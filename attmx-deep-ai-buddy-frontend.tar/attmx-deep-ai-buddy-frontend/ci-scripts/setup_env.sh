#!/bin/bash
if [[ "$1" == 'dev' ]]; then
	echo export BUCKET_URI=${BUCKET_URI_DEV}
elif [[ "$1" == 'stage' ]]; then
	echo export BUCKET_URI=${BUCKET_URI_STAGE}
else
	echo "unknow branch $1"
	exit 1
fi
