const _ = require('lodash');
// Use a random port number for the mock API by default,
// to support multiple instances of Jest running
// simultaneously, like during pre-commit lint.
process.env.MOCK_API_PORT = process.env.MOCK_API_PORT || _.random(9000, 9999);
module.exports = {
  setupFiles: ['<rootDir>/tests/setup'],
  globalSetup: '<rootDir>/tests/global-setup',
  globalTeardown: '<rootDir>/tests/global-teardown',
  setupFilesAfterEnv: ['<rootDir>/tests/matchers'],
  testMatch: ['**/(*.)unit.js'],
  moduleFileExtensions: ['js', 'json', 'jsx'],
  transform: {
    "^.+\\.tsx?$": "ts-jest",
    "^.+\\.(js|jsx|mjs)$": "<rootDir>/node_modules/babel-jest",
    '.+\\.(css|scss|jpe?g|png|gif|webp|svg|mp4|webm|ogg|mp3|wav|flac|aac|woff2?|eot|ttf|otf)$':
      'jest-transform-stub'
  },
  snapshotSerializers: ["enzyme-to-json/serializer"],
  coverageDirectory: '<rootDir>/tests/coverage',
  collectCoverageFrom: [
    'src/**/*.{js,jsx}',
    '!**/node_modules/**',
    '!src/App.js'
  ],
  watchPlugins: [
    'jest-watch-typeahead/filename',
    'jest-watch-typeahead/testname'
  ]
};
