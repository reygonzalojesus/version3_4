import { postRequest, postRequestLogin, getRequest, patchRequest, deleteRequest } from './utils';
import * as MwHistory from 'utils/MwHistory';
import * as FormatData from './formatdata';
import * as FormatTrans from './formatTransModels';
import { STORAGE_VARS } from 'utils/Constants';

export function passIP(userIP){
  const endpoint = 'user/setIP';
  return new Promise(function (resolve, reject) {
    const data = {
      ip: userIP
    };

    postRequestLogin(endpoint, data, false)
    .then((result) => {
      resolve(result);
    })
    .catch((error) => {
      switch (error.status) {
        case 401:
          MwHistory.replace('/401');
          break;
        case 423:
          MwHistory.replace('/423');
          break;
        case 404:
          MwHistory.replace('/404');
          break;
        case 500:
          MwHistory.replace('/500');
          break;
        default:
          MwHistory.replace('/500');
          break;
      }
    });
  });
}

export function login(email, password) {
  const endpoint = 'user/login';

  return new Promise(function (resolve, reject) {
    const data = {
      username: email,
      password: password
    };

    postRequestLogin(endpoint, data, false)
      .then((result) => {
        resolve(result);
      })
      .catch((error) => {
        switch (error.status) {
          case 401:
            MwHistory.replace('/401');
            break;
          case 423:
            MwHistory.replace('/423');
            break;
          case 404:
            MwHistory.replace('/404');
            break;
          case 500:
            MwHistory.replace('/500');
            break;
          default:
            MwHistory.replace('/500');
            break;
        }
      });
  });
}

export function logout() {
  const endpoint = 'user/logout';
  document.cookie = `${STORAGE_VARS.TOKEN}= ; expires = Thu, 01 Jan 1970 00:00:00 GMT;path=/`;

  return new Promise(function (resolve, reject) {
    if (!sessionStorage.getItem(STORAGE_VARS.TOKEN)) {
      resolve(null);
    } else {
      postRequest(endpoint)
        .then((result) => {
          resolve(result);
        })
        .catch((error) => {
          switch (error.status) {
            case 401:
              MwHistory.replace('/401');
              break;
            case 423:
              MwHistory.replace('/423');
              break;
            case 404:
              MwHistory.replace('/404');
              break;
            case 500:
              MwHistory.replace('/500');
              break;
            default:
              MwHistory.replace('/500');
              break;
          }
        });
    }
  });
}

export function getMe() {
  const endpoint = 'cco/persona/me';

  return new Promise(function (resolve, reject) {
    getRequest(endpoint)
      .then((result) => {
        resolve(FormatTrans.persona(result));
      })
      .catch((error) => {
        switch (error.status) {
          case 401:
            reject(error.status);
            MwHistory.replace('/403');
            break;
          case 403:
          case 404:
            reject(error.status);
            MwHistory.replace('/403');
            break;
          default:
            reject('error.generic');
            break;
        }
      });
  });
}

export function getPersona(personaId) {
  const endpoint = 'cco/persona/' + personaId;

  return new Promise(function (resolve, reject) {
    getRequest(endpoint)
      .then((result) => {
        const res = FormatTrans.persona(result);
        resolve(res);
      })
      .catch((error) => {
        switch (error.status) {
          case 404:
            reject('error.persona-404');
            break;
          case 403:
            reject(error.status);
            MwHistory.replace('/403');
            break;
          default:
            reject('error.generic');
            break;
        }
      });
  });
}

export function countPersonas() {
  const endpoint = 'cco/persona';
  return new Promise(function (resolve, reject) {
    getRequest(endpoint)
      .then((result) => {
        const results = result.count;
        resolve(results);
      })
      .catch((error) => {
        switch (error.status) {
          case 403:
            reject(error.status);
            MwHistory.replace('/403');
            break;
          case 404:
            reject(error.status);
            MwHistory.replace('/404');
            break;
          default:
            reject('error.generic');
            break;
        }
      });
  });
}
export function getPersonas(limit) {
  const endpoint = 'cco/persona?limit=' + limit;
  return new Promise(function (resolve, reject) {
    getRequest(endpoint)
      .then((result) => {
        const results = FormatData.personas(result.results);
        resolve(results);
      })
      .catch((error) => {
        switch (error.status) {
          case 403:
            reject(error.status);
            MwHistory.replace('/403');
            break;
          case 404:
            reject(error.status);
            MwHistory.replace('/404');
            break;
          default:
            reject('error.generic');
            break;
        }
      });
  });
}

export function getChannels() {
  const endpoint = 'cco/channel';

  return new Promise(function (resolve, reject) {
    getRequest(endpoint)
      .then((result) => {
        resolve(result.results);
      })
      .catch((error) => {
        switch (error.status) {
          case 403:
            reject(error.status);
            MwHistory.replace('/403');
            break;
          default:
            reject('error.generic');
            break;
        }
      });
  });
}

export function getPersonaTypes() {
  const endpoint = 'cco/personatype';

  return new Promise(function (resolve, reject) {
    getRequest(endpoint)
      .then((result) => {
        const results = FormatData.personaTypes(result.results);
        resolve(results);
      })
      .catch((error) => {
        switch (error.status) {
          case 403:
            reject(error.status);
            MwHistory.replace('/403');
            break;
          default:
            reject('error.generic');
            break;
        }
      });
  });
}

export function createUser(email, firstname, lastname, password, isactive, isStaff) {
  const endpoint = 'user';

  return new Promise(function (resolve, reject) {
    const data = {
      email: email,
      username: email,
      first_name: firstname,
      last_name: lastname,
      password: password,
      is_active: isactive,
      is_staff: isStaff
    };

    postRequest(endpoint, data)
      .then((result) => {
        resolve(result);
      })
      .catch((error) => {
        switch (error.status) {
          case 400:
            if (error.message.hasOwnProperty('email')) {
              reject('error.user-400-email');
            } else {
              reject('error.user-400-generic');
            }
            break;
          case 403:
            reject(error.status);
            MwHistory.replace('/403');
            break;
          default:
            reject('error.generic');
            break;
        }
      });
  });
}

export function deleteUser(userId) {
  const endpoint = 'user/' + userId;

  return new Promise(function (resolve, reject) {
    deleteRequest(endpoint)
      .then((result) => {
        resolve(result);
      })
      .catch((error) => {
        switch (error.status) {
          case 403:
            reject(error.status);
            MwHistory.replace('/403');
            break;
          default:
            reject('error.generic');
            break;
        }
      });
  });
}

export function createPersona(userId, typeId, channelId, nickname, isActive) {
  const endpoint = 'cco/persona';

  return new Promise(function (resolve, reject) {
    const data = {
      user: userId,
      type: typeId,
      channel: channelId,
      nickname: nickname.trim(),
      is_active: isActive
    };

    postRequest(endpoint, data)
      .then((result) => {
        resolve(result);
      })
      .catch((error) => {
        switch (error.status) {
          case 400:
            reject('error.user-400-generic');
            break;
          case 403:
            reject(error.status);
            MwHistory.replace('/403');
            break;
          default:
            reject('error.generic');
            break;
        }
      });
  });
}

export function patchPersona(personaId, typeId, channelId, nickname, isActive) {
  const endpoint = 'cco/persona/' + personaId;

  return new Promise(function (resolve, reject) {
    const data = {
      type: typeId,
      channel: channelId,
      nickname: nickname,
      isActive: isActive
    };
    if (!typeId) delete data.type;
    if (!channelId) delete data.channel;
    if (!nickname) delete data.nickname;

    patchRequest(endpoint, data)
      .then((result) => {
        resolve(result);
      })
      .catch((error) => {
        switch (error.status) {
          case 403:
            reject(error.status);
            MwHistory.replace('/403');
            break;
          case 404:
            reject('error.persona-404');
            break;
          default:
            reject('error.generic');
            break;
        }
      });
  });
}

export function patchUser(userId, email, firstname, lastname, isActive, isStaff) {
  const endpoint = 'user/' + userId;

  return new Promise(function (resolve, reject) {
    const data = {
      email: email,
      username: email,
      first_name: firstname,
      last_name: lastname,
      is_active: isActive,
      is_staff: isStaff
    };
    if (!email) {
      delete data.email;
      delete data.username;
    }
    if (!firstname) delete data.first_name;
    if (!lastname) delete data.last_name;

    patchRequest(endpoint, data)
      .then((result) => {
        resolve(result);
      })
      .catch((error) => {
        switch (error.status) {
          case 400:
            if (error.message.hasOwnProperty('email')) {
              reject('error.user-400-email');
            } else {
              reject('error.user-400-generic');
            }
            break;
          case 403:
            reject(error.status);
            MwHistory.replace('/403');
            break;
          case 404:
            reject('error.user-404');
            break;
          default:
            reject('error.generic');
            break;
        }
      });
  });
}

export function setUserPassword(userId, password) {
  const endpoint = 'user/' + userId + '/chpass';

  return new Promise(function (resolve, reject) {
    const data = {
      new_password: password
    };

    postRequest(endpoint, data)
      .then((result) => {
        resolve(result);
      })
      .catch((error) => {
        switch (error.status) {
          case 403:
            reject(error.status);
            MwHistory.replace('/403');
            break;
          case 404:
            reject('error.user-404');
            break;
          default:
            reject('error.generic');
            break;
        }
      });
  });
}

export function patchUserAvatar(userId, avatarId) {
  //patch user avatar
  const endpoint = 'user/' + userId;

  return new Promise(function (resolve, reject) {
    const data = {
      avatar: avatarId
    };

    patchRequest(endpoint, data)
      .then((result) => {
        resolve(result);
      })
      .catch((error) => {
        switch (error.status) {
          case 400:
            reject('error.user-400-generic');
            break;
          case 403:
            reject(error.status);
            MwHistory.replace('/403');
            break;
          case 404:
            reject('error.user-404');
            break;
          default:
            reject('error.generic');
            break;
        }
      });
  });
}

export function patchRemoveAvatar(userId) {
  //patch user avatar
  const endpoint = 'user/' + userId;

  return new Promise(function (resolve, reject) {
    const data = {
      avatar: null
    };

    patchRequest(endpoint, data)
      .then((result) => {
        resolve(result);
      })
      .catch((error) => {
        switch (error.status) {
          case 400:
            reject('error.user-400-generic');
            break;
          case 403:
            reject(error.status);
            MwHistory.replace('/403');
            break;
          case 404:
            reject('error.user-404');
            break;
          default:
            reject('error.generic');
            break;
        }
      });
  });
}

export function getAvatar(avatarId) {
  const endpoint = 'avatar/' + avatarId;

  return new Promise(function (resolve, reject) {
    if (!avatarId) {
      const res = FormatTrans.avatar(null);
      resolve(res);
      return;
    }

    getRequest(endpoint)
      .then((result) => {
        const res = FormatTrans.avatar(result);
        resolve(res);
      })
      .catch((error) => {
        switch (error.status) {
          default:
            reject('error.generic');
            break;
        }
      });
  });
}

export function getAvatars() {
  const endpoint = 'avatar';

  return new Promise(function (resolve, reject) {
    getRequest(endpoint)
      .then((result) => {
        const results = FormatData.avatars(result.results);
        resolve(results);
      })
      .catch((error) => {
        switch (error.status) {
          case 403:
            reject(error.status);
            MwHistory.replace('/403');
            break;
          default:
            reject('error.generic');
            break;
        }
      });
  });
}

export function getTenants() {
  const endpoint = 'cco/clientsettings';

  return new Promise(function (resolve, reject) {
    getRequest(endpoint, false)
      .then((result) => {
        resolve(result.results);
      })
      .catch((error) => {
        switch (error.status) {
          case 403:
            reject(error.status);
            MwHistory.replace('/403');
            break;
          default:
            reject('error.generic');
            break;
        }
      });
  });
}
