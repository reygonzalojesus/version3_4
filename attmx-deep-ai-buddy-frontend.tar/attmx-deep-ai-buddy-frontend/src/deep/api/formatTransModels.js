import { AvatarsSrc } from 'demo/ImagesSrc';

function formatTrans(trans) {
  return trans
}

export function user(data) {
  data.avatar = avatar(data.avatar);
  return data;
}

export function persona(data) {
  let dataTranslated = {
    ...data,
    user: user(data.user),
    type: personaType(data.type),
    channel: channel(data.channel)
  };
  return dataTranslated;
}

export function personaType(data) {
  if (!data) {
    return null;
  }
  let dataTranslated = {
    ...data,
    name: formatTrans(data.name)
  };
  return dataTranslated;
}

export function channel(data) {
  if (!data) {
    return null;
  }
  let dataTranslated = {
    ...data,
    name: formatTrans(data.name)
  };
  return dataTranslated;
}

export function campaignType(data) {
  if (!data) {
    return null;
  }

  let dataTranslated = {
    ...data,
    name: formatTrans(data.name)
  };
  return dataTranslated;
}

export function campaign(data) {
  if (!data) {
    return null;
  }

  let dataTranslated = {
    ...data,
    name: formatTrans(data.name),
    type: campaignType(data.type)
  };
  return dataTranslated;
}

export function offer(data) {
  if (!data) {
    return null;
  }

  let dataTranslated = {
    ...data,
    type: formatTrans(data.type),
    sub_type: formatTrans(data.sub_type),
    argument_sentence: formatTrans(data.argument_sentence),
    selling_sentence: formatTrans(data.selling_sentence),
    post_sale: formatTrans(data.post_sale)
  };
  if (data.others) {
    dataTranslated.others = data.others.map(offer);
  }

  return dataTranslated;
}

export function product(data) {
  if (!data) {
    return null;
  }
  let dataTranslated = {
    ...data,
    name: formatTrans(data.name)
  };
  return dataTranslated;
}

export function contract(data) {
  if (!data) {
    return null;
  }
  let dataTranslated = {
    ...data,
    product: product(data.product)
  };
  return dataTranslated;
}

export function outcome(data) {
  if (!data) {
    return null;
  }
  let dataTranslated = {
    ...data,
    name: formatTrans(data.name)
  };
  return dataTranslated;
}

export function reason(data) {
  if (!data) {
    return null;
  }
  let dataTranslated = {
    ...data,
    description: formatTrans(data.description),
    product: product(data.product)
  };
  return dataTranslated;
}

export function productFeature(data) {
  if (!data) {
    return null;
  }
  let dataTranslated = {
    ...data,
    name: formatTrans(data.name),
    unit: formatTrans(data.unit)
  };
  return dataTranslated;
}

export function feedback(data) {
  if (!data) {
    return null;
  }

  let dataTranslated = {
    ...data,
    outcome: outcome(data.outcome),
    channel: channel(data.channel),
    reason: reason(data.reason)
  };
  return dataTranslated;
}

export function opportunity(data) {
  if (!data) {
    return null;
  }

  let dataTranslated = {
    ...data,
    offer: offer(data.offer),
    product: product(data.product)
  };
  return dataTranslated;
}

export function customerAttribute(data) {
  if (!data) {
    return null;
  }

  let dataTranslated = {
    ...data,
    attribute: {
      ...data.attribute,
      name: formatTrans(data.attribute.name)
    }
  };
  return dataTranslated;
}

export function interaction(data) {
  if (!data) {
    return null;
  }

  let dataTranslated = {
    ...data,
    kind: {
      ...data.kind,
      name: formatTrans(data.kind.name)
    },
    channel: channel(data.channel),
    outcome: outcome(data.outcome)
  };
  return dataTranslated;
}

export function dataDrivenTip(data) {
  if (!data) {
    return null;
  }

  let dataTranslated = {
    ...data,
    sentence: formatTrans(data.sentence)
  };
  return dataTranslated;
}

export function collectionChoice(data) {
  if (!data) {
    return null;
  }
  let dataTranslated = {
    ...data,
    choice: formatTrans(data.choice)
  };
  return dataTranslated;
}

export function collectionQuestion(data) {
  if (!data) {
    return null;
  }
  let dataTranslated = {
    ...data,
    question: formatTrans(data.question),
    choices: data.choices.map(collectionChoice)
  };
  return dataTranslated;
}

export function quarantine(data) {
  if (!data) {
    return null;
  }
  let dataTranslated = {
    ...data,
    label: formatTrans(data.label)
  };
  return dataTranslated;
}
export function avatar(data) {
  if (!data) {
    return {
      id: null,
      file: require('assets/images/default_avatar.png')
    };
  }
  let dataFormatted = {
    id: data.id,
    file: data.file
  };
  if (
    data &&
    data.file &&
    (data.file.indexOf('localhost') > 0 || data.file.indexOf('http') < 0)
  ) {
    let file = data.file;
    let splits = file.split('/');
    const fileFullName = splits[splits.length - 1];
    splits = fileFullName.split('.');
    const fileExt = splits[splits.length - 1];
    const fileName = splits[0];
    splits = fileName.split('_');
    const fileSuf = splits[splits.length - 1];
    const fileRealName = fileName.replace('_' + fileSuf, '') + '.' + fileExt;
    const filePath = '/uploads/avatars/' + fileRealName;
    dataFormatted.file = AvatarsSrc[filePath];
  }

  return dataFormatted;
}


export function customerPromotions(data) {
  if (!data) {
    return null;
  }

  let dataTranslated = {
    ...data,
    attribute: {
      ...data.attribute,
      name: formatTrans(data.name)
    }
  };
  return dataTranslated;
}
