import { STORAGE_VARS } from 'utils/Constants';
import * as Tenancy from 'utils/Tenancy';

function getApiUrl() {
  let apibase = 'http://localhost:8000/deep/api/v1/';
  if (!Tenancy.isLocal()) {
    if (window.location.origin === 'https://buddy.mx.att.com') {
      // apibase = window.location.origin + '/deep/api/v1/';
      apibase = 'https://buddyservices.mx.att.com/deep/api/v1/';
      // apibase = 'https://buddy.mx.att.com/deep/api/v1/';
    }else if (window.location.origin === 'https://buddyuat.mx.att.com:16500') {
      apibase = 'https://buddyservicesuat.mx.att.com:16601/deep/api/v1/';
    }
  }
  return apibase;
}

function handleResponse(response, resolve, reject) {
  if (response.ok) {
    let key = Tenancy.isLocal() ? 'Token' : 'token';
    const token = response.headers.get(key);
    if (token) {
      const expiration = new Date();
      expiration.setHours(expiration.getHours() + 4);
      document.cookie = `${STORAGE_VARS.TOKEN}=${token}; ${expiration};path=/; SameSite='Lax'`;
      sessionStorage.setItem(STORAGE_VARS.TOKEN, token);
    }
    if (response.status === 204) {
      resolve();
    } else {
      response.json().then((result) => {
        resolve(result);
      });
    }
  } else {
    response
      .json()
      .then((result) => {
        const output = {
          status: response.status,
          message: result
        };
        reject(output);
      })
      .catch((error) => {
        const output = {
          status: response.status,
          message: null
        };
        reject(output);
      });
  }
}

function handleResponseLogin(response, resolve, reject){
  if (response.ok) {
    let key = Tenancy.isLocal() ? 'Token' : 'token';
    const token = response.headers.get(key);
    if (token) {
      const expiration = new Date();
      expiration.setHours(expiration.getHours() + 4);
      document.cookie = `${STORAGE_VARS.TOKEN}=${token}; ${expiration};path=/; SameSite='Lax'`;
      sessionStorage.setItem(STORAGE_VARS.TOKEN, token);
    }
    if (response.status === 204) {
      resolve();
    } else {
      response.json().then((result) => {
        resolve(result);
      });
    }
  } else {
    response
      .json()
      .then((result) => {
        const output = {
          status: response.status,
          message: result
        };
        reject(output);
      })
      .catch((error) => {
        const output = {
          status: response.status,
          message: null
        };
        reject(output);
      });
  }
}

export function getRequest(endpoint, isAuth = true) {
  return new Promise(function (resolve, reject) {
    const token = sessionStorage.getItem(STORAGE_VARS.TOKEN);
    let headers = {
      'Content-Type': 'application/json',
      Authorization: token
    };

    if (!isAuth || token === null) delete headers.Authorization;

    fetch(getApiUrl() + endpoint, {
      method: 'GET',
      headers: headers
    })
      .then((response) => {
        handleResponse(response, resolve, reject);
      })
      .catch((error) => {
        reject(error);
      });
  });
}

export function postRequest(endpoint, data, isAuth = true) {
  return new Promise(function (resolve, reject) {
    let headers = {
      'Content-Type': 'application/json',
      Authorization: sessionStorage.getItem(STORAGE_VARS.TOKEN)
    };
    if (!isAuth) delete headers.Authorization;

    fetch(getApiUrl() + endpoint, {
      method: 'POST',
      headers: headers,
      body: JSON.stringify(data)
    })
      .then((response) => {
        handleResponse(response, resolve, reject);
      })
      .catch((error) => {
        reject(error);
      });
  });
}

export function postRequestLogin(endpoint, data, isAuth = true) {
  return new Promise(function (resolve, reject) {
    let headers = {
      'Content-Type': 'application/json',
      Authorization: sessionStorage.getItem(STORAGE_VARS.TOKEN)
    };
    if (!isAuth) delete headers.Authorization;

    fetch(getApiUrl() + endpoint, {
      method: 'POST',
      headers: headers,
      body: JSON.stringify(data)
    })
      .then((response) => {
        handleResponseLogin(response, resolve, reject);
      })
      .catch((error) => {
        reject(error);
      });
  });
}

export function patchRequest(endpoint, data, isAuth = true) {
  return new Promise(function (resolve, reject) {
    let headers = {
      'Content-Type': 'application/json',
      Authorization: sessionStorage.getItem(STORAGE_VARS.TOKEN)
    };
    if (!isAuth) delete headers.Authorization;

    fetch(getApiUrl() + endpoint, {
      method: 'PATCH',
      headers: headers,
      body: JSON.stringify(data)
    })
      .then((response) => {
        handleResponse(response, resolve, reject);
      })
      .catch((error) => {
        reject(error);
      });
  });
}

export function deleteRequest(endpoint, isAuth = true) {
  return new Promise(function (resolve, reject) {
    let headers = {
      'Content-Type': 'application/json',
      Authorization: sessionStorage.getItem(STORAGE_VARS.TOKEN)
    };
    if (!isAuth) delete headers.Authorization;

    fetch(getApiUrl() + endpoint, {
      method: 'DELETE',
      headers: headers
    })
      .then((response) => {
        handleResponse(response, resolve, reject);
      })
      .catch((error) => {
        reject(error);
      });
  });
}
