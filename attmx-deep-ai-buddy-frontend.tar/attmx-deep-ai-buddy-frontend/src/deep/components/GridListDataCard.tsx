import React from 'react';
import {TFunction} from "i18next";
import {Theme} from "@material-ui/core/styles";
import {GridList, GridListTile, withStyles} from "@material-ui/core";
import Gauge from "./materials/Gauge";
import Rating from "./materials/Rating";

const styles: any = (theme: Theme) => ({
    item: {
        position: 'relative',
        '&:nth-child(n+3)': {
            paddingTop: '1.5rem !important'
        }
    },
    left: {
        paddingRight: '1.2rem !important'
    },
    right: {
        paddingLeft: '1.2rem !important'
    },
    full: {
        padding: '0rem'
    },
    label: {
        color: '#4C4C4C',
        fontWeight: 600,
        textAlign: 'left',
        width: '100%',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        fontSize: '1.5rem'
    },
    value: {
        position: 'relative',
        color: '#777777',
        textAlign: 'left',
        marginBottom: '1.5rem',
        width: '100%',
        overflow: 'hidden',
        textOverflow: 'ellipsis'
    },
    icon: {
        position: 'absolute',
        right: '0rem',
        top: '0rem'
    },
    separator: {
        position: 'absolute',
        bottom: '0rem',
        height: '1px',
        width: '100%',
        backgroundColor: '#E6E9EE'
    },
    portfolio: {
        marginTop: '1rem'
    },
    portfolioTitle: {
        fontSize: '1.7rem',
        color: '#4C4C4C',
        fontWeight: 600,
        marginBottom: '0.6rem'
    },
    chip: {
        boxShadow: '0rem 0.1rem 0.3rem 0rem rgba(0,0,0,0.3)',
        borderRadius: '3rem',
        padding: '0.7rem 1.2rem 0.7rem',
        marginRight: '1rem',
        color: '#777777',
        textAlign: 'center',
        backgroundColor: '#fff',
        display: 'inline-block',
        marginBottom: '1rem'
    }
});

export enum DataDisplayType {
    Text ,
    Gauge,
    Rating,
    SlidingRating
}

export interface DataItem {
    label: string;
    value: any;
    cols?: number;
    display?: DataDisplayType;
    type?: DataDisplayType;
}


interface GridListDataCardProps {
    data: DataItem[];
    t: TFunction;
    cols?: number;
    spacing?: number;
    itemCols?: number;
    classes: any;
}

interface ItemValueDisplayProps {
    item: DataItem;
    t: TFunction;
    classes: any;
}

function getRateStyle(value: any, t: TFunction) {
    if (value < 0.33) {
        return (
            <span style={{ fontWeight: 400, color: '#75CC19' }}>
          {t('session.customerdetails.val-low')}
        </span>
        );
    } else if (value < 0.66) {
        return (
            <span style={{ fontWeight: 400, color: 'orange' }}>
          {t('session.customerdetails.val-medium')}
        </span>
        );
    } else {
        return (
            <span style={{ fontWeight: 400, color: '#FF3838' }}>
          {t('session.customerdetails.val-high')}
        </span>
        );
    }
}

function ItemValueDisplay(props: ItemValueDisplayProps) {
    let renderedValue;
    const display = (props.item.display || props.item.type || DataDisplayType.Text);
    switch (display) {
        case DataDisplayType.Gauge:
            renderedValue = <Gauge value={props.item.value} />
            break;
        case DataDisplayType.Rating:
            renderedValue = <Rating value={props.item.value}
                                    precision={0.5}
                                    readOnly
                                />
            break;
        case DataDisplayType.SlidingRating:
            renderedValue = getRateStyle(props.item.value, props.t)
            break;
        default:
            renderedValue = <>{props.item.value}</>
            break;
    }
    return <>
        <div className={props.classes.label}>
            {props.item.label}
        </div>
        <div className={props.classes.value}>
            {renderedValue}
        </div>
    </>
}

function GridListDataCard(props: GridListDataCardProps) {
    const cols = props.cols || 1;
    const spacing = props.spacing || 0;
    return <div>
        <GridList cellHeight='auto'
                  cols={cols}
                  spacing={spacing}>
            {
               props.data.map((dataPoint, index) =>
                    <GridListTile
                        key={index}
                        cols={dataPoint.cols || 1}
                        className={props.classes.item}
                    >
                        <ItemValueDisplay item={dataPoint}
                                          t={props.t}
                                          classes={props.classes} />
                    </GridListTile>
               )
            }
        </GridList>
    </div>
}

export default withStyles(styles)(GridListDataCard);