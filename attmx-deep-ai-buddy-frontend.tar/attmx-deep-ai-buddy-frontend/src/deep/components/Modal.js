import React from 'react';
import styled from 'styled-components';

const Modal = ({children,estado,cambiarEstado}) => {
    return (
        <>
        {estado && 
         <Overlay>
            <Contenido>
            <ContenedorModal>
                <EncabezadoModal>
                    <h3>Mensaje</h3>
                </EncabezadoModal>
                <BotonCerrar onClick={() => cambiarEstado(false) }>X</BotonCerrar>
                {children}
            </ContenedorModal>
            </Contenido>

         </Overlay>
         }
        </>
    )
}

export default Modal;

const Overlay = styled.div`
    width: 100vw;
    height: 108vh;
    position: fixed;
    top: 0;
    left: 0;
    background: rgba(0,0,0,.5);
    padding: 40px;

    display: flex;
    align-items:center;
    justify-content: center;
    z-index: 1000;


`;

const ContenedorModal = styled.div`
  width: 500px;
  min-height: 100px;
  background: #fff;
  position: relative;
  border-radius: 5px;
  box-shadow: rgba(100,100,111,0.2) 0px 7px 29px 0px;
  padding: 20px;
  z-index: 1000;
`;

const EncabezadoModal = styled.div`
       display: flex;
       align-items: center;
       justify-content: space-between;
       margin-bottom: -10px;
       padding-bottom: 0px;
       border-botton: 1px solid #E8E8E8;
       h3{
        font-weight: 500;
        font-size: 16px;
        color: #00A8E0;;
       }
       z-index: 1000;
`;

const BotonCerrar = styled.button`
      position: absolute;
      top: 20px;
      right: 20px;
      
      width: 30px;
      height: 30px;
      border: none;
      background: none;
      cursor: pointer;
      transition: .3s ease all;
      border-radius: 5px;
      color: #00A8E0;

      &:hover {
        background: #00A8E0;
      }
      z-index: 1000;

`;


const Contenido = styled.div`
   display: flex;
   flex-direction: column;
   align-items: center;
   h1{
    font-size:42px;
    font-weight: 700;
    margin-bottom: 10px;
   } 

   p{
    font-size: 10px;
    margin-botton: 20px;
   }
   z-index: 100;

   

`;