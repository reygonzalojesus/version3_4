import React from 'react';
import Content, { ContentType } from '../../types/content';

type ReplacementMapping = { [src: string]: string };

interface ScriptRenderProps {
  content: Content;
  // Optionally supply a list of replacements
  replacements?: ReplacementMapping;
  // Optionally, pass in a custom renderer for rendering lists of scripts. Otherwise, ulRenderer will be use
  renderer?: (scripts: string[]) => any;
}

function ulRenderer(scripts: string[]): React.ReactElement {
  return (
    <>
      <ul>
        {scripts.map((s, i) => (
          <li key={i}>
            <span
              dangerouslySetInnerHTML={{
                __html: s
              }}
            />
          </li>
        ))}
      </ul>
    </>
  );
}

// The keys used for call scripts in different place in the app - they'll all be rendered in this order,
// depending on what's present
const _RECOGNIZED_SCRIPT_KEYS = ['pre_script', 'script', 'post_script'];

function runReplacements(
  src: string,
  replacements: ReplacementMapping
): string {
  let replacedSrc = src;
  for (let replacement of Object.keys(replacements)) {
    replacedSrc = replacedSrc.replaceAll(
      replacement,
      replacements[replacement]
    );
  }
  return replacedSrc;
}

export default function ScriptRender(props: ScriptRenderProps) {
  if (props.content.type !== ContentType.CallScript &&
      props.content.type !== ContentType.OfferScript) {
    console.warn(
      'Trying to render content with unsupported type, ',
      props.content
    );
  }
  const replaceIfEnabled = (s: string) =>
    props.replacements ? runReplacements(s, props.replacements) : s;
  const parsedScriptData = props.content.content as { [key: string]: string };
  // Go through each of the recognized type of scripts
  let renderSections: string[] = [];
  for (let scriptKey of _RECOGNIZED_SCRIPT_KEYS) {
    if (scriptKey in parsedScriptData) {
      const scriptValue = parsedScriptData[scriptKey] as string | Array<string>;
      // If the script is a standalone string, push it
      if (typeof scriptValue === 'string') {
        renderSections.push(replaceIfEnabled(scriptValue));
      } else {
        renderSections.push(...scriptValue.map((s) => replaceIfEnabled(s)));
      }
    }
  }
  if (renderSections.length === 0) {
    console.error('No supported content found', props.content);
    renderSections.push('No script found');
  }
  const listRenderer = props.renderer || ulRenderer;
  // If there's only a single script in renderSections, only render that script. Otherwise, render
  // the whole thing according to listRenderer.
  return (
    <>
      {renderSections.length === 1 ? (
        <div
          dangerouslySetInnerHTML={{
            __html: renderSections[0]
          }}
        />
      ) : (
        listRenderer(renderSections)
      )}
    </>
  );
}
