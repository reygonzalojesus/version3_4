import React from 'react';

export default function Gauge(props) {
  const value = parseFloat(props.value);
  const numSteps = Math.round(value * 10);
  const arSteps = Array(10).fill(null);

  const getColor = (numSteps) => {
    if (numSteps < 4) {
      return '#FF3838';
    } else if (numSteps < 7) {
      return 'orange';
    } else {
      return '#75CC19';
    }
  };

  return (
    <div style={{ display: 'flex', marginTop: '0.4rem' }}>
      {arSteps.map((step, index) => (
        <div
          key={index}
          style={{
            height: props.height ? props.height : '1.8rem;',
            width: props.width ? props.width : '2px',
            backgroundColor: index < numSteps ? getColor(numSteps) : '#DFDFDF',
            marginRight: 3
          }}
        />
      ))}
    </div>
  );
}
