import React from 'react';
import './pill.css';
import { Grid } from '@material-ui/core';

export interface PillProps {
  data: any;
  label: any;
}

export default function PillListA(props: PillProps) {
  return (
    <div className='pill'>
      <Grid
        container
        direction='row'
        justify='flex-start'
        alignItems='stretch'
        alignContent='stretch'
        className='pill'
        spacing={2}
      >
        <Grid item className='pill-label' md={6}>
          {props.label}
        </Grid>
        <Grid item className='pill-data' md={6}>
          {props.data.map(promotion => <p key={promotion.current === true? promotion.name: ""}>{`${promotion.current === true? promotion.name: ""}`}</p>)}

        </Grid>
      </Grid>
    </div>
  );
}

