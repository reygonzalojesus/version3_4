import React from 'react';
import { Theme, withStyles } from '@material-ui/core/styles';

const styles = (theme: Theme) => ({
  label: {
    color: '#4C4C4C',
    fontWeight: 600,
    textAlign: 'left',
    width: '100%',
    overflow: 'wrap',
    textOverflow: 'ellipsis',
    fontSize: '1rem'
  },
  table: {
    borderCollapse: 'collapse',
    tableLayout: 'auto',
    width: '100%'
  },
  row: {
    borderBottom: '1px solid black',
    fontSize: '0.6em'
  },
  cell: {
    textAlign: 'center',
    borderLeft: '1px solid black',
    borderRight: '1px solid black',
    wordWrap: 'break-word',
    overflowWrap: 'break-word'
  },
  header: {
    fontSize: '0.8em',
    textAlign: 'center',
    padding: '0.3em',
    border: '1px solid black'
  }
});

interface SimpleTableData {
  rows: any[][];
  headers: string[];
}

interface SimpleTableProps {
  data: SimpleTableData;
  field_name: string;
  classes: any;
}

function SimpleTable(props: SimpleTableProps) {
  const { classes } = props;
  return (
    <table className={classes.table}>
      <thead>
        <tr className={classes.label}>
          {props.data.headers.map((h, i) => (
            <td key={i} className={classes.header}>
              {h}
            </td>
          ))}
        </tr>
      </thead>
      <tbody>
        {props.data.rows.map((row, i) => (
          <tr key={i} className={classes.row}>
            {row.map((c, k) => (
              <td className={classes.cell} key={k}>
                {c}
              </td>
            ))}
          </tr>
        ))}
        {(!props.data || (props.data && props.data.rows.length === 0)) && (
          <tr>
            <td colSpan={props.data.headers.length}>
              <span>{`No se encontraron datos para ${props.field_name}`}</span>
            </td>
          </tr>
        )}
      </tbody>
    </table>
  );
}

// @ts-ignore
export default withStyles(styles)(SimpleTable);
