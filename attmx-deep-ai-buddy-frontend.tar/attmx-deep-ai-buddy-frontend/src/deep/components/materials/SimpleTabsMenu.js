import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';

export default function SimpleTabsMenu(props) {
  const useStyles = makeStyles((theme) => ({
    tabs: {
      minHeight: 'auto'
    },
    indicator: {
      height: '1px'
    },
    tab: {
      minWidth: 'auto',
      minHeight: 'auto',
      textTransform: 'none',
      margin: '0rem 2.4rem 0.3rem 0rem',
      color: '#777777',
      opacity: '0.5',
      fontSize: '1.5rem',
      '&:after': {
        content: "''",
        border: 'solid #777777',
        marginLeft: '20px',
        borderWidth: '0 2px 2px 0',
        padding: '3px',
        left: '20px',
        transform: 'rotate(-45deg)',
        width: '0',
        height: '8px',
      },
    },
    selected: {
      fontWeight: 600,
      opacity: '1'
    }
  }));
  const classes = useStyles(props);

  const styles = {
    wrapper: {
      position: 'relative',
      marginBottom: '2.3rem'
    },
    bgLine: {
      position: 'absolute',
      bottom: 0,
      height: '1px',
      width: '100%',
      backgroundColor: '#E6E9EE'
    }
  };

  const tabs = props.tabs;

  return (
    <div style={styles.wrapper}>
      <div style={styles.bgLine}></div>
      <Tabs
        value={props.value}
        indicatorColor='secondary'
        onChange={props.onChange}
        classes={{
          root: classes.tabs,
          indicator: classes.indicator
        }}
      >
        {tabs.map((tab, index) => (
          <Tab
            key={tab.id}
            label={tab.name}
            wrapped={false}
            disableRipple={true}
            disableFocusRipple={true}
            classes={{
              root: classes.tab,
              selected: classes.selected
            }}
          />
        ))}
      </Tabs>
    </div>
  );
}
