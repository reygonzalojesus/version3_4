import React from 'react';
import {Theme, withStyles} from "@material-ui/core/styles";

interface SoftTableData {
    rows: any[][];
    headers: string[];
}

interface SoftTableProps {
    data: SoftTableData;
    field_name: string;
    classes: any;
}

const styles = (theme: Theme) => ({
    label: {
        color: '#4C4C4C',
        fontWeight: 600,
        textAlign: 'left',
        width: '100%',
        overflow: 'wrap',
        textOverflow: 'ellipsis',
        fontSize: '1rem'
    },
    table: {
        borderCollapse: 'collapse',
        tableLayout: 'fixed',
        width: '100%',
        border: '2px #4C4C4C',
        borderRadius: '8px'
    },
    row: {
        fontSize: '0.6em',
        borderBottom: '1px solid #4C4C4C'
    },
    cell: {
        textAlign: 'center',
        wordWrap: 'break-word',
        overflowWrap: 'break-word'
    },
    header: {
        fontSize: '0.8em',
        textAlign: 'center',
        padding: '0.3em'
    }
})

function SoftTable(props: SoftTableProps) {
    const { classes } = props;
    return <table className={classes.table}>
        <thead>
        <tr className={classes.label}>
            {props.data.headers.map((h, i) =>
                <td key={i} className={classes.header}>{h}</td>
            )}
        </tr>
        </thead>
        <tbody>
        {props.data.rows.map((row, i) => <tr key={i} className={classes.row}>
            {row.map((c, k) =>
                <td className={classes.cell}
                    key={k}
                >{c}</td>
            )}
        </tr>)}
        </tbody>
        {(!props.data || (props.data && props.data.rows.length === 0))  && <p>{`No se encontraron datos para ${props.field_name}`}</p>}
    </table>
}

//@ts-ignore
export default withStyles(styles)(SoftTable);
