import React, {ReactElement} from 'react';
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import {makeStyles} from "@material-ui/core/styles";

const useStyles = makeStyles((theme) => ({
    root: {
        flexGrow: 1,
        backgroundColor: theme.palette.background.paper,
        display: 'flex',
        height: 224,
    },
    tabs: {
        //borderRight: `1px solid ${theme.palette.divider}`,
    },
    tab: {
        minWidth: 'auto',
        maxWidth: '12rem',
        maxHeight: 'auto',
        textTransform: 'none',
        padding: 0,
        margin: '0rem 2.4rem 0.3rem 0rem',
        color: 'black',
    },
    labels: {
        flex: "left",
        display: "flex",
        flexWrap: "nowrap",
        flexDirection: "column",
    },
    body: {
        fontSize: 12,
    },
    selected: {
        fontWeight: 600,
        opacity: '1'
    }
}));


export interface VerticalTabMenuChild {
    // The rendered body of the tab
    body: ReactElement;
    // If a tab provides a name and description, the list item for it will be generated automatically.
    // Otherwise,
    name?: string;
    alt_name?: string;
    description?: string;
    listitem?: ReactElement;
}

function a11yProps(index: number) {
    return {
        id: `vertical-tab-${index}`,
        'aria-controls': `vertical-tabpanel-${index}`,
    };
}


function TabPanel(props: any) {
    const { children, value, index, ...other } = props;
    const classes = useStyles();

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`vertical-tabpanel-${index}`}
            aria-labelledby={`vertical-tab-${index}`}
            className={classes.body}
            {...other}
        >
            {value === index && (
                props.children
            )}
        </div>
    );
}


function VerticalColumnTab(props: { tab: VerticalTabMenuChild, idx: number, onClick: (n: number) => any }) {
    const classes = useStyles();
    let tabLabel;
    if (props.tab.listitem) {
        tabLabel = props.tab.listitem;
    } else {
        let name, description, alt_name;
        if (props.tab.name || props.tab.alt_name ||  props.tab.description) {
            name = <b style={{fontSize: 10}}>{props.tab.name || "Unknown"}</b>
            if (props.tab.alt_name) {
                alt_name = <b style={{fontSize: 10}}>{props.tab.alt_name || "Unknown"}</b>
            }
            description = <span style={{fontSize: 10}}>{props.tab.description || ''}</span>
        } else {
            name = <b>Tab {props.idx}</b>
            description = <></>
        }
        tabLabel = <div className={classes.labels}>
            {name}
            {alt_name ? alt_name : ''}
            <br />
            {description}
        </div>
    }
    return <Tab key={props.idx}
                label={tabLabel}
                {...a11yProps(props.idx)}
                onClick={() => props.onClick(props.idx)}
                classes={{
                    root: classes.tab,
                    selected: classes.selected
                }}
    />
}

interface VerticalTabMenuProps {
    // The tabs and their content
    children: VerticalTabMenuChild[];
    // The title of the whole component
    title?: string;
    // Optionally specify the tab key to start with, should correspond to a key in children
    start?: number;
    // Optionally provide a callback for whenever a tab is selected
    onTabSelected?: (tabKey: number) => any;
    // The scroll variant of the tabs. Defaults to "scrollable"
    scrollVariant?: "standard" | "scrollable" | "fullWidth";
}

/**
 * A menu of vertical tabs and their content
 */
function VerticalTabMenu(props: VerticalTabMenuProps) {
    const classes = useStyles();

    // The state handler for the current tab
    const [currTab, setCurrTab] = React.useState(props.start || 0);

    const setCurrTabValue = (v: any) => {
        setCurrTab(v);
        if (props.onTabSelected) {
            props.onTabSelected(v);
        }
    }

    const styles = {
        wrapper: {
            position: 'relative',
            marginBottom: '2.3rem'
        },
        bgLine: {
            position: 'absolute',
            bottom: 0,
            height: '1px',
            width: '100%',
            backgroundColor: '#E6E9EE'
        }
    };

    return <div style={styles.wrapper}>
            {props.title && <h3>{props.title}</h3>}
            {props.children.length > 0 && <div>
                <Tabs variant={props.scrollVariant || "scrollable"}
                      value={currTab}
                      onChange={(e, val) => setCurrTabValue(val)}
                      className={classes.tabs}
                >
                    {props.children.map((c, i) =>
                        <VerticalColumnTab
                            tab={c}
                            idx={i}
                            key={i}
                            onClick={setCurrTabValue}
                        />)}
                </Tabs>
                {props.children.map((c, i) =>
                    <TabPanel
                        key={i}
                        index={i}
                        value={currTab}>
                            {c.body}
                    </TabPanel>
                )}
            </div>}
        </div>
}

export default VerticalTabMenu;