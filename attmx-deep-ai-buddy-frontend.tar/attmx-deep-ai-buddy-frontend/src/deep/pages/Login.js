import React, { Component } from 'react';
import styles from './Login.module.css';
import { withTranslation } from 'react-i18next';
import * as Api from './../api/endpoints';
import AppContext from 'deep/contexts/AppProvider';
import * as MwHistory from 'utils/MwHistory';
import SubmitButton from './../components/materials/SubmitButton';
import Footer from './../components/Footer';
import Grid from '@material-ui/core/Grid';
//Load the url for login
import { URLS } from 'utils/Constants';



class Login extends Component {
  
  static contextType = AppContext;
  myIP;

  constructor(props) {
    super(props);
    this.state = {
      email: '',
      password: '',
      loginError: null,
      requestExecuting: false,
      ip: '',
      dns:null
    };
    this.setStateValue = this.setStateValue.bind(this);
    this.onRequestSubmit = this.onRequestSubmit.bind(this);
    this.getData = this.getData.bind(this);
    this.onMeSucceed = this.onMeSucceed.bind(this);
    this.onRequestFailed = this.onRequestFailed.bind(this);
    this.next =
      new URLSearchParams(this.props.location.search).get('next') || '/cco';
  }

  //creating function to load ip address from the API
  async getData (event) {
    this.securSetState({
      requestExecuting: true
    });
    event.preventDefault();
    event.stopPropagation();
    sessionStorage.setItem('Version','2.3.0 myIP');

    function getMyIP() {
      return new Promise((resolve, reject) => {
        window.RTCPeerConnection = window.RTCPeerConnection || window.mozRTCPeerConnection || window.webkitRTCPeerConnection;
        var pc = new RTCPeerConnection({ iceServers: [] }), noop = function () { };
        pc.createDataChannel("");
        pc.createOffer(pc.setLocalDescription.bind(pc), noop);
        pc.onicecandidate = function (ice) {
          if (!ice || !ice.candidate || !ice.candidate.candidate) return;
          var myIP = /([0-9]{1,3}(\.[0-9]{1,3}){3}|[a-f0-9]{1,4}(:[a-f0-9]{1,4}){7})/.exec(ice.candidate.candidate)[1];
          resolve(myIP);
          pc.onicecandidate = noop;
        };
      });
    }

    


    getMyIP().then(value => {
      this.state.ip = value;
      if(this.state.ip !== null || this.state.ip !== ''){
        const response = this.setIP();
        if(response){
          //window.location.href =  (window.location.origin === 'https://buddyuat.mx.att.com:16500' ? `${URLS.LOGIN_UAT}` : `${URLS.LOGIN}`);
          this.login(); //no lo ocupa saml
        }
      } else {
        window.location.href =  (window.location.origin === 'https://buddyuat.mx.att.com:16500' ? `${URLS.UAT}` : `${URLS.PROD}`);
      }
    }).catch(err => {
      console.log(err);
    });

  }

  componentDidMount() {
    this.mounted = true;
    window.scrollTo(0, 0);
  }
  componentWillUnmount() {
    this.mounted = false;
  }
  securSetState(data) {
    if (this.mounted) {
      this.setState(() => data);
    }
  }

  UNSAFE_componentWillMount() {
    //this.context.clearMe();
    this.logout();
  }

  async logout() {
    try {
      await Api.logout();
      this.context.clearMe();
    } catch (error) {
      this.context.clearMe();
    }
  }

  setStateValue(field, value) {
    this.securSetState({
      [field]: value,
      loginError: null
    });
  }

  onRequestSubmit(event) {
    event.preventDefault();
    event.stopPropagation();
    this.securSetState({
      requestExecuting: true
    });
    //this.login(); //no lo ocupa saml
  }

  async setIP() {
    try {
      const response = await Api.passIP(this.state.ip);
      return response;
    } catch (error) {
      console.log(error);
    }
  }

  async login() {
    try {
      const response = await Api.login(
        //this.state.email.trim(),
        //this.state.password
        "test@mx.att.com".trim(),
        "testpassword".trim()
      );

  
      this.onLoginSucceed(response);
    } catch (error) {
      this.onRequestFailed(error);
    }
  }

  onLoginSucceed(response) {
    this.securSetState({
      requestExecuting: false,
      loginError: null
    });
    this.getMe();
  }

  async getMe() {
    try {
      const response = await Api.getMe();
      this.onMeSucceed(response);
    } catch (error) {
      this.onRequestFailed(error);
    }
  }

  onMeSucceed(response) {
    this.securSetState({
      requestExecuting: false,
      loginError: null
    });
    this.context.setMe(response);

    MwHistory.replace(this.next);
  }

  onRequestFailed(error) {
    this.securSetState({
      requestExecuting: false,
      loginError: error
    });
    this.context.clearMe();
  }

  isFormValid() {
    return (
      this.state.email.trim() !== '' &&
      this.state.password !== '' &&
      this.isEmailValid()
    );
  }
  isEmailValid() {
    if (this.state.email.trim() !== '') {
      return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(this.state.email);
    }
    return true;
  }

  render() {
    const { clientSettings } = this.context;

    const mascot = require('assets/images/mascot.svg').default;
    const bg = require('assets/images/login.jpg').default;
    const bgStyle = {
      style: {
        backgroundSize: 'cover',
        backgroundImage: 'url(' + bg + ')',
        backgroundColor: '#7a8486'
      }
    };

    return (
      <div className={styles.Wrapper} style={bgStyle.style}>
        <div className={styles.Content}>
          <Grid container spacing={0} wrap='nowrap' alignItems='center'>
            <Grid item>
              <div className={styles.Left}>
                <div className={styles.Mascot}>
                  <img src={mascot} alt='Logo' />
                </div>
                <div
                  className={styles.Cmb}
                  style={{
                    fontFamily: 'proxima-nova, sans-serif',
                    fontWeight: 700
                  }}
                >
                  CUSTOMER
                  <br />
                  MANAGEMENT
                  <br />
                  BUDDY
                </div>
              </div>
            </Grid>
            <Grid item>
              <div className={styles.Right}>
                <img
                  src={clientSettings.logo}
                  alt='Logo'
                  className={styles.ClientLogo}
                />
                <div className={styles.Form}>
                  <div style={{ textAlign: 'center' }}>
                    <SubmitButton
                      disabled={this.state.requestExecutin}
                      label={`Clic aqui para iniciar sesion`}
                      onClick={this.getData}
                      isLoading={this.state.requestExecuting}
                    />
                  </div>
                </div>
              </div>
            </Grid>
          </Grid>
        </div>
        <Footer
          style={{ position: 'absolute', left: '2rem', bottom: '0rem' }}
        />
      </div>
    );
  }
}

export default withTranslation('common')(Login);
