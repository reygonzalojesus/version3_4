import React, { Component } from 'react';
import { STORAGE_VARS } from 'utils/Constants';
import * as MwHistory from 'utils/MwHistory';
import jwt_decode from "jwt-decode";

class Saml extends Component {
  componentDidMount() {
    this.mounted = true;
    const token = new URLSearchParams(this.props.location.search).get('token');
    if (token) {
      const expiration = new Date();
      expiration.setHours(expiration.getHours() + 4);
      document.cookie = `${STORAGE_VARS.TOKEN}=${token}; ${expiration};path=/; SameSite='Lax'`;
      sessionStorage.setItem(STORAGE_VARS.TOKEN, token);
      var decoded = jwt_decode(token);
      if(decoded['user'].ATTUID != null){
        sessionStorage.setItem(STORAGE_VARS.ATTUID, decoded['user'].ATTUID);
      }
      MwHistory.replace('/cco');
    }
  }
  render() {
    return <></>;
  }
}

export default Saml;
