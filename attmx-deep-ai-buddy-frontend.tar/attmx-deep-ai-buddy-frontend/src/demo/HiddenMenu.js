import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { clients } from 'demo/clients';
import { STORAGE_VARS } from 'utils/Constants';
import * as MwHistory from 'utils/MwHistory';
import * as Tenancy from 'utils/Tenancy';
import * as GamificationApi from 'gamification/api/endpoints';
import * as Api from 'deep/api/endpoints';
import Button from '@material-ui/core/Button';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import Divider from '@material-ui/core/Divider';
import FiberManualRecordIcon from '@material-ui/icons/FiberManualRecord';
import AppContext from 'deep/contexts/AppProvider';

class HiddenMenu extends Component {
  static contextType = AppContext;

  constructor(props) {
    super(props);
    this.state = {
      isLoading: true,
      theme: null,
      clientSettings: null,
      //me: null,
      isCustomizationMenuOpen: false,
      anchorEl: null,
      meGameKeys: null,
      showNotification: false,
      notificationType: null,
      notificationData: null
    };
    document.title = 'DEEP by BCG';
  }

  toggleGamification() {
    if (this.context.gamificationActive) {
      this.context.deactivateGamification();
    } else {
      this.context.activateGamification();
    }
    this.setState(() => ({
      isCustomizationMenuOpen: false
    }));
  }
  toggleNotification() {
    if (this.context.notificationActive) {
      this.context.deactivateNotification();
    } else {
      this.context.activateNotification();
    }
    this.setState(() => ({
      isCustomizationMenuOpen: false
    }));
  }
  clearGamificationHistory() {
    const me = this.context.me;
    if (Tenancy.isMonoTenant()) {
      sessionStorage.removeItem(STORAGE_VARS.AVATAR_DISCLAIMER);
    } else {
      const tenant = Tenancy.getTenant();
      sessionStorage.removeItem(tenant + '_' + STORAGE_VARS.AVATAR_DISCLAIMER);
    }
    this.clearMyGamification(me);
  }

  async clearMyGamification(me) {
    await GamificationApi.resetEvents(me.user.id);
    await Api.patchRemoveAvatar(me.user.id);
    this.setState(() => ({
      isCustomizationMenuOpen: false
    }));
    MwHistory.redirect('login');
  }

  openMonitoringTool() {
    MwHistory.open('/monitoring/analysis/overall-performance');
    this.setState(() => ({
      isCustomizationMenuOpen: false
    }));
  }

  render() {
    const { me, gamificationActive, notificationActive } = this.context;
    const isMonoTenant = Tenancy.isMonoTenant();

    const openMenu = (e) => {
      const target = e.currentTarget;
      this.setState(() => ({
        isCustomizationMenuOpen: true,
        anchorEl: target
      }));
    };
    const closeMenu = (e) => {
      this.setState(() => ({
        isCustomizationMenuOpen: false
      }));
    };

    const changeClient = (client) => () => {
      this.setState(() => ({
        isCustomizationMenuOpen: false
      }));
      MwHistory.clear();
      window.location.href = '/ccbuddy-app/' + client.code + '/login';
    };

    const toggleGamification = () => {
      this.toggleGamification();
    };
    const toggleNotification = () => {
      this.toggleNotification();
    };
    const openMonitoringTool = () => {
      this.openMonitoringTool();
    };

    return (
      <div
        style={{
          position: 'fixed',
          left: '0%',
          bottom: '5px',
          opacity: '0'
        }}
      >
        <Button
          aria-controls='simple-menu'
          aria-haspopup='true'
          variant='contained'
          onClick={openMenu}
          size='small'
        >
          Customization
        </Button>
        <Menu
          keepMounted
          open={this.state.isCustomizationMenuOpen}
          onClose={closeMenu}
          anchorEl={this.state.anchorEl}
        >
          <MenuItem onClick={toggleGamification}>
            <FiberManualRecordIcon
              style={{
                color: gamificationActive ? 'rgba(19, 174, 87, 1)' : '#000'
              }}
            />
            {gamificationActive && <>&nbsp;&nbsp;Turn Off Gamification</>}
            {!gamificationActive && <>&nbsp;&nbsp;Turn On Gamification</>}
          </MenuItem>
          <MenuItem onClick={toggleNotification}>
            <FiberManualRecordIcon
              style={{
                color: notificationActive ? 'rgba(19, 174, 87, 1)' : '#000'
              }}
            />
            {notificationActive && <>&nbsp;&nbsp;Turn Off Notification</>}
            {!notificationActive && <>&nbsp;&nbsp;Turn On Notification</>}
          </MenuItem>
          <Divider />
          {!isMonoTenant &&
            clients.map((client, index) => {
              if (client.show) {
                return (
                  <MenuItem onClick={changeClient(client)} key={client.id}>
                    <FiberManualRecordIcon
                      style={{
                        color:
                          sessionStorage.getItem(STORAGE_VARS.TENANT) ===
                          client.code
                            ? 'rgba(19, 174, 87, 1)'
                            : '#000'
                      }}
                    />
                    &nbsp;&nbsp;{client.type} - {client.name}
                  </MenuItem>
                );
              } else {
                return <MenuItem key={client.id} />;
              }
            })}
          <Divider />
          {me && (
            <MenuItem onClick={() => this.clearGamificationHistory()}>
              <FiberManualRecordIcon style={{ color: '#999999' }} />
              &nbsp;&nbsp;Reset Gamification Scenario
            </MenuItem>
          )}
          {me && (
            <MenuItem onClick={openMonitoringTool}>
              <FiberManualRecordIcon style={{ color: '#999999' }} />
              &nbsp;&nbsp;Open Monitoring Dashboard
            </MenuItem>
          )}
        </Menu>
      </div>
    );
  }
}

export default withTranslation('common')(HiddenMenu);
