//Mockup static data
import logo_att from './logos/att.png';
export let fetched = false;
export let clients = [];

export function setClients(results) {
  clients = results.map((client) => ({
    id: client.slug,
    code: client.slug,
    type: 'Industry',
    show: true,
    name: client.name,
    //logo: client.logo || logo_deep,
    // Stopgap for demos until asset hosting happens
    logo: logo_att,
    currency: '$',
    colors: {
      primary: client.primary_color,
      secondary: client.secondary_color
    },
    languages: [
      {
        key: 'es',
        name: 'Español'
      },
      {
        key: 'en',
        name: 'English'
      }
    ]
  }));

  fetched = true;
}
