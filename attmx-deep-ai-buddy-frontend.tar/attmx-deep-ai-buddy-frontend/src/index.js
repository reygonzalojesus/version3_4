import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import { BrowserRouter } from 'react-router-dom';
import { I18nextProvider } from 'react-i18next';
import { STORAGE_VARS } from 'utils/Constants';
import i18next from 'i18next';
import common_en from './translations/en/common.json';
import cco_en from './translations/en/cco.json';
import gamification_en from './translations/en/gamification.json';
import notification_en from './translations/en/notification.json';
import common_fr from './translations/fr/common.json';
import cco_fr from './translations/fr/cco.json';
import gamification_fr from './translations/fr/gamification.json';
import notification_fr from './translations/fr/notification.json';
import common_de from './translations/de/common.json';
import cco_de from './translations/de/cco.json';
import gamification_de from './translations/de/gamification.json';
import notification_de from './translations/de/notification.json';
import common_es from './translations/es/common.json';
import cco_es from './translations/es/cco.json';
import gamification_es from './translations/es/gamification.json';
import notification_es from './translations/es/notification.json';
import * as Api from 'deep/api/endpoints';
import { setClients } from 'demo/clients';

Api.getTenants().then((results) => {
  setClients(results);

  const cookies = Object.fromEntries(
    document.cookie.split(';').map((e) => e.split('=').map((s) => s.trim()))
  );
  sessionStorage.setItem(STORAGE_VARS.TOKEN, cookies[STORAGE_VARS.TOKEN]);

  i18next.init({
    fallbackLng: 'es',
    interpolation: { escapeValue: false }, // React already does escaping
    react: {
      useSuspense: false
    },
    lng: sessionStorage.getItem(STORAGE_VARS.LANGUAGE)
      ? sessionStorage.getItem(STORAGE_VARS.LANGUAGE)
      : 'es',
    resources: {
      en: {
        common: common_en,
        cco: cco_en,
        gamification: gamification_en,
        notification: notification_en
      },
      fr: {
        common: common_fr,
        cco: cco_fr,
        gamification: gamification_fr,
        notification: notification_fr
      },
      de: {
        common: common_de,
        cco: cco_de,
        gamification: gamification_de,
        notification: notification_de
      },
      es: {
        common: common_es,
        cco: cco_es,
        gamification: gamification_es,
        notification: notification_es
      }
    }
  });

  ReactDOM.render(
    //<React.StrictMode>
    <BrowserRouter>
      <I18nextProvider i18n={i18next}>
        <App />
      </I18nextProvider>
    </BrowserRouter>,
    //</React.StrictMode>,
    document.getElementById('root')
  );

  // If you want your app to work offline and load faster, you can change
  // unregister() to register() below. Note this comes with some pitfalls.
  // Learn more about service workers: https://bit.ly/CRA-PWA
  serviceWorker.unregister();
});
