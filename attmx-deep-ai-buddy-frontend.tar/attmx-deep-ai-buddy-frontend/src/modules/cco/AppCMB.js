import React, { Component} from 'react';
import { MuiThemeProvider } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import AppContext, { AppProvider } from 'deep/contexts/AppProvider';
import { GamificationProvider } from 'gamification/contexts/GamificationProvider';
import { CallSessionProvider } from 'modules/cco/contexts/CallSessionProvider';
import Routes from 'utils/Routes';
import Header from 'deep/components/Header';

import Notifications from 'notifications/Notifications';
//
import Modal from 'deep/components/Modal';
import styled from 'styled-components';

const Boton = styled.button`
    display:block;
    padding: 10px 30px;
    border:0px;
    border-radius:100px;
    color:#fff;
    background:#1766DC;
    cursor: pointer;
    font-family: 'Roboto',sans-serif;
    font-weight:500;
    transition: .3s ease all;
    &:hover{
      backgraund: #0066FF;
    }

`;
//

class AppCMB extends Component {

  render() {

    return (
      <AppProvider>
        <AppContext.Consumer>
          {(appContext) => (
            <MuiThemeProvider theme={appContext.theme}>
              <CssBaseline />
              <GamificationProvider appContext={appContext}>
                <CallSessionProvider appContext={appContext}>
                  {appContext.notificationActive && <Notifications />}
                  <Header />
                  <Routes />
                  {/* <HiddenMenu /> */}
                </CallSessionProvider>
              </GamificationProvider>
            </MuiThemeProvider>
          )}
        </AppContext.Consumer>
        <Modal
           estado= {false} 
           cambiarEstado = {true}
        >
          <h1>Ventana Modal</h1>
          <p>Reutilizable</p>
           <Boton>Aceptar</Boton>
        </Modal>
      </AppProvider>
    );
  }
}

export default AppCMB;
