import React,{useState} from 'react';
import styled from 'styled-components';
import Modal from 'deep/components/Modal';

const AppModalWindows = ({state,message,clearInputId,clearInputDN,showButtonStart,clearInputDNF,IsRedirect}) => {
    const [estadoModal1,cambiarEstadoModal1] = useState(state);
	const clearInputId1 = '';
	const clearInputDN1 = '';
	const showButtonStart1= showButtonStart;


	return (
		<div>
            <Modal
            estado={estadoModal1}
            cambiarEstado={cambiarEstadoModal1}
			clearInputId={clearInputId1}
			clearInputDN={clearInputDN1}
			showButtonStart={showButtonStart1}
			clearInputDNF={clearInputDN1}
            >
                <Contenido>
                    <p>{message}</p>
                    <Boton  onClick={() => cambiarEstadoModal1(!state)  }>Aceptar</Boton>
                </Contenido>
            </Modal>

		</div>
	);
}

export default AppModalWindows;

const Boton = styled.button`
	display: block;
	padding: 10px 30px;
	border-radius: 100px;
	color: #fff;
	border: none;
	background: #00A8E0;
	cursor: pointer;
	font-family: 'Roboto', sans-serif;
	font-weight: 500;
	transition: .3s ease all;
	&:hover {
		background: #00A8E0;
	}
	z-index: 1000;
`;

const Contenido = styled.div`
	display: flex;
	flex-direction: column;
	align-items: center;
	h1 {
		font-size: 42px;
		font-weight: 700;
		margin-bottom: 0px;
	}
	p {
		font-size: 18px;
		margin-bottom: 20px;
		
	}
	img {
		width: 100%;
		vertical-align: top;
		border-radius: 3px;
	}
	z-index: 1000;
`;