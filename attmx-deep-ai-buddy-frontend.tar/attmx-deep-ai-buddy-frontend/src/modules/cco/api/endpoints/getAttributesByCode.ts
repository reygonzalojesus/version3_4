/**
 * Get a listing of Customer Attributes, filtering by campaign, the customer ID, and the code of the attribute type,
 * ex. 'profile'
 *
 * @param customerId The ID of the customer for whom the attributes are relevant
 * @param campaignTypeId The ID of the campaign type
 * @param code The code of the attribute type, ex. 'profile' or 'portfolio'
 */
import * as MwHistory from 'utils/MwHistory';
import CustomerAttribute from "../../../../types/customerAttribute";
import {getRequest} from "../../../../deep/api/utils";

export default function getAttributesByCode(customerId: string | number, code: string,
                                            campaignTypeId?: string | number): Promise<CustomerAttribute[]> {
    let endpoint =
        `cco/customer_value?customer=${customerId}&attribute__category__code=${code}&attribute__customerattributevisibility=visible=true`;
    if (campaignTypeId) {
        endpoint += `&attribute__customerattributevsibility__campaign_type=${campaignTypeId}`;
    }
    return new Promise((resolve, reject) => {
        getRequest(endpoint).then((res) => {
            resolve(res.results as CustomerAttribute[]);
        }).catch((error) => {
            switch (error.status) {
                case 403:
                    reject(error.status);
                    MwHistory.replace('/403');
                    break;
                default:
                    reject('error.customer-data-unavailable');
                    break;
            }
        });
    });
}