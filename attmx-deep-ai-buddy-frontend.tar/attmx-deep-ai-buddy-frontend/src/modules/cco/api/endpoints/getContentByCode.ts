import Content from "../../../../types/content";
import {getRequest} from "../../../../deep/api/utils";

export default function getContentByCode(contentCode: string): Promise<Content> {
    const endpoint = 'cco/discovery_content?code='+contentCode;

    return new Promise((resolve, reject) => {
            getRequest(endpoint).then((res) => {
                resolve(res.results[0].content as Content);
            }).catch((err) => {
                reject(err);
            })
    })
}