import Customer from "../../../../types/customer";
import { getRequest } from '../../../../deep/api/utils';
import * as MwHistory from 'utils/MwHistory';


/**
 * Fetch a customer from the API, by ID
 *
 * @param customerId The ID of the customer to fetch
 */
export default function getCustomer(customerId: string): Promise<Customer> {
    const endpoint = 'cco/customer/' + customerId;

    return new Promise((resolve, reject) => {
        getRequest(endpoint)
            .then((result) => {
                resolve(result as Customer);
            })
            .catch((error) => {
                switch (error.status) {
                    case 403:
                        reject(error.status);
                        MwHistory.replace('/403');
                        break;
                    default:
                        reject('error.customer-404');
                        break;
                }
            });
        });
}