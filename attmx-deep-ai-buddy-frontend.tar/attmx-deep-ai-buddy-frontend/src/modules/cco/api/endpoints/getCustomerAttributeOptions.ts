import { getRequest } from "../../../../deep/api/utils";
import AttributeOption from "../../../../types/attributeOption";



export default function getCustomerAttributeOptions(): Promise<AttributeOption[]> {
    let endpoint = 'cco/customerattribute?limit=10000';

    return new Promise((resolve, reject) => {

        getRequest(endpoint).then((resp) => {
            resolve(resp.results as AttributeOption[]);
        })
    });
}