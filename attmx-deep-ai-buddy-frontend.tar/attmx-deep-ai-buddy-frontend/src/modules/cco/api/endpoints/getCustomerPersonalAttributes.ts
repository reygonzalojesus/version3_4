import CustomerAttribute from "../../../../types/customerAttribute";
import getAttributesByCode from "./getAttributesByCode";

export default function getCustomerPersonalAttributes(customerId: string | number,
                                                      campaignTypeId?: string | number): Promise<CustomerAttribute[]> {
    return getAttributesByCode(customerId, "profile", campaignTypeId);
}
