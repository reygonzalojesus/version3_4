import TrafficShare from "../../../../types/trafficShare";
import {getRequest} from "../../../../deep/api/utils";

export default function getDataUsage(customerId: string | number): Promise<TrafficShare> {
    return new Promise((resolve, reject) => {
        getRequest(`cco/datausage/${customerId}`).then((resp) => {
            resolve(resp as TrafficShare);
        }).catch((err) => reject(err))
    })
}
