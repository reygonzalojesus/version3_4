import Incident from "../../../../types/incident";
import {getRequest} from "../../../../deep/api/utils";

export default function getIncidentsBySubscriber(subscriberId: number): Promise<Incident[]> {
    const endpoint = `cco/incident?subscriber__id=${subscriberId}`;
    return new Promise((resolve, reject) => {
        getRequest(endpoint).then((result) => {
            resolve(result.results as Incident[]);
        })
    })
}