import OfferLadderOffers from '../../../../types/offerLadderOffers';
import { getRequest } from '../../../../deep/api/utils';

export default function getOffersByCustomer(
  customerId: string | number
): Promise<OfferLadderOffers[]> {
  return new Promise((resolve, reject) => {
    // Start by finding the offerladder with the matching opportunity ID
    const offerladderendpoint = `cco/ladderoffersbycustomer/${customerId}`;
    getRequest(offerladderendpoint).then((res) => {
      resolve(res.results as OfferLadderOffers[]);
    });
  });
}
