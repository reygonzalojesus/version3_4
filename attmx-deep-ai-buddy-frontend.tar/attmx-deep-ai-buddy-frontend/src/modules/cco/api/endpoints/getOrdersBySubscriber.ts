import {getRequest} from "../../../../deep/api/utils";
import Order from "../../../../types/order";

export default function getOrdersBySubscriber(subscriberId: number): Promise<Order[]> {
    const endpoint = `cco/order?subscriber__id=${subscriberId}`;
    return new Promise((resolve, reject) => {
        getRequest(endpoint).then((result) => {
            resolve(result.results as Order[]);
        })
    })
}