import Order from "../../../../types/order";
import Incident from "../../../../types/incident";
import ContractSubscriber from "../../../../types/contractSubscriber";
import Payment from "../../../../types/payment";
import {getRequest} from "../../../../deep/api/utils";

export interface OrdersIncidents {
    orders: Order[];
    incidents: Incident[];
    payments: Payment[];
    subscribers: ContractSubscriber[];
}

export default function getOrdersIncidentsBillsForCustomer(customerId: string | number): Promise<OrdersIncidents> {
    const endpoint = `cco/ordersincidentsbillsforcustomer/${customerId}`
    return new Promise((resolve, reject) => {
        getRequest(endpoint).then((res) => {
            resolve(res as OrdersIncidents)
        })
    })
}