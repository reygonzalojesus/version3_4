import ProactiveOpportunity from "../../../../types/proactiveOpportunity";
import {getRequest} from "../../../../deep/api/utils";
import * as MwHistory from 'utils/MwHistory';

export function getProactiveOpportunities(limit: number = 1000): Promise<ProactiveOpportunity[]> {
    const endpoint = 'cco/opportunity/proactive?limit=' + limit;

    return new Promise((resolve, reject) => {
        getRequest(endpoint)
            .then((result) => {
                // Dedupe customers in opportunities
                const rawOpportunities = result.results as ProactiveOpportunity[];
                let customersSeen = new Set();
                let resolvedOpportunities: ProactiveOpportunity[] = []
                rawOpportunities.forEach((r) => {
                    if (!(customersSeen.has(r.customer.id))) {
                        resolvedOpportunities.push(r);
                        customersSeen.add (r.customer.id);
                    }
                })
                resolve(resolvedOpportunities);
            })
            .catch((error) => {
                switch (error.status) {
                    case 403:
                        reject(error.status);
                        MwHistory.replace('/403');
                        break;
                    default:
                        reject('error.customer-data-unavailable');
                        break;
                }
            })
    });

}