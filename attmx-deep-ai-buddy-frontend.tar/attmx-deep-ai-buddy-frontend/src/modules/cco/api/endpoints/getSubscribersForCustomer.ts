import ContractSubscriber from "../../../../types/contractSubscriber";
import {getRequest} from "../../../../deep/api/utils";
import Contract from "../../../../types/contract";

export default function getSubscribersForCustomer(customerId: string | number): Promise<ContractSubscriber[]> {
    const endpoint = `cco/contract?customer__id=${customerId}`;
    return new Promise((resolve, reject) => {
        getRequest(endpoint).then((r) => {
            const contracts = r.results as Contract[];
            let subscribers: ContractSubscriber[] = [];
            let seenSubscribers = new Set();
            contracts.forEach((c) => {
                if (!seenSubscribers.has(c.subscriber.id)) {
                    subscribers.push(c.subscriber);
                }
            })
            resolve(subscribers);
        }).catch((e) => reject(e))
    })

}