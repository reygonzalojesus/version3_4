import { postRequest } from '../../../../deep/api/utils';

interface SessionFeedbackOffers {
  outcome: string;
  comment?: string;
}

export interface SessionFeedbackData {
  started: number;
  opportunity: number;
  customer: number;
  offers: { [offerId: number]: SessionFeedbackOffers };
  comment?: string;
}

export default function submitSessionFeedback(
  data: SessionFeedbackData
): Promise<void> {
  const endpoint = 'cco/feedback';
  return postRequest(endpoint, data);
}
