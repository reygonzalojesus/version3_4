import * as FormatTrans from 'deep/api/formatTransModels';

export function customerAttributes(data) {
  let dataTranslated = [];
  data.forEach((item) => {
    dataTranslated.push(FormatTrans.customerAttribute(item));
  });
  return dataTranslated;
}

export function contracts(data) {
  let dataTranslated = [];
  data.forEach((item) => {
    dataTranslated.push(FormatTrans.contract(item));
  });
  return dataTranslated;
}

export function feedbacks(data) {
  let dataTranslated = [];
  data.forEach((item) => {
    dataTranslated.push(FormatTrans.feedback(item));
  });
  return dataTranslated;
}

export function campaigns(data) {
  let dataTranslated = [];
  data.forEach((item) => {
    dataTranslated.push(FormatTrans.campaign(item));
  });
  return dataTranslated;
}

export function opportunities(data) {
  let dataTranslated = [];
  data.forEach((item) => {
    dataTranslated.push(FormatTrans.opportunity(item));
  });
  return dataTranslated;
}

export function dataDrivenTips(data) {
  let dataTranslated = [];
  data.forEach((item) => {
    dataTranslated.push(FormatTrans.dataDrivenTip(item));
  });
  return dataTranslated;
}

export function reasons(data) {
  let dataTranslated = [];
  data.forEach((item) => {
    dataTranslated.push(FormatTrans.reason(item));
  });
  return dataTranslated;
}

export function outcomes(data) {
  let dataTranslated = [];
  data.forEach((item) => {
    dataTranslated.push(FormatTrans.outcome(item));
  });
  return dataTranslated;
}

export function products(data) {
  let dataTranslated = [];
  data.forEach((item) => {
    dataTranslated.push(FormatTrans.product(item));
  });
  return dataTranslated;
}

export function productsfeatures(data) {
  let dataTranslated = [];
  data.forEach((item) => {
    dataTranslated.push(FormatTrans.productFeature(item));
  });
  return dataTranslated;
}

export function interactions(data) {
  let dataTranslated = [];
  data.forEach((item) => {
    dataTranslated.push(FormatTrans.interaction(item));
  });
  return dataTranslated;
}

export function proactiveOpportunities(data) {
  let dataTranslated = [];
  data.forEach((item) => {
    dataTranslated.push({
      ...item,
      offer: FormatTrans.offer(item.offer),
      contracts: contracts(item.contracts),
      campaign_type: FormatTrans.campaignType(item.campaign_type),
      product: FormatTrans.product(item.product)
    });
  });
  return dataTranslated;
}

export function dataCollection(data) {
  return data.map(FormatTrans.collectionQuestion);
}

export function quarantine(data) {
  return data.map(FormatTrans.quarantine);
}

export function customerPromotions(data) {
  let dataTranslated = [];
  data.forEach((item) => {
    dataTranslated.push(FormatTrans.customerPromotions(item));
  });
  return dataTranslated;
}
