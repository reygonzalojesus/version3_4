import React from 'react';

export default function CCOLogo(props) {
  return (
    <>
      {props.size === 'large' && (
        <div
          style={{ fontFamily: 'proxima-nova, sans-serif', color: '#414343' }}
        >
          <div
            style={{
              fontSize: '11em',
              fontWeight: 700,
              lineHeight: '0.75',
              float: 'left'
            }}
          >
            O
          </div>
          <div
            style={{
              fontSize: '4.8em',
              fontWeight: 900,
              lineHeight: '0.90',
              letterSpacing: 2
            }}
          >
            UTBOUND
          </div>
          <div
            style={{
              fontSize: '4em',
              fontWeight: 400,
              lineHeight: '0.95',
              letterSpacing: 2
            }}
          >
            BUDDY
          </div>
        </div>
      )}
      {props.size === 'small' && (
        <div
          style={{
            fontFamily: 'proxima-nova, sans-serif',
            color: '#414343',
            marginLeft: '1rem',
            marginTop: '0.3rem'
          }}
        >
          <div
            style={{
              fontSize: '2.6rem',
              fontWeight: 600,
              lineHeight: '0.75',
              position: 'absolute'
            }}
          >
            O
          </div>
          <div
            style={{
              fontSize: '1rem',
              fontWeight: 800,
              lineHeight: '1',
              letterSpacing: 1,
              marginLeft: '2.1rem'
            }}
          >
            UTBOUND
          </div>
          <div
            style={{
              fontSize: '1rem',
              fontWeight: 300,
              lineHeight: '1',
              letterSpacing: 1,
              marginLeft: '2.1rem'
            }}
          >
            BUDDY
          </div>
        </div>
      )}
    </>
  );
}
