import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import * as MwHistory from 'utils/MwHistory';
import SubmitButton from 'deep/components/materials/SubmitButton';
import PhoneInput from 'deep/components/materials/PhoneInput';
import IdInput from 'deep/components/materials/IdInput';
import getCustomer from "modules/cco/api/endpoints/getCustomerById";
import * as CcoApi from './../api/endpoints';
import AppModal from 'modules/cco/AppModal';
import * as MainMenu from 'deep/components/MainMenu';
const _DEBOUNCE_AMOUNT = 400;

class StartCall extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loadingID: false,
      loadingDN: false,
      error: null,
      inputKeyword: '',
      validKeyword: '',
      inputKeywordID:'',
      inputKeywordDN:'',
      searchResults: null,
      showButtonID: false,
      showButtonDN: false,
      IsRedirect: false
    };
    this.handleKeywordChangeDN = this.handleKeywordChangeDN.bind(this);
    this.handleKeywordChangeID = this.handleKeywordChangeID.bind(this);
    this.handleSearchSubmit = this.handleSearchSubmit.bind(this);
  }

  componentDidMount() {
    this.mounted = true;
  }
  componentWillUnmount() {
    this.mounted = false;
  }
  securSetState(data) {
    if (this.mounted) {
      this.setState(() => data);
    }
  }

  handleKeywordChangeDN(value) {
    if(parseInt(value.length) <= 10)
    {
      this.securSetState({
        inputKeyword: value,
        searchCustomerID: null,
        searchSubsriberId: null,
        searchResults: null
      });
    }
    if(value.length === 10)
    {
       this.debounceCustomerSearchClientDN(value);
    }
  }
  debounceCustomerSearchID(value) {
    const currTimestamp = Date.now();
    this.setState({ lastInput: currTimestamp });
    setTimeout(() => {
      if (this.state.lastInput === currTimestamp) {
        this.searchCustomerClientID(value);
      }else{
        this.searchCustomerClientID(value); 
      }
    }, _DEBOUNCE_AMOUNT);
  }
  debounceCustomerSearchClientDN(value) {
    const currTimestamp = Date.now();
    this.setState({ lastInput: currTimestamp });
    setTimeout(() => {
      if (this.state.lastInput === currTimestamp) {
        this.searchCustomer(value);
      } 
    }, _DEBOUNCE_AMOUNT);
  }    
  onSearchCustomerSucceedDN(results) {
    this.securSetState({
      loadingID: false,
      loadingDN: true,
      error: false,
      searchResults: results,
      showButtonDN : results.length === 0? false: results[0].muestraModal['enableButton'] === false? false : true,
      inputKeyword: results.length === 0? "": results[0].muestraModal['showModal'] === true?  '' : this.state.inputKeyword,
    });
    this.setState({
      inputKeyword : this.state.inputKeyword.length <= 10? this.state.inputKeyword : '',
      searchSubsriberId : results[0]['ContracSubscriber_id'],
      searchCustomerID : results[0]['id'],
      IsRedirect :  results.length === 0? false: results[0].muestraModal['isRedirect']
    });
    const timer = setTimeout(() => {
      this.securSetState({
        loadingID: false,
        loadingDN: false});
    }, 500);
   
  }
  onSearchCustomerSucceedID(results) {
    this.securSetState({
      loadingID: true,
      loadingDN:false,
      error: false,
      searchResults: results,
      showButtonID : results.length === 0? false: results[0]['showButton'] === false? false : true,
      IsRedirect: results.length === 0? false: results[0].muestraModal['isRedirect'],
      inputKeywordID: ''
    });
    this.setState({
    searchSubsriberId : results[0]['ContracSubscriber_id'],
    searchCustomerID : results[0]['id']
    });
    const timer = setTimeout(() => {
      this.securSetState({
        loadingID: false,
        loadingDN: false});
    }, 1000);
  }
  async searchCustomer(inputKeyword) {
    if (inputKeyword.trim() === '') {
      this.securSetState({
        searchResults: null,
        searchCustomerID: null,
        searchSubsriberId: null
      });
    } else {
      try {
        //CODIGO PARA VALIDAR 
        const results = await CcoApi.searchCustomerDN(inputKeyword);
        this.onSearchCustomerSucceedDN(results);
        this.redirect();
        this.securSetState({inputKeywordDN:"",
        inputKeyword: ""
      });

      } catch (error) {
        if (error.status === 403) {
          this.props.onClose(); 
        } else {
          this.securSetState({
            loadingID: false,
            loadingDN:false,
            error: null
          });
        }
      }
    }
  }
  
  async searchCustomerClientID(inputKeywordID) {
    if (inputKeywordID.trim() === '') {
      this.securSetState({
        searchResults: null,
        searchCustomerID: null,
        searchSubsriberId: null
      });
    } else {
      try {
        const results = await CcoApi.searchCustomerClient(inputKeywordID);
        this.onSearchCustomerSucceedID(results);
        this.redirect();
        this.securSetState({inputKeywordID:""
      });
        
      } catch (error) {
        if (error.status === 403) {
          this.props.onClose(); 
        } else {
          this.securSetState({
            loadingID: false,
            loadingDN:false,
            error: error
          });
        }
      }
    }
  }
  handleKeywordChangeID(value) {
    if(value.length <= 13)
    {
      this.securSetState({
        inputKeywordID: value,
        searchCustomerID: null,
        searchSubsriberId: null,
        searchResults: null
      });
      this.debounceCustomerSearchID(value);
    }
  }
  highlightResult(data, keyword) {
    const search = keyword.toLowerCase();
    if (data !== undefined){
        const aData = data.toLowerCase().split(search);
        let hiData = [];
        if (aData[0] !== '') {
          hiData.push(<span key={0}>{aData[0]}</span>);
        }
        for (let i = 1; i < aData.length; i++) {
         hiData.push(
          <span key={i}>
            <span style={{ fontWeight: 700 }}>{keyword}</span>
            {aData[i]}
          </span>
         );
         }
        return hiData;
    }
  }
  formatSearchResults(data, keyword) {
    if (!data) {
      return false;
    }

    return data.map((item) => ({
      customerId: item.customer.id,
      subscriberId: item.id,
      namestr: item.customer.firstname + ' ' + item.customer.lastname,
      name: (
        <>
          {this.highlightResult(item.customer.firstname, keyword)}&nbsp;
          {this.highlightResult(item.customer.lastname, keyword)}
        </>
      ),
      idstr: (
        <>
          {this.highlightResult(
            item.customer.src_client_id.toString(),
            keyword
          )}
        </>
      ),
      mdn: <>{this.highlightResult(item.customer.phone_number, keyword)}</>
    }));
  }
  handleSearchSubmit(event) {
    event.preventDefault();
    event.stopPropagation();
    if (this.state.inputKeyword !== '' || this.state.inputKeywordID !== '') {
      this.securSetState({
        loadingID: true,
        loadingDN:false,
        validKeyword: this.state.inputKeywordID
      });
      if (this.mounted) {
        this.loadData();
      }
    } else {
      this.securSetState({
        customers: [],
        loadingID: false
      });
    }
  }

  async loadData() {
    const validKeyword = this.state.inputKeyword;
    const validKeywordID = this.state.inputKeywordID;

    try {
      const result = await getCustomer(validKeyword,validKeywordID);
      this.onLoadDataSucceed(result);
    } catch (error) {
      if (error.status === 403) {
        this.props.onClose();
      } else {
        this.securSetState({
          loadingID: false
        });
      }
    }
  }

  async onLoadDataSucceed(customer){
    try {
      const result = await CcoApi.searchCustomerDN(customer.phone_number);

      this.securSetState({
        loadingID: false
      });
      this.props.onStart();
      MwHistory.push(
        '/cco/session/' +
          customer.id +
          '/' +
          result[0].id
      );
  
          
      const currentRoute = MwHistory.getCurrentRoute();
      if (currentRoute.path.indexOf('/cco/session/') > -1) {
        MwHistory.go();
      }
    } catch (error) {
      if (error.status === 403) {
        this.props.onClose();
      } else {
        this.securSetState({
          loadingID: false,
          error: error
        });
      }
    }
  };

  render() {


  // Method for valid
  const contract = this.state.searchResults
  const thisInput = this.state.inputKeyword !== ''? this.state.inputKeyword : this.state.inputKeywordID
  const results = this.formatSearchResults(
    this.state.searchResults,
    thisInput
  );
  //
    return (
      <div >
        <div style={{ width: 'max-content', margin: '0rem auto' }}>
          <IdInput
            defaultValue=''
            autoFocus={false}
            placeholder={this.props.t('startcall.ph-id')}
            error={false}
            valid={this.state.inputKeywordID !== ''}
            value={this.state.inputKeywordID}
            type={'text'}
            min={'9'}
            maxLength={'12'}
            onChange={(value) => this.handleKeywordChangeBasic(value)}//this.handleKeywordChangeID(value)}
            size={this.props.size}
            style={{
              width: this.props.inputWidth,
              maxWidth: '100%',
              margin: '0rem 1rem 1rem 0rem'
            }}
          />

          <span style={{ margin: '0rem 1rem 0rem 0rem' }}>

            <SubmitButton
              disabled={this.state.inputKeywordID == ""}//{this.state.showButtonID === false}
              label={this.props.t('startcall.bt-start')}
              isLoading={this.state.loadingID}
              type='submit'
              size={this.props.size}
              onClick={(thisInputs) =>  this.selectDN(thisInput)}
            />
          </span>

          <div>
        <PhoneInput
            defaultValue=''
            autoFocus={false}
            placeholder={this.props.t('startcall.search-dn')}
            error={false}
            valid={this.state.inputKeyword !== ''}
            value={this.state.inputKeyword}
            type={'text'}
            onChange={(value) => this.handleKeywordChangeBasicDN(value)}//this.handleKeywordChangeDN(value)}
            size={this.props.size}
            min={'10'}
            maxLength={'10'}
            style={{
              width: this.props.inputWidth,
              maxWidth: '100%',
              margin: '0rem 1rem 1rem 0rem'
            }}
          />
                  <span style={{ margin: '0rem 1rem 0rem 0rem' }}>

<SubmitButton
  disabled={this.state.inputKeyword === ''}//{this.state.showButtonDN === false}
  label={this.props.t('startcall.bt-start')}
  isLoading={this.state.loadingDN}
  type='submit'
  size={this.props.size}
  onClick={(thisInputs) =>  this.handleKeywordChangeDN(thisInput)}
/>

</span>

{results && results.length === 0  &&(
  <AppModal state={true} message={'Consulta la linea en CRM y asigna una promoción manual de acuerdo a las reglas de Negocio.'}
           clearInputId={this.state.inputKeywordID = ''}
           clearInputDN={this.state.inputKeywordDNValue= ""} 
           showButtonStart ={this.state.showButton=false} 
           clearInputDNF={this.state.inputKeyword = ""}
          ></AppModal>
          )}
         {contract && contract.length > 0 && contract[0].muestraModal['showModal'] === true  &&(
         <AppModal state={true}  message={contract[0].muestraModal['message']} 
           clearInputId={this.state.inputKeywordID = ""}
           clearInputDN={this.state.inputKeywordDNValue = ""}
           showButtonStart ={this.state.showButton=contract[0].muestraModal['enableButton']}
           clearInputDNF={this.state.inputKeyword = ""}
           IsRedirect= {this.state.IsRedirect = contract[0].muestraModal['isRedirect']}
          ></AppModal>
          )}      
     
        </div>
        </div>

      </div>
    );
  }

  selectDN(value){
    if(this.state.inputKeywordID !== ''){
      this.handleKeywordChangeIDV2(value);
      this.redirect();
    }
    if(this.state.inputKeywordDN !== ''){
      this.redirect();
    }
  }

  redirect() {
    var URLactual = window.location.pathname;
    if(this.state.IsRedirect === true){
    MwHistory.redirect(
      '/cco/session/' +
        this.state.searchCustomerID +
        '/' +
        this.state.searchSubsriberId
    );
    }
  }
  handleKeywordChangeIDV2(value) {
    if(value.length >= 1)
    {
      this.securSetState({
        inputKeywordID: value,
        IsSearchDN: false,
        IsSearchID: true,
        searchCustomerID: null,
        searchSubsriberId: null,
        searchResults: null,
        showButton: true
      });
      this.debounceCustomerSearchID(value);
    }
  }

  handleKeywordChangeBasic(value) {
    this.state.inputKeywordID = value;
    this.securSetState({
      inputKeywordID: value,
      IsSearchDN: false,
      IsSearchID: true,
      searchCustomerID: null,
      searchSubsriberId: null,
      searchResults: null,
      //showButton: true,
      showButtonID: true
    });
  }

  handleKeywordChangeBasicDN(value) {
    //this.state.inputKeywordDN = value;
    this.securSetState({
      inputKeyword: value,
      inputKeywordDN: value,
      IsSearchDN: true,
      IsSearchID: false,
      searchCustomerID: null,
      searchSubsriberId: null,
      searchResults: null,
      //showButton: true,
      showButtonDN: value.length === 10? true:false
    });
    //this.handleKeywordChangeDN(value);
    
  }

   refreshPage(bool) {
    window.location.reload(bool);
  }

}


export default withTranslation('cco')(StartCall);
