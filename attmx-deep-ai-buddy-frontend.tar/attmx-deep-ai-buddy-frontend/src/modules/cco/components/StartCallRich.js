import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import * as MwHistory from 'utils/MwHistory';
import SubmitButton from 'deep/components/materials/SubmitButton';
import BasicInput from 'deep/components/materials/BasicInput';
import PhoneInput from 'deep/components/materials/PhoneInput';
import IdInput from 'deep/components/materials/IdInput';
import Box from '@material-ui/core/Box';
import * as CcoApi from './../api/endpoints';
import getCustomer from 'modules/cco/api/endpoints/getCustomer';
import CCOTabs from './../components/CCOTabs';
import Paper from '@material-ui/core/Paper';
import SmallDataTable from 'deep/components/materials/SmallDataTable';
import AppModal from 'modules/cco/AppModal';
// In milliseconds, the amount of time to debounce the search


const _DEBOUNCE_AMOUNT = 400;


class StartCallRich extends Component {
  
  constructor(props) {
    super(props);
    this.state = {
      error: null,
      loading: false,
      inputID: '',
      validID: '',
      inputKeyword: '',
      inputKeywordID: '',
      inputKeywordDN:'',
      inputKeywordDNValue:'',
      searchResults: null,
      searchCustomerID: null,
      selectedTab: 0,
      lastInput: null,
      inputType: 'number',
      showButton: false,
      IsSearchDN: false,
      IsSearchID: false,
      message: 'No existe en la base de datos',
      existDB: false,
      showModal: false,
      onlynumber: true,
      IsRedirect: false
    };
    this.handleIDChange = this.handleIDChange.bind(this);
    this.handleIDSubmit = this.handleIDSubmit.bind(this);
    this.handleKeywordSubmit = this.handleKeywordSubmit.bind(this);
    
  }
  componentDidMount() {
    this.mounted = true;
  }
  componentWillUnmount() {
    this.mounted = false;
  }
  securSetState(data) {
    if (this.mounted) {
      this.setState(() => data);
    }
  }

  handleIDChange(value) {
    this.securSetState({
      inputID: value,
      error: null
    });
  }
  handleIDSubmit(event) {
    event.preventDefault();
    event.stopPropagation();
    
    if (this.state.inputID !== '') {
      this.securSetState({
        loading: true,
        validID: this.state.inputID
      });
      if (this.mounted) {
        this.loadCustomer();
      }
    } else {
      this.securSetState({
        customers: [],
        loading: false
      });
    }
  }

  async loadCustomer() {
    const validID = this.state.inputID;

    try {
      const result = await getCustomer(validID);
      this.onLoadCustomerSucceed(result);
    } catch (error) {
      if (error.status === 403) {
        this.props.onClose();
      } else {
        this.securSetState({
          loading: false,
          error: error
        });
      }
    }
  }
  onLoadCustomerSucceed(customer) {
    this.securSetState({
      loading: false,
      error: false
    });
    this.props.onStart();
    MwHistory.replace('/cco/session/' + customer.id);
  }


  //BASIC HANDLER

  handleKeywordChangeBasicDN(value) { 
    try{
      this.securSetState({
        inputKeyword: value,
        inputKeywordDN: value,
        inputKeywordDNValue: value,
        IsSearchDN: true,
        IsSearchID: false,
        searchCustomerID: null,
        searchSubsriberId: null,
        searchResults: null
      });
      if(value.length === 10){
        this.state.showButton=true;
        this.debounceCustomerSearch(value);
      }

    }catch(exception){
      alert(exception.message);
    }

  }
  handleSearchSubmitBasic(event) {
    event.preventDefault();
    event.stopPropagation();
    if (this.state.inputKeywordID !== '') {
      this.securSetState({
        loading: true,
        validKeyword: this.state.inputKeywordID
      });
      if (this.mounted) {
        this.loadDataBasic();
      }
    } else {
      this.securSetState({
        customers: [],
        loading: false
      });
    }
  }
  async loadDataBasic() {
    const validKeyword = this.state.inputKeywordID;

    try {
      const result = await getCustomer(validKeyword);
      this.onLoadDataSucceedBasic(result);
    } catch (error) {
      if (error.status === 403) {
        this.props.onClose();
      } else {
        this.securSetState({
          loading: false,
          error: error
        });
      }
    }
  }
  async onLoadDataSucceedBasic(customer){
    try {
      const result = await CcoApi.searchCustomer(customer.phone_number);
      this.securSetState({
        loading: false,
        error: false
      });
      this.props.onStart();
      MwHistory.push(
        '/cco/session/' +
          customer.id +
          '/' +
          result[0].id
      );
      const currentRoute = MwHistory.getCurrentRoute();
      if (currentRoute.path.indexOf('/cco/session/') > -1) {
        MwHistory.go();
      }
    } catch (error) {
      if (error.status === 403) {
        this.props.onClose();
      } else {
        this.securSetState({
          loading: false,
          error: error
        });
      }
    }
  };
  //BASIC HANDLER

  debounceCustomerSearch(value) {
    this.securSetState({showButton:false});
    const currTimestamp = Date.now();
    this.setState({ lastInput: currTimestamp });
    setTimeout(() => {
      if (this.state.lastInput === currTimestamp) {
        this.searchCustomer(value);
      } 
    }, _DEBOUNCE_AMOUNT);
  }

  async searchCustomer(inputKeyword) {

    if (inputKeyword.trim() === '') {
      this.securSetState({
        searchResults: null,
        searchCustomerID: null,
        searchSubsriberId: null,
        showButton:false,
        inputKeyword:''
      });
    } else {
      try {
        //AQUI AGREGAR VALIDACIÓN PARA BUSCAR POR DN O ID
        const results = await CcoApi.searchCustomerDN(this.state.inputKeywordDNValue);//antes sin el DN
        this.onSearchCustomerSucceed(results);
        if (results.length !== 0){
          if (results[0].muestraModal['showModal'] === true ){
            this.securSetState({inputKeywordID:"",
            inputKeyword:""});
          }

          this.redirect();
        }

        
        
      } catch (error) {
        if (error.status === 403) {
          this.props.onClose(); 
        } else {
          this.securSetState({
            loading: false,
            error: error
          });
        }
      }
    }
  }
  async searchCustomerClient(inputKeywordID) {
    if (inputKeywordID.trim() === '') {
      this.securSetState({
        searchResults: null,
        searchCustomerID: null,
        searchSubsriberId: null
      });
    } else {
      try {
        const results = await CcoApi.searchCustomerClient(inputKeywordID);
        this.onSearchCustomerSucceed(results);
      } catch (error) {
        if (error.status === 403) {
          this.props.onClose(); 
        } else {
          this.securSetState({
            loading: false,
            error: error
          });
        }
      }
    }
  }
  onSearchCustomerSucceed(results) {
    this.securSetState({
      loading: false,
      error: false,
      searchResults: results,
      showButton: results[0] === undefined? false: results[0].showButton,
      inputKeywordID: results[0] !== undefined? (results[0].clearInputDN === true? '': this.state.inputKeywordID) :this.state.inputKeywordID
    });
  }

  highlightResult(data, keyword) {
    const search = keyword.toLowerCase();
    if (data !== undefined){
        const aData = data.toLowerCase().split(search);
        let hiData = [];
        if (aData[0] !== '') {
          hiData.push(<span key={0}>{aData[0]}</span>);
        }
        for (let i = 1; i < aData.length; i++) {
         hiData.push(
          <span key={i}>
            <span style={{ fontWeight: 700 }}>{keyword}</span>
            {aData[i]}
          </span>
         );
         }
        return hiData;
    }
  }

  formatSearchResults(data, keyword) {
    if (!data) {
      return false;
    }
    return data.map((item) => ({
      customerId: item.customer.id,
      subscriberId: item.id,
      namestr: item.customer.firstname + ' ' + item.customer.lastname,
      status: (
        <>
        <div style={changeElement(item.statusColor)}>
        </div>
        </>
      ),
      name: (
        <>
          {this.highlightResult(item.customer.firstname, keyword)}&nbsp;
          {this.highlightResult(item.customer.lastname, keyword)}
        </>
      ),
      idstr: (
        <>
          {this.highlightResult(
            item.customer.src_client_id.toString(),
            keyword
          )}
        </>
      ),
      mdn: <>{this.highlightResult(item.customer.phone_number, keyword)}</>
    }));
  }

  onSelectCustomer(data) {
    this.securSetState({
      inputType: 'text',
      inputKeyword: data.namestr,
      searchCustomerID: data.customerId,
      searchSubsriberId: data.subscriberId,
      searchResults: null
    });
  }

  handleKeywordSubmit(event) {
    event.preventDefault();
    event.stopPropagation();
    this.props.onStart();
    MwHistory.push(
      '/cco/session/' +
        this.state.searchCustomerID +
        '/' +
        this.state.searchSubsriberId
    );
  }
  onChangeTab(event, value) {
    event.preventDefault();
    this.securSetState({
      selectedTab: value,
      searchResults: null,
      error: null
    });
    
  }
  //redirect
  redirect() {
    if(this.state.IsRedirect === true){
      MwHistory.push(
        '/cco/session/' +
          this.state.searchCustomerID +
          '/' +
          this.state.searchSubsriberId
      );
      
    }
  }
  refreshPage() {
    window.location.reload(false);
  }
  //
  selectIDOrDN(value){

    if(this.state.inputKeywordDNValue !== ''){
      this.handleKeywordChangeDN(this.state.inputKeywordDNValue);
    }
  }
  //Beging V2


  onSearchCustomerSucceedDN(results) {
    this.securSetState({
      loading: true,
      error: false,
      searchResults: results,
      showButton: results[0] === undefined? false: results[0].showButton,
      existDB : true,
      //inputKeyword: results[0] !== undefined? (results[0].clearInputDN === true? '': this.state.inputKeyword) :this.state.inputKeyword,
      inputKeywordID: results[0] !== undefined? (results[0].clearInputID === true? '': this.state.inputKeywordID) :this.state.inputKeywordID,
      IsRedirect: results[0] === undefined? false: results[0].IsRedirect
    });
    this.setState({
      searchSubsriberId : results[0]['ContracSubscriber_id'],
      searchCustomerID : results[0]['id']
      });
  

  }
  
  //End V2

  //Beging DN
  handleBlur() {
  }
  //Sincroniza el valor del campo
  handleKeywordChangeDN(value) {
    this.securSetState({
      loading: true,
      error: null
    });
    if(value.length <= 10)
    {
      this.securSetState({
        IsSearchDN: true,
        IsSearchID: false,
        searchCustomerID: null,
        searchSubsriberId: null,
        searchResults: null,
        showModal: true
      });
    }else{
      this.state.showButton = false
    }
      if(value.length === 10)
      {
        this.debounceCustomerSearchClientDN(value);
        
      }
    
  }
  debounceCustomerSearchClientDN(value) {
    const currTimestamp = Date.now();
    this.setState({ lastInput: currTimestamp });
    setTimeout(() => {
      if (this.state.lastInput === currTimestamp) {
        this.searchCustomerForDN(value);
      }
    }, _DEBOUNCE_AMOUNT);
  }
  async searchCustomerForDN(inputKeyword) {

    if (inputKeyword.trim() === '') {
      this.securSetState({
        searchResults: null,
        searchCustomerID: null,
        searchSubsriberId: null
      });
    } else {
      try {
 
        const results = await CcoApi.searchCustomerDN(inputKeyword); // busca en el back y BD el dn del cliente
        this.onSearchCustomerSucceedDN(results);//llenar los parametros de customer id y subscriber id
        this.securSetState({IsRedirect: results[0].muestraModal['isRedirect']})
        this.redirect(); // te redirige a los detalles del cliente
        
 
      } catch (error) {
        if (error.status === 403) {
          this.props.onClose(); 
        } else {
          this.securSetState({
            loading: false,
            error: null
          });
        }
      }
    }
  }

  //End DN


  renderStartCallKeyword() {
    const styles = {
      error: {
        height: '2rem',
        fontSize: '1.1rem',
        padding: 0,
        textAlign: 'left'
      },
      results: {
        backgroundColor: '#fff',
        position: 'absolute',
        top: '4.4rem',
        left: '0rem',
        padding: '2rem 2.5rem',
        zIndex: 1
      }
    };

    const cols = [
      {
        id: 'id',
        numeric: false,
        label: this.props.t('startcall.col-customer-id'),
        hide: true
      },
      {
        id: 'namestr',
        numeric: false,
        label: this.props.t('startcall.col-customer-name'),
        hide: true
      },
      {
        id: 'name',
        numeric: false,
        label: this.props.t('startcall.col-customer-name')
      },
      {
        id: 'idstr',
        numeric: false,
        label: this.props.t('startcall.col-customer-id')
      },
      {
        id: 'mdn',
        numeric: false,
        label: this.props.t('startcall.col-number')
      }
    ];

    const customHeadStyle = {
      fontSize: '1.3rem'
    };
    const customCellStyle = {
      fontSize: '1.3rem',
      '&:nth-child(n+2)': {
        fontWeight: 400
      }
    };
    const customRowStyle = {
      '&:hover': {
        backgroundColor: '#f5f7fa',
        cursor: 'pointer'
      }
    };


    const contract = this.state.searchResults;
    const thisInput = this.state.inputKeyword !== ''? this.state.inputKeyword : this.state.inputKeywordID
    const results = this.formatSearchResults(
      this.state.searchResults,
      thisInput
    );

    return (
      
      <div >
        <div
          style={{
            width: 'max-content',
            margin: '0rem auto',
            position: 'relative',
          }}
        >
          <PhoneInput
            defaultValue=''
            autoFocus={true}
            placeholder={this.props.t('startcall.ph-search')}
            error={false}
            valid={this.state.inputKeyword !== ''}
            type={'text'}
            value={this.state.inputKeyword}
            onChange={(value) => this.handleKeywordChangeBasicDN(value)}
            size={this.props.size}
            min='10'
            maxLength='10'
            style={{
              width: this.props.inputWidth,
              maxWidth: '100%',
              margin: '0rem 1rem 1rem 0rem'
            }}
          />
                    
       <span style={{ margin: '0rem 1rem 0rem 0rem', width:'max-content' }}>
            <SubmitButton
              disabled={this.state.showButton === false}
              label={this.props.t('startcall.bt-start')}
              isLoading={this.state.loading}
              type='submit'
              size={this.props.size}
              onClick={(thisInputs) =>  this.selectIDOrDN(thisInput)}
            />
          </span>
          {results && results.length === 0  &&(
         <AppModal state={true} message={'Consulta la linea en CRM y asigna una promoción manual de acuerdo a las reglas de Negocio.'}
           clearInputId={this.state.inputKeywordID = ''}
           clearInputDN={this.state.inputKeywordDNValue= ""} 
           showButtonStart ={this.state.showButton=false} 
           clearInputDNF={this.state.inputKeyword = ""}
           IsRedirect= {this.state.IsRedirect = true}
          ></AppModal>
          )}
          {contract && contract.length > 0 && contract[0].muestraModal['showModal'] === true  &&(
         <AppModal state={true}  message={contract[0].muestraModal['message']} 
           clearInputId={this.state.inputKeywordID = ""}
           clearInputDN={this.state.inputKeywordDNValue = ""}
           showButtonStart ={this.state.showButton=contract[0].muestraModal['enableButton']}
           clearInputDNF={this.state.inputKeyword = ""}
           IsRedirect= {this.state.IsRedirect = contract[0].muestraModal['isRedirect']}
          ></AppModal>
          )}      

          {contract && contract.length > 0  &&  contract[0].muestraModal['isContract'] === true &&(
            <Paper style={styles.results} elevation={3}>
              <SmallDataTable
                data={results}
                columns={cols}
                highlight={false}
                customHeadStyle={customHeadStyle}
                customCellStyle={customCellStyle}
                customRowStyle={customRowStyle}
                onSelect={(customer) => {
                  this.onSelectCustomer(customer);
                  //this.state.showButton= true;
                  this.state.IsRedirect = true;
                }}
              />
            </Paper>
            
          )}

          
        </div>

      </div>
  

    );


  }

  renderStartCallID() {
    const styles = {
      error: {
        height: '2rem',
        fontSize: '1.1rem',
        padding: 0,
        textAlign: 'left'
      }
    };

    //manage language
    let errorTrans = null;
    if (this.state.error) {
      errorTrans = this.props.t(this.state.error);
    }

    return (
      <form onSubmit={this.handleIDSubmit}>
        <div style={{ width: 'max-content', margin: '0rem auto' }}>
          <BasicInput
            defaultValue=''
            autoFocus={true}
            placeholder={this.props.t('startcall.ph-id')}
            error={this.state.error && this.state.error !== ''}
            valid={this.state.inputID !== '' && !this.state.error}
            type='text'
            onChange={(value) => this.handleIDChange(value)}
            size={this.props.size}
            maxLength='250'
            style={{
              width: this.props.inputWidth,
              maxWidth: '100%',
              margin: '0rem 1rem 1rem 0rem'
            }}
          />
          <span style={{ margin: '0rem 1rem 0rem 0rem' }}>
            <SubmitButton
              disabled={this.state.inputID === ''}
              label={this.props.t('startcall.bt-start')}
              isLoading={this.state.loading}
              type='submit'
              size={this.props.size}
            />
          </span>
          <Box color='error.main' style={styles.error}>
            <span>{errorTrans}</span>
          </Box>
        </div>
      </form>
    );
  }

  render() {
    const tabs = [
      { id: 1, name: this.props.t('startcall.tab-inbound'), value: 'inbound' }
    ];

    return (
      <>
        <CCOTabs
          tabs={tabs}
          defaultValue={this.state.selectedTab}
          onChange={(event, value) => this.onChangeTab(event, value)}
        />
        {this.state.selectedTab === 0 && this.renderStartCallKeyword()}
        {this.state.selectedTab === 1 && this.renderStartCallID()}
      </>
    );
  }

}
function changeElement(color) {
  const circle = {
    height: '25px',
    width: '25px',
    backgroundColor: color,
    borderRadius: '50%',
    display: 'inline-block'
  }

  return circle
}

export default withTranslation('cco')(StartCallRich);
