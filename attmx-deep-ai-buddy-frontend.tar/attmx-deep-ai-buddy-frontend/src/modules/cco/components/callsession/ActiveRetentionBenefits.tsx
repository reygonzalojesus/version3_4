import React from 'react';
import {TFunction} from "i18next";
import {makeStyles} from "@material-ui/core/styles";

export interface ActiveRetentionBenefitsProps {
    t: TFunction;
    history: any;
}

export default function ActiveRetentionBenefits(props: ActiveRetentionBenefitsProps) {
    let retention_benefits = [];
    if (props.history) {
        for (let attributeInfo of props.history) {
            if (attributeInfo.attribute.code === 'benefit') {
                retention_benefits.push(attributeInfo.value);
            }
        }
    }
    if (retention_benefits.length === 0) {
        retention_benefits.push('Sin beneficios de retención activa');
    }
    const useStyles = makeStyles({
        details: {
            borderBottom: '2px solid #00a8e0',
            padding: '5px',
        },
        benefit: {
            borderBottom: '2px solid #777777'
        }
    });

    const classes = useStyles(props);
    return <>
        <div className={classes.details}>
            <h3>
                {props.t('session.retention-benefit-details')}
            </h3>
        </div>
        <br />
        {retention_benefits.map((r, n) =>
            <div className={classes.benefit}
                 key={n}>
                {r}
            </div>
        )}
    </>
}
