import React from 'react';
import CustomerAttribute from '../../../../types/customerAttribute';
import Pill from '../../../../deep/components/materials/Pill';

interface AttributeInfo {
  attribute: CustomerAttribute;
  customer: number;
  id: number;
  value: any;
  date: string;
}

export interface AttributePillProps {
  attributesList: AttributeInfo[];
  neededAttributeCode: string;
  children: React.ReactNode;
}

export default function AttributePill(props: AttributePillProps) {
  let attribute;
  if (props.attributesList && props.attributesList.length > 0) {
    for (let attr of props.attributesList) {
      if (attr.attribute.code === props.neededAttributeCode) {
        attribute = attr;
        break;
      }
    }
  }
  return (
    <>
      {attribute && (
        <Pill label={attribute.attribute.name.es} data={attribute.value} />
      )}
      {props.children}
    </>
  );
}
