import React from 'react';
import SoftTable from "../../../../deep/components/materials/SoftTable";

export default function BusinessRules() {
    const tableData = {
        headers: [
            'Herramienta de retención',
            'BYOD (en meses)',
            'Installments (en meses)',
            'Planes aplicables',
            'Notas'
        ],
        rows: [
            ['Redes sociales ilimitadas', '6', '12', 'Consiguelo 1 y 2', ''],
            ['GBs adicionales', '6', '12 a 15 meses', 'Todos los planes', ''],
            ['Triple de GB', '15', '15', 'Desde Consiguelo 2 en adelante', ''],
            ['Add on control', '12', '24', 'Todos los planes', ''],
            ['20% de descuento', '6', '6', 'Todos los planes', 'No combinable con otras herramientas'],
            ['30% de descuento', '6', '6', 'Todos los planes', 'No combinable con otras herramientas'],
            ['Noches y Fines de Semana', '6', '6', 'Desde Consiguelo 8 en adelante', '']
        ]
    }
    return <SoftTable data={tableData} field_name={'Regalas'} />
}
