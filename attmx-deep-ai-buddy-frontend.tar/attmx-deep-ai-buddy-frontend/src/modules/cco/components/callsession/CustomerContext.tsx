import React from 'react';
import { TFunction } from 'i18next';
import ProbabilityGauge from './ProbabilityGauge';
import AttributePill from './AttributePill';
import AppModal from 'modules/cco/AppModal';

export interface CustomerContextProps {
  t: TFunction;
  tips: any;
  history: any;
}

export default function CustomerContext(props: CustomerContextProps) {
  //validar que no acceda al detalle del cliente si tiene los contratos finalizados
  return (
    <>
      {props.tips && <ProbabilityGauge t={props.t} tips={props.tips} />}
      {props.history &&
        ['balance', 'retention_contact'].map((c, n) => (
          <AttributePill
            key={n}
            attributesList={props.history}
            neededAttributeCode={c}
          >
            <br />
          </AttributePill>
        ))}
    </>
  );
}

