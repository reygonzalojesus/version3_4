import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { withStyles } from '@material-ui/core/styles';
import i18next from 'i18next';
import PhoneIcon from '@material-ui/icons/Phone';
import GridList from '@material-ui/core/GridList';
import GridListTile from '@material-ui/core/GridListTile';
import Gauge from 'deep/components/materials/Gauge';
import Rating from 'deep/components/materials/Rating';
import CallSessionContext from './../../contexts/CallSessionProvider';
import { get } from 'lodash';
const styles = (theme) => ({
  item: {
    position: 'relative',
    '&:nth-child(n+3)': {
      paddingTop: '1.5rem !important'
    }
  },
  left: {
    paddingRight: '1.2rem !important'
  },
  right: {
    paddingLeft: '1.2rem !important'
  },
  full: {
    padding: '0rem'
  },
  label: {
    color: '#4C4C4C',
    fontWeight: 600,
    textAlign: 'left',
    width: '100%',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    fontSize: '1.5rem'
  },
  value: {
    position: 'relative',
    color: '#777777',
    textAlign: 'left',
    marginBottom: '1.5rem',
    width: '100%',
    overflow: 'hidden',
    textOverflow: 'ellipsis'
  },
  icon: {
    position: 'absolute',
    right: '0rem',
    top: '0rem'
  },
  separator: {
    position: 'absolute',
    bottom: '0rem',
    height: '1px',
    width: '100%',
    backgroundColor: '#E6E9EE'
  },
  portfolio: {
    marginTop: '1rem'
  },
  portfolioTitle: {
    fontSize: '1.7rem',
    color: '#4C4C4C',
    fontWeight: 600,
    marginBottom: '0.6rem'
  },
  chip: {
    boxShadow: '0rem 0.1rem 0.3rem 0rem rgba(0,0,0,0.3)',
    borderRadius: '3rem',
    padding: '0.7rem 1.2rem 0.7rem',
    marginRight: '1rem',
    color: '#777777',
    textAlign: 'center',
    backgroundColor: '#fff',
    display: 'inline-block',
    marginBottom: '1rem'
  },
  table: {
    borderCollapse: 'collapse'
  },
  row: {
    borderBottom: '1px solid black',
    fontSize: '0.7em'
  },
  cell: {
    padding: '0.5em 0.5em',
    textAlign: 'center'
  }
});

//DISPLAY CODE
//1 : string
//2 : int
//3 : float
//4 : currency
//5 : rate
//6 : gauge
//7 : year
//8 : month
//9 : day
//10 : rating

class CustomerDetails extends Component {
  static contextType = CallSessionContext;

  UNSAFE_componentWillMount() {
    this.rendered = false;
  }
  componentWillUnmount() {
    this.rendered = false;
  }
  componentDidUpdate() {
    if (
      !this.rendered &&
      this.context.customer &&
      this.context.personalAttributes &&
      this.context.portfolio
    ) {
      this.rendered = true;
      this.props.onRender(true);
      return true;
    }
    return false;
  }

  getRateStyle(value) {
    if (value < 0.33) {
      return (
        <span style={{ fontWeight: 400, color: '#75CC19' }}>
          {this.props.t('session.customerdetails.val-low')}
        </span>
      );
    } else if (value < 0.66) {
      return (
        <span style={{ fontWeight: 400, color: 'orange' }}>
          {this.props.t('session.customerdetails.val-medium')}
        </span>
      );
    } else {
      return (
        <span style={{ fontWeight: 400, color: '#FF3838' }}>
          {this.props.t('session.customerdetails.val-high')}
        </span>
      );
    }
  }

  formatPersonalInfo(data) {
    if (!data) {
      return null;
    }
    const dataFormatted = [
      {
        label: this.props.t('session.customerdetails.fullname'),
        value: data?.firstname + ' ' + data?.lastname,
        icon: null,
        size: 'medium',
        position: 'left'
      },
      {
        label: this.props.t('session.customerdetails.id'),
        value: data?.src_client_id,
        icon: null,
        size: 'medium',
        position: 'right'
      },
      {
        label: this.props.t('session.customerdetails.location'),
        value: data?.region + ', ' + data?.country,
        icon: null,
        size: 'medium',
        position: 'left'
      },
      {
        label: this.props.t('session.customerdetails.phone'),
        value: data?.phone_number,
        // <PhoneInput value={data?.phone_number} />,
        icon: <PhoneIcon color='primary' fontSize='small' />,
        size: 'medium',
        position: 'right'
      },
      // {
      //   label: this.props.t('session.customerdetails.email'),
      //   value: data?.email,
      //   icon: <EmailIcon color='primary' fontSize='small' />,
      //   position: 'medium'
      // },
      {
        label: this.props.t('session.customerdetails.financial_account'),
        value: data?.email,
        icon: data?.financial_account,
        size: 'medium',
        position: 'left'
      }
    ];
    return dataFormatted;
  }

  formatPersonalAttributes(data) {
    if (!data) {
      return null;
    }

    const dataFormatted = [];

    let i = 0;
    data.forEach((item) => {
      let value = null;
      switch (item.attribute.type) {
        case 'CURRENCY':
          value =
            this.context.clientSettings.currency +
            parseFloat(parseFloat(item.value).toFixed(2)).toString();
          break;
        case 'FLOAT':
          value = parseFloat(parseFloat(item.value).toFixed(2));
          break;
        case 'INT':
          value = parseInt(item.value);
          break;
        case 'DAY_DURATION':
          value = `${parseInt(item.value)}  ${this.props.t(
            'session.customerdetails.days'
          )}`;
          break;
        case 'MONTH_DURATION':
          value = `${parseInt(item.value)}  ${this.props.t(
            'session.customerdetails.months'
          )}`;
          break;

        default:
          value = item.value;
      }

      dataFormatted.push({
        label:
          item.attribute.name[i18next.language] ||
          item.attribute.name[i18next.options.fallbackLng[0]],
        value: value,
        display: item.attribute.display,
        icon: null,
        position: i % 2 === 0 ? 'left' : 'right'
      });
      i += 1;
    });

    return dataFormatted;
  }

  formatPortfolio(data) {
    if (!data) {
      return null;
    }
    const dataFormatted = [];
    let seenProducts = new Set();

    data.forEach((item) => {
      if (item.product && !item.ended) {
        if (!seenProducts.has(item.product.name)) {
          dataFormatted.push({
            id: item.subscriber.src_subscriber_id,
            phone: item?.subscriber.src_mdn,
            name:
              item.product.name[i18next.language] ||
              item.product.name[i18next.options.fallbackLng[0]],
            price: item.product.price
          });
        }
      }
    });

    return dataFormatted;
  }

  formatSubscribers(data) {
    if (!data) {
      return null;
    }
    return data.map((subscriber) => ({
      ...subscriber,
      device: {
        ...subscriber.device,
        name:
          subscriber.device.product.name[i18next.language] ||
          subscriber.device.product.name[i18next.options.fallbackLng[0]]
      },
      plan: {
        ...subscriber.plan,
        name:
          subscriber.plan.product.name[i18next.language] ||
          subscriber.plan.product.name[i18next.options.fallbackLng[0]]
      }
    }));
    
  }

  render() {
    const personalInfo = this.formatPersonalInfo(this.context.customer);
    const personalAttributes = this.formatPersonalAttributes(
      this.context.personalAttributes
    );
    const portfolio = this.formatPortfolio(this.context.portfolio);
    const subscribers = this.formatSubscribers(this.context.subscribers);
    const displayPortfolio = get(
      this.context.clientSettings,
      'sessionConfig.displayPortfolio',
      true
    );

    const { classes } = this.props;
    return (
      <div>
        <GridList cellHeight='auto' cols={2} spacing={0}>
          {personalInfo &&
            personalInfo.map((item, index) => (
              <GridListTile
                key={index}
                cols={item.position === 'full' ? 2 : 1}
                className={`${classes.item} ${classes[item.position]}`}
              >
                <div className={classes.label}>{item.label}</div>
                <div className={classes.value}>
                  <span style={{ paddingRight: '1.5rem' }}>{item.value}</span>
                  {item.icon && <div className={classes.icon}>{item.icon}</div>}
                </div>
                <div className={classes.separator}></div>
              </GridListTile>
            ))}

          {personalAttributes &&
            personalAttributes.map((item, index) => (
              <GridListTile
                key={index}
                cols={item.position === 'full' ? 2 : 1}
                className={`${classes.item} ${classes[item.position]}`}
              >
                <div className={classes.label}>{item.label}</div>
                <div className={classes.value}>
                  {item.display === 10 && (
                    <Rating value={item.value} precision={0.5} readOnly />
                  )}
                  {item.display === 6 && <Gauge value={item.value} />}
                  {item.display === 5 && <>{this.getRateStyle(item.value)}</>}
                  {![5, 6, 10].includes(item.display) && <>{item.value}</>}
                </div>
                <div className={classes.separator}></div>
              </GridListTile>
            ))}
        </GridList>

        {portfolio && displayPortfolio && (
          <div className={classes.portfolio}>
            <div className={classes.portfolioTitle}>
              {this.props.t('session.customerdetails.portfolio-title')}
            </div>
            <div>
              <table className={classes.table}>
                <tr className={classes.row}>
                  <td className={classes.label}>Plan</td>
                  {subscribers &&
                    subscribers.length > 0 &&
                    subscribers.map((subscriber, index) => (
                      <td key={index} className={classes.cell}>
                        {subscriber.plan.name}
                      </td>
                    ))}
                </tr>
                <tr className={classes.row}>
                  <td className={classes.label}>DN</td>
                  {subscribers &&
                    subscribers.length > 0 &&
                    subscribers.map((subscriber, index) => (
                      <td key={index} className={classes.cell}>
                        {subscriber.src_mdn}
                      </td>
                    ))}
                </tr>
                <tr className={classes.row}>
                  <td className={classes.label}>Data plan fee</td>
                  {subscribers &&
                    subscribers.length > 0 &&
                    subscribers.map((subscriber, index) => (
                      <td key={index} className={classes.cell}>
                        {subscriber.plan.product.price}
                      </td>
                    ))}
                </tr>
                <tr className={classes.row}>
                  <td className={classes.label}>Device</td>
                  {subscribers &&
                    subscribers.length > 0 &&
                    subscribers.map((subscriber, index) => (
                      <td key={index} className={classes.cell}>
                        {subscriber.device.name}
                      </td>
                    ))}
                </tr>
                <tr className={classes.row}>
                  <td className={classes.label}>Outstanding device payment</td>
                  {subscribers &&
                    subscribers.length > 0 &&
                    subscribers.map((subscriber, index) => (
                      <td key={index} className={classes.cell}>
                        {subscriber.remaining_balance}
                      </td>
                    ))}
                </tr>
                <tr className={classes.row}>
                  <td className={classes.label}>Pending device installments</td>
                  {subscribers &&
                    subscribers.length > 0 &&
                    subscribers.map((subscriber, index) => (
                      <td key={index} className={classes.cell}>
                        {subscriber.outstanding_installments}
                      </td>
                    ))}
                </tr>
                {/* <tr className={classes.cell}>DN</tr>
                    <tr className={classes.cell}>Data plan fee</tr>
                    <tr className={classes.cell}>Device</tr>
                    <tr className={classes.cell}>Outstanding device payment</tr>
                    <tr className={classes.cell}>
                      Pending device installments
                    </tr> */}
                {/* </td> */}
                {/* {subscribers &&
                  subscribers.length > 0 &&
                  subscribers.map((subscriber, index) => (
                    <td key={index} className={classes.row}>
                      <tr className={classes.cell}>{subscriber.plan.name}</tr>
                      <tr className={classes.cell}>{subscriber.src_mdn}</tr>
                      <tr className={classes.cell}>
                        {subscriber.plan.product.price}
                      </tr>
                      <tr className={classes.cell}>{subscriber.device.name}</tr>
                      <tr className={classes.cell}>
                        {subscriber.remaining_balance}
                      </tr>
                      <tr className={classes.cell}>
                        {subscriber.outstanding_installments}
                      </tr>
                    </td>
                  ))} */}
              </table>
            </div>
          </div>
        )}
      </div>
    );
  }
}

export default withTranslation('cco')(withStyles(styles)(CustomerDetails));
