import React from 'react';
import {TFunction} from "i18next";
import CustomerDetails from "./CustomerDetails";
import AttributePill from "./AttributePill";

export interface CustomerOverviewProps {
    t: TFunction;
    onRender: any;
    history: any;
}

export default function CustomerOverview(props: CustomerOverviewProps) {
    return <>
        <CustomerDetails
            t={props.t}
            onRender={props.onRender}
        />
        <br />
        <AttributePill attributesList={props.history}
                       neededAttributeCode={'late_payment'} />
        <br />
        <AttributePill attributesList={props.history}
                       neededAttributeCode={'open_order'} />
    </>
}
