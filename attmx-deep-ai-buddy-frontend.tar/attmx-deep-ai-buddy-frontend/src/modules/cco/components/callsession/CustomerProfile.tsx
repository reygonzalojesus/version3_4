import React from 'react';
import { TFunction } from 'i18next';
import GridListDataCard from '../../../../deep/components/GridListDataCard';
import Contract from '../../../../types/contract';

interface CustomerProfileProps {
  t: TFunction;
  portfolio: any;
  products: any;
}

function CustomerProfile(props: CustomerProfileProps) {
  let portfolio = props.portfolio
    ? props.portfolio.filter((p: Contract) => !p.ended)
    : [];
  // @ts-ignore
  let possiblePlans = portfolio
    ? portfolio.filter(
        (p: Contract) => p.product.product_code === 'PLAN_ACTUAL'
      )
    : [];
  // @ts-ignore
  let possibleEquipment = portfolio
    ? props.portfolio.filter(
        (p: Contract) => !p.product.product_code === 'EQUIP_ACTUAL'
      )
    : [];
  let gridData = [];
  if (possiblePlans.length >= 1) {
    gridData.push({
      label: 'Plan',
      value: possiblePlans[0].product.name['es']
    });
  }
  if (possibleEquipment.length >= 1) {
    gridData.push({
      label: 'Equipo',
      value: possibleEquipment[0].product.name['es']
    });
  }

  return <GridListDataCard t={props.t} data={gridData} />;
}

export default CustomerProfile;
