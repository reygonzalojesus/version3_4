import React from 'react';
import TrafficShare from "../../../../types/trafficShare";
import {TFunction} from "i18next";
import StackedBar from "../../../monitoring/analysis/charts/StackedBar";

export interface DataUsageProps {
    t: TFunction;
    dataUsage: TrafficShare;
}


export default function DataUsage(props: DataUsageProps) {
    // This is janky, but I don't think it's a poor choice in this context -
    // ideally the labels here would be defined on BE in case it changes
    let outcome: any = [];
    const colors = ['#0BDCE9', '#0CE67F', '#FEC869', '#FF5757']
    if (props.dataUsage) {
        Object.keys(props.dataUsage).forEach((x, i) => {
            if (x.startsWith("daily_")) {
                const source = x.split("_")[1];
                if (source) {
                    const sourceCapitalized = source.slice(0, 1).toUpperCase() + source.slice(1);
                    // @ts-ignore
                    const sourceVal: number = props.dataUsage[x];
                    if (sourceVal > 0) {
                        outcome.push({
                            label: sourceCapitalized,
                            value: (sourceVal * 100),
                            ratio: sourceVal,
                        })
                    }
                }
            }
        });
    }
    let sortedOutcomes = outcome.sort((a: any, b: any) => {
        if (a.ratio > b.ratio) {
            return -1;
        }
        else if (a.ratio === b.ratio) {
            return 0;
        } else {
            return 1;
        }
    }).map((o: any, i: number) => {
        o.color = (colors[(i)%(colors.length)]);
        return o;
    })
    return <>
        <StackedBar data={sortedOutcomes} showValue={false} />
    </>
}
