import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import i18next from 'i18next';
import styles from './Feedback.module.css';
import * as MwHistory from 'utils/MwHistory';
import * as CcoApi from './../../api/endpoints';
import Box from '@material-ui/core/Box';
import SimpleTabsMenu from 'deep/components/materials/SimpleTabsMenu';
import SmartTextarea from 'deep/components/materials/SmartTextarea';
import RadioButtonsList from 'deep/components/materials/RadioButtonsList';
import SubmitButton from 'deep/components/materials/SubmitButton';
import ConfirmTimerModal from 'deep/components/ConfirmTimerModal';
import CallSessionContext from './../../contexts/CallSessionProvider';
import StartTab from './tabs/StartTab';
// import ScanTab from './tabs/ScanTab';
import { OfferOutcome } from './tabs/offerladder/OfferButtons';
import CheckTab from './tabs/CheckTab';
import ExplorationTab from './tabs/ExplorationTab';
// import OfferTab from './tabs/OfferTab';
import submitSessionFeedback from '../../api/endpoints/submitSessionFeedback';
import Button from '@material-ui/core/Button';
import NotesModal from './NotesModal';
import ScriptOptionalTab from './ScriptOptionalTab';

class Feedback extends Component {
  static contextType = CallSessionContext;

  constructor(props) {
    super(props);
    this.state = {
      selectedTab: 0,
      selectedOutcome: -1,
      selectedReason: null,
      selectedQuarantine: null,
      comment: null,
      feedBackRequestExecuting: false,
      quarantineRequestExecuting: false,
      submitError: null,
      regularConfirmModalOpen: false,
      notesModalOpen: false,
      confirmModalTimer: 15,
      intervalId: null,
      feedbackId: null,
      offerStatuses: null,
      churnArchetype: null,
      recordArchetype: false,
      src_subscriber_id: null
    };

    this.onChangeTab = this.onChangeTab.bind(this);
    this.onChangeOutcome = this.onChangeOutcome.bind(this);
    this.onChangeReason = this.onChangeReason.bind(this);
    this.onRequestSubmit = this.onRequestSubmit.bind(this);
    this.handleConfirmModal = this.handleConfirmModal.bind(this);
    this.handleCloseModal = this.handleCloseModal.bind(this);
  }

  componentDidMount() {
    this.mounted = true;
    // Note start time of session
    this.sessionStart = Date.now();
    this.securSetState({
      confirmModalTimer: 15,
      startDate: new Date(),
      offerStatuses: this.context.offerLadder
        .sort((a, b) => {
          const aValue = a.offer_value ? a.offer_value : 0;
          const bValue = b.offer_value ? b.offer_value : 0;
          return aValue === bValue ? 0 : aValue > bValue ? -1 : 1;
        })
        .map((o) => ({
          offerLadderOffer: o,
          status: OfferOutcome.NotSelected,
          comment: null
        })),
      customOfferStatus: OfferOutcome.NotSelected,
      cutomOfferComment: null
    });
  }
  componentWillUnmount() {
    this.mounted = false;
    clearInterval(this.state.intervalId);
    clearTimeout(this.timeout);
  }
  securSetState(data) {
    if (this.mounted) {
      this.setState(() => data);
    }
  }

  componentDidUpdate() {
    if (this.state.selectedOutcome < 0 && this.context.outcomeAcceptedId) {
      this.securSetState({ selectedOutcome: this.context.outcomeAcceptedId });
    }
  }

  onChangeTab = (event, value) => {
    event.preventDefault();
    this.securSetState({
      selectedTab: value,
      submitError: null
    });
  };

  onChangeOutcome = (value) => {
    this.securSetState({
      selectedOutcome: value
    });
  };

  onChangeOfferComment = (event, value) => {
    let offers = this.state.offerStatuses;
    offers[event].comment = value;
    this.securSetState({
      offerStatuses: offers
    });
  };

  onChangeReason = (event, value) => {
    event.preventDefault();
    this.securSetState({
      selectedReason: value,
      submitError: null
    });
  };

  onChangeQuarantine = (event, value) => {
    event.preventDefault();
    this.securSetState({
      selectedQuarantine: value,
      submitError: null
    });
  };

  onChangeComment = (value) => {
    this.securSetState({
      comment: value,
      submitError: null
    });
  };

  onRequestSubmit(event) {
    const { selectedQuarantine } = this.state;

    event.preventDefault();
    let feedbackOffers = {};
    this.state.offerStatuses.forEach((s) => {
      feedbackOffers[s.offerLadderOffer.offer.id] = {
        outcome: s.status,
        comment: s.comment
      };
    });
    if (this.state.customOfferStatus !== OfferOutcome.NotSelected) {
      feedbackOffers['custom'] = {
        outcome: this.state.customOfferStatus,
        comment: this.state.customOfferComment
      };
    }
    submitSessionFeedback({
      started: this.state.startDate.toISOString(),
      opportunity: this.context.selectedOpportunity.id,
      customer: this.context.customer.id,
      subscriber: this.context.subscriberId,
      outcome: this.state.selectedOutcome,
      comment: this.state.comment,
      archetype: this.state.churnArchetype.id,
      offer: this.context.selectedOffer.id,
      ended: new Date().toISOString()
    }).then(() => {
      this.securSetState({
        feedBackRequestExecuting: false,
        submitError: null
      });
      this.openRegularConfirmModal();
    });
    this.securSetState({
      feedBackRequestExecuting: true
    });
    if (selectedQuarantine) {
      this.securSetState({
        quarantineRequestExecuting: true
      });
      this.postQuarantine();
    }
  }

  async postQuarantine() {
    const customerId = this.context.customer;
    const { selectedQuarantine } = this.state;
    try {
      await CcoApi.postQuarantine(customerId, selectedQuarantine);
    } catch (error) {
      this.securSetState({
        quarantineRequestExecuting: false,
        submitError: this.props.t(error)
      });
    }
  }

  onSubmitFeedbackSucceed(response) {
    if (this.context.gamificationActive) {
      this.props.gamificationContext.raiseFeedbackNotification();
    } else {
      this.openRegularConfirmModal();
    }
    this.securSetState({
      feedBackRequestExecuting: false,
      submitError: null,
      feedbackId: response.id
    });
  }

  openRegularConfirmModal() {
    let intervalId = setInterval(() => {
      this.setTimerConfirmModal(this.state.confirmModalTimer);
    }, 1000);
    this.securSetState({
      regularConfirmModalOpen: true,
      intervalId: intervalId
    });
  }

  setTimerConfirmModal(timer) {
    if (timer === 0) {
      clearInterval(this.state.intervalId);
      this.securSetState({
        notesModalOpen: true,
        regularConfirmModalOpen: false
      });
    } else {
      this.securSetState({
        confirmModalTimer: timer - 1
      });
    }
  }

  handleCloseModal(event) {
    clearInterval(this.state.intervalId);
    this.securSetState({
      regularConfirmModalOpen: false
    });
    this.timeout = setTimeout(() => {
      this.securSetState({ confirmModalTimer: 15 });
    }, 200);
  }

  handleCloseNotesModal() {
    MwHistory.replace('/cco');
  }

  handleConfirmModal(event) {
    clearInterval(this.state.intervalId);
    this.securSetState({
      notesModalOpen: true,
      regularConfirmModalOpen: false
    });
  }

  formatReasons(outcomes, reasons) {
    if (!outcomes || !reasons) {
      return null;
    }

    let dataFormatted = {};
    outcomes.forEach((item) => {
      dataFormatted[item.id] = [];
    });
    reasons.forEach((item) => {
      dataFormatted[item.outcome].push({
        id: item.id,
        label:
          item.description[i18next.language] ||
          item.description[i18next.options.fallbackLng[0]],
        value: item.id.toString()
      });
    });

    return dataFormatted;
  }
  formatQuarantines(quarantines) {
    if (!quarantines) {
      return null;
    }

    return quarantines.map((quarantine) => ({
      id: quarantine.id,
      label:
        quarantine.label[i18next.language] ||
        quarantine.label[i18next.options.fallbackLng[0]],
      value: quarantine.id.toString()
    }));
  }

  /**
   * Render the appropriate tab
   * @returns {JSX.Element}
   */
  activeTab() {
    let tab;
    let optionnal = true;
    switch (this.state.selectedTab) {
      case 0:
        tab = (
          <StartTab
            t={this.props.t}
            customer={this.context.customer}
            me={this.context.me}
            clientSettings={this.context.clientSettings}
            opportunity={this.context.selectedOpportunity}
            staticScripts={this.context.staticScripts}
          />
        );
        break;
      case 1:
        optionnal = false;
        tab = (
          <ExplorationTab
            t={this.props.t}
            archetypes={this.context.archetypes}
            churnArchetypeOption={this.context.churnArchetypeOption}
            opportunity={this.context.selectedOpportunity}
            recordArchetype={() =>
              this.securSetState({ recordArchetype: true })
            }
            archetypeRecorded={this.state.recordArchetype}
            selectedChurnArchetype={this.state.churnArchetype}
            onChangeChurnArchetype={(c) => {
              this.securSetState({ churnArchetype: c });
            }}
            selectedOffer={this.context.selectedOffer}
            onChangeOffer={this.context.setSelectedOffer}
            staticScripts={this.context.staticScripts}
            selectedOutcome={this.state.selectedOutcome}
            onChangeOutcome={this.onChangeOutcome}
          />
        );
        break;
      case 2:
        tab = (
          <CheckTab
            staticScripts={this.context.staticScripts}
            customer={this.context.customer}
            me={this.context.me}
          />
        );
        break;
      default:
        tab = <div>Unrecognized option</div>;
        break;
    }
    if (optionnal) {
      return <ScriptOptionalTab t={this.props.t}>{tab}</ScriptOptionalTab>;
    } else {
      return tab;
    }
  }

  renderScripts() {
    const opportunity = this.context.selectedOpportunity;

    if (!opportunity) {
      return null;
    }

    const tabs = [
      {
        id: 1,
        name: this.props.t('session.feedback.tab-start'),
        value: 'startScript'
      },
      {
        id: 2,
        name: this.props.t('session.feedback.tab-scan'),
        value: 'scanScript'
      },
      {
        id: 3,
        name: this.props.t('session.feedback.tab-check'),
        value: 'checkScript'
      }
    ];
    return (
      <>
        <SimpleTabsMenu
          tabs={tabs}
          value={this.state.selectedTab}
          onChange={(event, value) => this.onChangeTab(event, value)}
        />
        <div className={styles.Script}>{this.activeTab()}</div>
      </>
    );
  }

  renderReasons() {
    const { outcomes, reasons } = this.context;

    if (!reasons || !reasons) {
      return null;
    }

    const formattedReasons = this.formatReasons(outcomes, reasons);
    const { selectedOutcome } = this.state;
    const { outcomeNotOfferedId, outcomeRejectedId } = this.context;
    return (
      <>
        {selectedOutcome === outcomeNotOfferedId && (
          <RadioButtonsList
            onChange={(event, value) => this.onChangeReason(event, value)}
            defaultValue={1}
            options={formattedReasons[outcomeNotOfferedId]}
          />
        )}
        {selectedOutcome === outcomeRejectedId && (
          <RadioButtonsList
            onChange={(event, value) => this.onChangeReason(event, value)}
            defaultValue={1}
            options={formattedReasons[outcomeRejectedId]}
          />
        )}
      </>
    );
  }
  renderQuarantines() {
    const { quarantines } = this.context;
    if (!quarantines) {
      return null;
    }

    const formattedQuarantines = this.formatQuarantines(quarantines);
    const { selectedOutcome } = this.state;
    const { outcomeUndecidedId } = this.context;
    return (
      <>
        {selectedOutcome === outcomeUndecidedId && (
          <RadioButtonsList
            onChange={(event, value) => this.onChangeQuarantine(event, value)}
            defaultValue={1}
            options={formattedQuarantines}
          />
        )}
      </>
    );
  }
  renderComment() {
    return (
      <>
        <div className={styles.Subtitle}>
          {this.props.t('session.feedback.lbl-comments')}
        </div>
        <div>
          <SmartTextarea
            maxLength='250'
            onChange={(value) => this.onChangeComment(value)}
          />
        </div>
      </>
    );
  }

  render() {
    const isSubmitEnable = () => {
      const {
        selectedOutcome
      } = this.state;
      if (selectedOutcome) {
        return true;
      }
      return false;
    };

    return (
      <div>
        <ConfirmTimerModal
          open={this.state.regularConfirmModalOpen}
          onClose={this.handleCloseModal}
          onConfirm={this.handleConfirmModal}
          timer={this.state.confirmModalTimer}
          lblTitle={this.props.t('session.feedback.modal-title')}
          btClose={this.props.t('session.feedback.bt-back')}
          btConfirm={this.props.t('session.feedback.bt-continue')}
        />
        {this.state.offerStatuses && (
          <NotesModal
            customer={this.context.customer}
            customOfferOutcome={this.state.customOfferStatus}
            offers={this.state.offerStatuses}
            archetype={
              this.state.churnArchetype ? this.state.churnArchetype.label : ''
            }
            open={this.state.notesModalOpen}
            onClose={this.handleCloseNotesModal}
            t={this.props.t}
          />
        )}
        <form onSubmit={this.onRequestSubmit}>
          {this.renderScripts()}
          {this.renderQuarantines()}
          {this.renderComment()}
          {this.state.submitError && (
            <Box color='error.main' className={styles.error}>
              <span>{this.state.submitError}</span>
            </Box>
          )}
          <div style={{ textAlign: 'right', marginTop: '1rem' }}>
            {this.state.selectedTab === 2 ? (
              <SubmitButton
                disabled={!isSubmitEnable()}
                label={this.props.t('session.feedback.bt-end-session')}
                isLoading={
                  this.state.feedBackRequestExecuting ||
                  this.state.quarantineRequestExecuting
                }
                color='secondary'
                type='submit'
                size='small'
              />
            ) : (
              <Button
                variant='contained'
                color={'default'}
                disableElevation
                disableRipple
                onClick={() =>
                  this.setState({ selectedTab: this.state.selectedTab + 1 })
                }
              >
                {this.props.t('session.next')}
              </Button>
            )}
          </div>
        </form>
      </div>
    );
  }
}

export default withTranslation('cco')(Feedback);
