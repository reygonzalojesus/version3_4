import React from 'react';
import SimpleTable from '../../../../deep/components/materials/SimpleTable';
import Moment from 'react-moment';

export default function InteractionHistory(props) {
  const interactionHistory = {
    headers: [
      'interaction-date',
      'interaction-reason',
      'interaction-subreason',
      'interaction-media'
    ].map((i) => props.t(`session.interaction.${i}`)),
    rows:
      props?.interactions && props.interactions.length > 0
        ? props.interactions?.map((interaction) => [
            <Moment format={'ll'}>{interaction.created}</Moment>,
            interaction.level_one,
            interaction.level_two,
            interaction.inc_inter_channel
          ])
        : []
  };
  return (
    <div>
      <SimpleTable data={interactionHistory} field_name={'interacciones'} />
    </div>
  );
}
