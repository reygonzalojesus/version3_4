import React, {useState} from 'react';
import {Dialog} from "@material-ui/core";
import Customer from "../../../../types/customer";
import {OfferStatus} from "./tabs/OfferTab";
import {OfferOutcome} from "./tabs/offerladder/OfferButtons";
import {makeStyles} from "@material-ui/core/styles";
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faCopy, faStickyNote} from "@fortawesome/free-solid-svg-icons";
import Button from "@material-ui/core/Button";
import {TFunction} from "i18next";

export interface NotesModalProps {
    customer: Customer;
    offers: OfferStatus[];
    customOfferOutcome: OfferOutcome;
    open: boolean;
    onClose: () => any;
    archetype?: string;
    t: TFunction;
}

function getInitialNotes(customer: Customer, offers: OfferStatus[],
                         customOfferOutcome: OfferOutcome,
                         archetype?: string): string {
    let offerResults: string[] = [];
    // First find any accepted offers, than any rejected ones, then custom
    offers.filter((o) => o.status === OfferOutcome.Accepted).forEach((s) => {
        offerResults.push(`Oferta "${s.offerLadderOffer.offer.name}" aceptada`)
    })
    offers.filter((o) => o.status === OfferOutcome.Rejected).forEach((s) => {
        offerResults.push(`Oferta "${s.offerLadderOffer.offer.name}" rechazada`)
    })
    if (customOfferOutcome !== OfferOutcome.NotSelected &&
        customOfferOutcome !== OfferOutcome.NotProposed) {
        if (customOfferOutcome === OfferOutcome.Accepted) {
            offerResults.push("Oferta personalizada aceptada")
        } else {
            offerResults.push("Oferta personalizada rechazada")
        }
    }
    let resultsText;
    if (offerResults.length >= 1) {
        resultsText = offerResults.join('\n');
    } else {
        resultsText = "No se aceptaron ni rechazaron ofertas"
    }
    const noteSections: {name: string; value: string}[] = [
        {
            name: "Nombre",
            value: `${customer.firstname} ${customer.lastname}`
        },
        {
            name: "DN",
            value: customer.phone_number
        },
        {
            name: "CTA",
            value: ""
        },
        {
            name: "Motivo de la cancelación",
            value: (archetype ? archetype : "")
        },
        {
            name: "Resultado de la sesión",
            value: resultsText
        },
        {
            name: "Telefono de contacto",
            value: customer.phone_number
        },
        {
            name: "Otro",
            value: ""
        }
    ]
    let notes = '';
    noteSections.forEach((s) => {
        notes += `${s.name}: ${s.value}\n\n`
    })
    notes += "#REACT";
    return notes;
}

export default function NotesModal(props: NotesModalProps) {
    const useStyles = makeStyles({
        paper: {
            padding: '3rem',
            minWidth: '40rem',
            borderRadius: '0.6rem'
        },
        button: {
            textTransform: 'none',
            fontSize: '1.3rem',
            fontWeight: 600,
            margin: '0rem 1rem',
            paddingLeft: '1.7rem',
            paddingRight: '1.7rem',
            borderRadius: '1.8rem'
        },
        icon: {
            fontSize: '3rem',
            textAlign: 'center',
            lineHeight: 1
        },
        close: {
            position: 'absolute',
            top: '1rem',
            right: '1rem',
            color: '#979797',
            cursor: 'pointer',
            fontWeight: 'bold'
        },
        message: {
            fontSize: '2rem',
            fontWeight: 600,
            textAlign: 'center',
            marginTop: '1rem'
        },
        textarea: {
            width: '100%',
            maxWidth: '100%',
            resize: 'vertical',
            padding: '1rem 1.4rem',
            border: '1px solid #E6E9EE',
            borderRadius: '0.5rem',
            fontSize: '1.2rem',
            color: '#3A404D',
            minHeight: '35rem',
            fontFamily: "'Open Sans', sans-serif",
            whiteSpace: "pre-wrap"
        },
    });
    const classes = useStyles();
    const [notes, setNotes] = useState(getInitialNotes(props.customer, props.offers, props.customOfferOutcome,
        props.archetype));
    const [typing, setTyping] = useState(false);
    let newNotes = getInitialNotes(props.customer,
        props.offers,
        props.customOfferOutcome,
        props.archetype);
    if (newNotes !== notes && !typing) {
        setNotes(newNotes)
    }
    return <Dialog
        open={props.open}
        onClose={props.onClose}
        classes={{ paper: classes.paper }}
        disableBackdropClick={true}
        disableEscapeKeyDown={true}
    >
        <div>
            <div className={classes.icon}>
                <FontAwesomeIcon icon={faStickyNote} />
            </div>
            <div className={classes.message}>
                {props.t('session.notes-modal-title')}
            </div>
            <textarea
                className={classes.textarea}
                value={notes}
                onChange={(v: any) => {
                    setTyping(true);
                    setNotes(v.target.value);
                }}
             />
            <Button
                variant='outlined'
                color='primary'
                disableElevation
                size='small'
                classes={{
                    root: classes.button
                }}
                onClick={() => {
                    navigator.clipboard.writeText(notes).then(() => {
                        
                    })
                }}
            >
                <FontAwesomeIcon icon={faCopy} />
                {props.t('session.copy')}
            </Button>
            <Button
                variant='contained'
                color='primary'
                disableElevation
                size='small'
                classes={{
                    root: classes.button
                }}
                onClick={props.onClose}
            >
                {props.t('session.continue-and-close')}
            </Button>
        </div>
    </Dialog>
}
