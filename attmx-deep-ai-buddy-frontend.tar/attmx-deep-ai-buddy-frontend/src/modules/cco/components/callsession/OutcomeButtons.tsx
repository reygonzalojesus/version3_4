import React from 'react';
import Opportunity from "../../../../types/opportunity";
import {TFunction} from "i18next";
import styles from './Feedback.module.css';
import Box from "@material-ui/core/Box";

interface OutcomeButtonsProps {
    onChangeOutcome: (event: any, value: any) => any;
    selectedOutcome: any;
    opportunity: Opportunity;
    t: TFunction;
    outcomes: any;
    outcomeAcceptedId: any;
    outcomeNotOfferedId: any;
    outcomeRejectedId: any;
    outcomeUndecidedId: any;
}

function OutcomeButtons(props: OutcomeButtonsProps) {
    return (
        <>
            <div className={styles.Subtitle}>
                {props.t('session.feedback.lbl-outcome')}
            </div>
            <div className={styles.ChipsContainer}>
                <Box className={styles.ChipsBorder}>
                    <div
                        className={`
                  ${styles.Chip}
                  ${styles.Accepted}
                  ${props.selectedOutcome === props.outcomeAcceptedId ? styles.Active : ''}
                `}
                        onClick={(event) =>
                            props.onChangeOutcome(event, props.outcomeAcceptedId)
                        }
                    >
                        {props.t('session.feedback.tab-outcome-accepted')}
                    </div>
                    {props.opportunity.product && (
                        <div
                            className={`
                    ${styles.Chip}
                    ${styles.NotProposed}
                    ${props.selectedOutcome === props.outcomeNotOfferedId
                                ? styles.Active
                                : ''
                            }
                  `}
                            onClick={(event) =>
                                props.onChangeOutcome(event, props.outcomeNotOfferedId)
                            }
                        >
                            {props.t('session.feedback.tab-outcome-notoffered')}
                        </div>
                    )}
                    <div
                        className={`
                    ${styles.Chip}
                    ${styles.Undecided}
                    ${props.selectedOutcome === props.outcomeUndecidedId
                            ? styles.Active
                            : ''
                        }
                  `}
                        onClick={(event) =>
                            props.onChangeOutcome(event, props.outcomeUndecidedId)
                        }
                    >
                        {props.t('session.feedback.tab-outcome-undecided')}
                    </div>
                    <div
                        className={`
                  ${styles.Chip}
                  ${styles.Rejected}
                  ${props.selectedOutcome === props.outcomeRejectedId ? styles.Active : ''}
                `}
                        onClick={(event) =>
                            props.onChangeOutcome(event, props.outcomeRejectedId)
                        }
                    >
                        {props.t('session.feedback.tab-outcome-rejected')}
                    </div>
                </Box>
            </div>
        </>
    );
}

export default OutcomeButtons;