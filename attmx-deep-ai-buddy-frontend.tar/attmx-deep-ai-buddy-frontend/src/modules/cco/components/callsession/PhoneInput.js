import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { withStyles } from '@material-ui/core/styles';
import CallSessionContext from './../../contexts/CallSessionProvider';

const styles = (theme) => ({
  input: {
    cursor: 'pointer',
    border: 'none',
    // borderBottom: '1px #777 solid',
    color: '#777777',
    fontSize: '1.5rem',
    fontStyle: 'italic',
    fontWeight: 400,
    padding: '0.5em 0'
  },
  helptext: {
    fontSize: '0.6em',
    letterSpacing: '-0.8px'
  }
});

class PhoneInput extends Component {
  static contextType = CallSessionContext;

  constructor(props) {
    super(props);
    this.state = {};
    // this.toggle = this.toggle.bind(this);
  }

  render() {
    const { classes } = this.props;
    return (
      <div>
        <input value={this.props.value} className={classes.input} />
        <span className={classes.helptext}>
          Customer's phone number is modifiable
        </span>
      </div>
    );
  }
}

export default withStyles(styles)(withTranslation('cco')(PhoneInput));
