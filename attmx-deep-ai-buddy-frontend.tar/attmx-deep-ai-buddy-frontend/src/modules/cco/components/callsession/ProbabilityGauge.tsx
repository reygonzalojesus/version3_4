import React from 'react';
import { TFunction } from 'i18next';
import './probabilitygauge.css'
import {makeStyles} from "@material-ui/core/styles";

export interface ProbabilityGaugeProps {
  t: TFunction;
  tips?: any[];
}

const levels = {
    green: {
        color: "#00de7c",
        cutoff: 16.5,
        label: "green",
        text: "session.probability-types.low"
    },
    yellow: {
        color: "#FEC869",
        cutoff: 50,
        text: "session.probability-types.typical"
    },
    red: {
        color: "#d85656",
        cutoff: 100,
        text: "session.probability-types.high"
    }
};


export default function ProbabilityGauge(props: ProbabilityGaugeProps) {
    // const styles = {
    //     '.probability-gauge-bar::before': {

    //     }
    // };
  let churnProb: number = 0;
  if (props.tips) {
    for (let tip of props.tips) {
      if (tip.label === 'Probabilidad de Abandono' && tip.value) {
        let val = tip.value;
        if (typeof val === 'string') {
          val = parseFloat(val);
        }
        val = val.toFixed(3);
        churnProb = val;
      }
    }
  }
  const churnProbPercent = churnProb * 100;
  const churnProbPrecision = churnProbPercent.toPrecision(2);
  let probLevel;
  for (let levelKey of (Object.keys(levels))) {
      // @ts-ignore
      const level = levels[levelKey];
      if (level.cutoff >= churnProbPercent) {
          probLevel = level;
          break;
      }
  }
  if (!probLevel) {
      probLevel = levels.red;
  }
  const useStyles = makeStyles({
        arrow: {
            marginLeft: `${churnProbPrecision}%`,
            borderLeft: '5px solid transparent',
            borderRight: '5px solid transparent',
            borderBottom: '5px solid black',
            height: '0',
            width: '10px'
        }
  });

  const classes = useStyles(props);
  return <div className='probability-gauge-wrapper'>
      <p>
          {props.t('session.probability-types.prefix')}
          <b>{props.t(probLevel.text)} <span style={{
              color: probLevel.color
          }}>({churnProbPrecision}%)</span>
          </b>
          {props.t('session.probability-types.suffix')}
      </p>
      <div className='probability-gauge-bar'>
          {['green', 'yellow', 'red'].map((i, n) =>
              <div key={n} className={`probability-section probability-gauge-${i}`} />
          )}
      </div>
      <div className={classes.arrow} />
      <br />
  </div>
}
