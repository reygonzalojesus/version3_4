import React from 'react';
// import { TFunction } from 'i18next';
import GridListDataCard from '../../../../deep/components/GridListDataCard';
// import AttributeOptionDetail from '../../../../types/attributeOptionDetail';

/**
 * Data for recommended tips card, with information about customer churn archetype, retention driver,
 * etc.

 */

// interface RecommendedTipsProps {
//   t: TFunction;
//   tips: AttributeOptionDetail[];
// }

function RecommendedTips(props: any) {
  const { render, t, tips } = props;
  React.useEffect(() => {
    if (!props.render && props.t && props.tips) {
      props.onRender(true);
    }
  }, [render, t, tips]);
  let seen_attributes = new Set();
  let newTips: any[] = [];
  if (props.tips) {
    props.tips.forEach((t: any) => {
      t.label = t.attribute.name
        ? t.attribute.name.es
          ? t.attribute.name.es
          : t.attribute.name.en
        : props.t('cco.error.customer-data-unavailable');
      // Patch for churn support behavior -- too late in process to fix how this comes in, so doing this on FE
      if (t.label === 'Apoyo' && t.value && typeof t.value === 'string') {
        let supportSections: any[] = [];
        t.value.split(';').forEach((s: string, i: number) => {
          supportSections.push(<li key={i}>{s}.</li>);
        });
        t.label = ''
        t.value = <ul>{supportSections}</ul>;
      } else if (t.label === 'Probabilidad de Abandono' && t.value) {
        if (typeof t.value === 'string') {
          if (t.value.length > 5) {
            t.value = t.value.substring(0, 5);
          }
        } else if (typeof t.value === 'number') {
          t.value = t.value.toFixed(3);
        }
      }
      if (
        !seen_attributes.has(t.label) &&
        t.label !== 'Probabilidad de Abandono'
      ) {
        if (t.label === 'Apoyo') {
          t.label = '';
        }
  
        seen_attributes.add(t.label);
        newTips.push(t);
      }
    });
  }
  return (
    <>
      {props.tips && (
        <GridListDataCard
          t={props.t}
          data={newTips.map((t: any) => {
              if(t.attribute['code'] === 'support'){
                return t;
              }
              return 0
          })}
        />
      )}
    </>
  );
}

export default RecommendedTips;
