import React from 'react';
import { TFunction } from 'i18next';
import SimpleSwitch from '../../../../deep/components/materials/SimpleSwitch';

export interface ScriptOptionalTabProps {
  children: any;
  t: TFunction;
}

export default function ScriptOptionalTab(props: ScriptOptionalTabProps) {
  const [scriptsEnabled, setScriptsEnabled] = React.useState(true);

  return (
    <>
      <SimpleSwitch
        labelOff={props.t('session.enable-scripts')}
        checked={scriptsEnabled}
        color='#00de7c'
        onChange={() => setScriptsEnabled(!scriptsEnabled)}
      />
      {React.cloneElement(props.children, { scriptsEnabled })}
    </>
  );
}
