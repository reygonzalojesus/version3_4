import React, {useState} from 'react';
import Persona from "../../../../types/persona";
import {Button} from "@material-ui/core";
import {TFunction} from "i18next";
import Dialog from "@material-ui/core/Dialog";
import {makeStyles} from "@material-ui/core/styles";

const _TRELLO_EMAIL = 'willbeddow1+xq3h6vi617ioaudi8mrp@boards.trello.com'

export interface SupportEmailProps {
    me: Persona,
    t: TFunction;
}

interface SupportModalProps {
    onClose: () => any;
    open: boolean;
    t: TFunction;
    handleConfirm: () => any;
}

function SupportModal(props: SupportModalProps) {
    const useStyles = makeStyles({
        paper: {
            padding: '3rem',
            minWidth: '40rem',
            borderRadius: '0.6rem'
        },
        button: {
            textTransform: 'none',
            fontSize: '1.3rem',
            fontWeight: 600,
            margin: '0rem 1rem',
            paddingLeft: '1.7rem',
            paddingRight: '1.7rem',
            borderRadius: '1.8rem'
        },
        message: {
            fontSize: '2rem',
            fontWeight: 600,
            textAlign: 'center',
            marginTop: '1rem'
        },
    });
    const classes = useStyles();
    return <Dialog
        onClose={props.onClose}
        aria-labelledby='confirmation'
        open={props.open}
        classes={{ paper: classes.paper }}
        disableBackdropClick={true}
        disableEscapeKeyDown={true}
    >
        <div className={classes.message}>{props.t('session.contact-support')}</div>
        <div style={{ textAlign: 'center' }}>
            <p>
                {props.t('session.support-modal')}
            </p>
            <Button
                variant='outlined'
                color='primary'
                disableElevation
                size='small'
                classes={{
                    root: classes.button
                }}
                onClick={props.onClose}
            >
                {props.t('session.close-support-modal')}
            </Button>
            <Button
                variant='contained'
                color='primary'
                disableElevation
                size='small'
                classes={{
                    root: classes.button
                }}
                onClick={props.handleConfirm}
            >
                {props.t('session.support-modal-ok')}
            </Button>
        </div>
    </Dialog>
}

export default function SupportEmail(props: SupportEmailProps) {
    const [modalOpen, setModalOpen] = useState(false);
    const subject = `Asunto: [RESUMEN DEL PROBLEMA AQUÍ]`
    const body = `Correo: ${props.me.user.email}\nID: ${props.me.user.id}\nNombre: ${props.me.user.first_name} ${props.me.user.last_name}\n\nDescripción: [DESCRIBA AQUÍ SU PROBLEMA]\n\nOcurrió en ${new Date().toLocaleString()}\nEn la página: ${window.location.href}`;
    const mailtoLink = `mailto:${_TRELLO_EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
    return <>
        <SupportModal
            open={modalOpen}
            onClose={() => setModalOpen(false)}
            handleConfirm={() => {
                window.open(mailtoLink, '_newtab')
                setModalOpen(false);
            }}
            t={props.t}
        />
        <Button onClick={() => setModalOpen(true)}
                variant='outlined'
                color='primary'
                disableElevation
                size='large'
        >
            {props.t('session.contact-support')}
        </Button>
    </>
}