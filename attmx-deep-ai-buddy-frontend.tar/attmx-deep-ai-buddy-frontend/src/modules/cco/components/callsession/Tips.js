import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import i18next from 'i18next';
import CallSessionContext from './../../contexts/CallSessionProvider';

class Tips extends Component {
  static contextType = CallSessionContext;

  UNSAFE_componentWillMount() {
    this.rendered = false;
  }

  componentDidUpdate() {
    if (
      !this.rendered &&
      this.context.selectedOpportunity &&
      this.context.tips
    ) {
      this.rendered = true;
      this.props.onRender(true);
    }
  }

  formatOffer(opportunity) {
    if (!opportunity || !opportunity.offer) {
      return null;
    }

    let dataFormatted = {
      type:
        opportunity.offer.type[i18next.language] ||
        opportunity.offer.type[i18next.options.fallbackLng[0]],
      argument_sentence:
        opportunity.offer.argument_sentence[i18next.language] ||
        opportunity.offer.argument_sentence[
          i18next.options.fallbackLng[0]
        ]
    };

    return dataFormatted;
  }

  formaTips(data) {
    if (!data) {
      return null;
    }

    let dataFormatted = [];

    data.forEach((item) => {
      dataFormatted.push({
        sentence:
          item.sentence[i18next.language] ||
          item.sentence[i18next.options.fallbackLng[0]]
      });
    });

    return dataFormatted;
  }

  render() {
    const offer = this.formatOffer(this.context.selectedOpportunity);
    const tips = this.formaTips(this.context.tips);

    const styles = {
      label: {
        color: '#4C4C4C',
        fontWeight: 600
      },
      value: {
        color: '#777777'
      },
      divider: {
        margin: '0.8rem 0rem 1rem'
      },
      ul: {
        margin: 0,
        padding: '0.3rem 0rem 0.3rem 1.4rem'
      },
      li: {
        color: '#777777',
        margin: 0,
        padding: '0.2rem 0rem',
        lineHeight: 1.4
      }
    };

    return (
      <div>
        <div style={styles.label}>
          {this.props.t('session.tips.lbl-offer-type')}
        </div>
        <div style={styles.value}>
          <ul style={styles.ul}>
            <li style={styles.li}>{offer.type}</li>
            <li style={styles.li}>{offer.argument_sentence}</li>
          </ul>
        </div>
        <div style={{ ...styles.label, ...{ marginTop: '2rem' } }}>
          {this.props.t('session.tips.lbl-tips')}
        </div>
        {tips && tips.length > 0 && (
          <div>
            <ul style={styles.ul}>
              {tips.map((item, index) => (
                <li key={index} style={styles.li}>
                  {item.sentence}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    );
  }
}

export default withTranslation('cco')(Tips);
