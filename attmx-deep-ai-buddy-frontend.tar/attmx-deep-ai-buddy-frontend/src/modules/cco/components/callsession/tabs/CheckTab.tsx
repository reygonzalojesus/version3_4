import React from 'react';
import ScriptRender from '../../../../../deep/components/ScriptRender';
import { Checkbox, Grid } from '@material-ui/core';
import Persona from '../../../../../types/persona';
import Customer from '../../../../../types/customer';

interface CheckTabProps {
  staticScripts: any;
  customer: Customer;
  me: Persona;
  scriptsEnabled?: boolean;
}

function CheckTab(props: CheckTabProps) {
  return (
  <>
    {props.scriptsEnabled && <><ScriptRender content={props.staticScripts.check} />
      <br />
      <ScriptRender
        content={props.staticScripts.end_accepted}
        renderer={(scripts: string[]) => {
          let renderedChecks: any[] = [];

          for (let i = 0; i <= scripts.length; i++) {
            let script = scripts[i];
            if (script && script.length > 1) {
              renderedChecks.push(
                <Grid item key={`check_${i}`} xs={10}>
                  <Checkbox size={'small'} />
                  <span
                    dangerouslySetInnerHTML={{
                      __html: script
                    }}
                  />
                </Grid>
              );
            }
          }
          return (
            <Grid container spacing={3} direction={'row'}>
              {renderedChecks}
            </Grid>
          );
        }}
        replacements={{
          '[Nombre del agente]': props.me.nickname,
          '[Nombre del cliente]': ` ${props.customer.firstname} `,
          '[NOMBRE AGENTE]': props.me.nickname,
          '_______': ` ${props.customer.lastname} `
        }}
      /></>}
    </>
  );
}

export default CheckTab;
