import React from 'react';
import { withTranslation } from 'react-i18next';
import { withStyles } from '@material-ui/core/styles';
import { TFunction } from 'i18next';
import Opportunity from '../../../../../types/opportunity';
import AttributeOption from '../../../../../types/attributeOption';
import DropDownList from '../../../../../deep/components/materials/DropDownList';
import GroupedDropDownList from '../../../../../deep/components/materials/GroupedDropDownList';
import Content from '../../../../../types/content';
import ScriptRender from '../../../../../deep/components/ScriptRender';
import OfferButtons, { OfferOutcome } from './offerladder/OfferButtons';

import ScriptOptionalTab from '../ScriptOptionalTab';
import { groupBy } from 'lodash';
interface ExplorationTabProps {
  t: TFunction;
  opportunity: Opportunity;
  archetypes: any;
  churnArchetypeOption: AttributeOption;
  onChangeChurnArchetype: (c: any) => any;
  selectedOffer: any;
  onChangeOffer: (c: any) => any;
  selectedChurnArchetype: any;
  staticScripts: { [name: string]: Content };
  recordArchetype: () => any;
  archetypeRecorded: boolean;
  scriptsEnabled?: boolean;
  classes: any;
  selectedOutcome: OfferOutcome;
  onChangeOutcome: (status: OfferOutcome) => any;
}
const styles = {
  label: {
    color: '#4C4C4C',
    fontWeight: 600,
    textAlign: 'left',
    width: '100%',
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    fontSize: '1.7rem',
    marginBottom: '0.7rem'
  },
  dropdown: {
    marginBottom: '1em'
  },
  hr: {
    margin: '20px 15%',
    lineHeight: '1px',
    height: '1px'
  },
  additionalOffers: {
    display: 'flex'
  },
  additionalOffer: {
    // fontSize: '1.em',
    padding: '1em',
    margin: '1em',
    textAlign: 'center',
    borderRadius: '200px',
    boxShadow: '1px 1px 1px 1px rgba(122, 122, 122, 0.52)',
    position: 'relative',
    fontSize: '1.2rem'
  },
  outcomeTitle: {
    marginBottom: '2em'
  }
};
function LocalScriptRender(props: any) {
  return props.scriptsEnabled && <ScriptRender content={props.content} />;
}
function groupRules(t: any, rules: any) {
  return Object.entries(groupBy(rules, 'display'))
    .map(([idx, offers]) => {
      let label;
      const index = parseInt(idx);
      const items = offers.map((rule: any) => ({
        
        ...rule.offer,
        expectation: rule.value,
        label: 'test-' + rule.value + rule.offer.id + rule.offer.description, //
        value: {
          ...rule.offer,
          expectation: rule.value,
          label: rule.offer.description
        }
      }));
      switch (index) {
        case 0:
          label = 'Unavailable';
          return;

        case 1:
          label = 'Optimizadas Indenpendietes del Motivo';
          break;
        case 2:
          label = 'Con el motivo';
          break;
      }
      return {
        index,
        label,
        items
      };
    })
    .filter(Boolean)
    .sort((a, b) => b.index - a.index);
}
function ExplorationTab(props: ExplorationTabProps) {
  console.log(props.selectedChurnArchetype?.rules);
  const groupedOffers = groupRules(
    props.t,
    props.selectedChurnArchetype?.rules
  );
  console.log(groupedOffers);
  return (
    <>
      <div className={props.classes.label}>
        {props.t('session.feedback.title-select-churn')}
      </div>
      <div className={props.classes.dropdown}>
        <DropDownList
          options={props.archetypes.map((arch: any) => ({
            ...arch,
            label: arch.name,
            value: arch
          }))}
          size='small'
          placeholder={props.t('session.feedback.lbl-select-churn')}
          value={props.selectedChurnArchetype}
          onChange={props.onChangeChurnArchetype}
        />
      </div>

      {props.selectedChurnArchetype && (
        <>
          <hr className={props.classes.hr} />
          <ScriptOptionalTab t={props.t}>
            <LocalScriptRender content={props.selectedChurnArchetype.content} />
          </ScriptOptionalTab>
        </>
      )}

      {props.selectedChurnArchetype && (
        <>
          <hr className={props.classes.hr} />
          <div className={props.classes.label}>
            {props.t('session.feedback.title-select-offer')}
          </div>

          <GroupedDropDownList
            groups={groupedOffers}
            size='small'
            placeholder={props.t('session.feedback.lbl-select-offer')}
            value={props.selectedOffer}
            onChange={props.onChangeOffer}
          />
          {props.selectedChurnArchetype?.additional_actions.length > 0 && (
            <>
              <hr className={props.classes.hr} />
              <div className={props.classes.label}>
                {props.t('session.feedback.title-additional-offer')}
              </div>
              <div className={props.classes.additionalOffers}>
                {props.selectedChurnArchetype.additional_actions.map(
                  (additional, idx) => (
                    <span key={idx} className={props.classes.additionalOffer}>
                      {additional}
                    </span>
                  )
                )}
              </div>
            </>
          )}
          <hr className={props.classes.hr} />
        </>
      )}
      {props.selectedOffer && (
        <>
          <div className={props.classes.label}>
            {props.t('session.feedback.title-select-outcome')}
          </div>
          <div className={props.classes.outcomeTitle}>
            <b>Oferta final selectionada:</b>
            <span className={props.classes.additionalOffer}>
              {props.selectedOffer.name}
            </span>
          </div>

          <OfferButtons
            selectedOutcome={props.selectedOutcome}
            onChangeOutcome={props.onChangeOutcome}
            t={props.t}
          />
        </>
      )}
    </>
  );
}

export default withTranslation('cco')(withStyles(styles)(ExplorationTab));
