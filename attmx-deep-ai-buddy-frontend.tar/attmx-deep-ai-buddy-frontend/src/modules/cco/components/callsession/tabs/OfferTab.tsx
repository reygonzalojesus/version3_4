import React from 'react';
import {TFunction} from 'i18next';
import SmartTextarea from 'deep/components/materials/SmartTextarea';
import Opportunity from '../../../../../types/opportunity';
import OfferButtons, {OfferOutcome} from './offerladder/OfferButtons';
import OfferLadderOffers from '../../../../../types/offerLadderOffers';
import ScriptRender from '../../../../../deep/components/ScriptRender';
import VerticalTabMenu from "../../../../../deep/components/materials/VerticalTabMenu";

export interface OfferStatus {
  offerLadderOffer: OfferLadderOffers;
  status: OfferOutcome;
  comment: any;
}

interface OfferTabProps {
  onChangeOutcome: (offerIdx: number, status: OfferOutcome) => any;
  onChangeOfferComment: (offerIdx: number, comment: string) => any;
  customOfferStatus: OfferOutcome;
  customOfferComment: any;
  onChangeCustomOfferStatus: (status: OfferOutcome) => any;
  onChangeCustomOfferComment: (comment: any) => any;
  selectedOutcome: any;
  offers: OfferStatus[];
  opportunity: Opportunity;
  t: TFunction;
  outcomes: any;
  outcomeAcceptedId: any;
  outcomeNotOfferedId: any;
  outcomeRejectedId: any;
  outcomeUndecidedId: any;
  scriptsEnabled?: boolean;
}

interface OfferSectionProps {
  status: OfferStatus;
  onOfferStatusChange: (status: OfferOutcome) => any;
  onOfferCommentChange: (comment: string) => any;
  t: TFunction;
  num: number;
  scriptsEnabled?: boolean;
}

function OfferSection(props: OfferSectionProps) {
  return (
    <>
      <h3>Oferta {props.num}</h3>
      <b>{props.status.offerLadderOffer.offer.name}</b>
      <br />
      {props.scriptsEnabled && <ScriptRender content={props.status.offerLadderOffer.content} /> }
      <br />
      <>
        <div>Oferta Comentarios</div>
        <div>
          <SmartTextarea
            placeholder={props.status.comment}
            maxLength='3000'
            onChange={(value: any) => props.onOfferCommentChange(value)}
          />
        </div>
      </>
      <OfferButtons
        selectedOutcome={props.status.status}
        onChangeOutcome={props.onOfferStatusChange}
        t={props.t}
      />
    </>
  );
}

function OfferTab(props: OfferTabProps) {
  let seenOffers = new Set();
  let rawOffers: any[] = [];
  props.offers.sort((a, b) => {
      const aValue = (a.offerLadderOffer.offer_value? a.offerLadderOffer.offer_value as number : 0);
      const bValue = (b.offerLadderOffer.offer_value? b.offerLadderOffer.offer_value as number : 0);
      return (aValue === bValue ? 0 : (
          aValue > bValue ? -1 : 1
      ))
  }).forEach((p) => {
    if (!seenOffers.has(p.offerLadderOffer.offer.name)) {
      rawOffers.push(p);
      seenOffers.add(p.offerLadderOffer.offer.name);
    }
  });


  let tabs: any[] = [];
  rawOffers.forEach((o: OfferStatus, i) => {
      const offerValue: number | string = (o.offerLadderOffer.offer_value ? o.offerLadderOffer.offer_value: 0).toFixed(2);
      let description;
      if (Number.parseFloat(offerValue) > 0) {
          description = `Value: ${offerValue}$`
      } else {
          description = ""
      }
      tabs.push({
          name: `Oferta ${i+1}`,
          alt_name: o.offerLadderOffer.offer.name,
          description: description,
          body: <OfferSection
              key={i}
              num={i+1}
              status={o}
              scriptsEnabled={props.scriptsEnabled}
              onOfferStatusChange={(s) => {
                  props.onChangeOutcome(i, s);
              }}
              onOfferCommentChange={(v) => {
                  props.onChangeOfferComment(i, v)
              }}
              t={props.t}
          />
      })
  });
  tabs.push({
      name: props.t('session.custom-offer'),
      alt_name: props.t('session.custom-offer-construct'),
      description: '',
      body: <>
          <br />
          <b>{props.t('session.custom-offer-instructions')}</b>
          <br />
          <>
              <div>Oferta Comentarios</div>
              <div>
                  <SmartTextarea
                      maxLength='3000'
                      placeholder={props.customOfferComment}
                      onChange={(value: any) => props.onChangeCustomOfferComment(value)}
                  />
              </div>
          </>
          <OfferButtons
              selectedOutcome={props.customOfferStatus}
              onChangeOutcome={props.onChangeCustomOfferStatus}
              t={props.t}
          />
      </>
  })
  return <VerticalTabMenu
      children={tabs}
  />
}

export default OfferTab;
