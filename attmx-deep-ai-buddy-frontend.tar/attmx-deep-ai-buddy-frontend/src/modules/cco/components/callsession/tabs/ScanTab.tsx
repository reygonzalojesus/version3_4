import React from 'react';
import { TFunction } from 'i18next';
import Opportunity from '../../../../../types/opportunity';
import AttributeOption from '../../../../../types/attributeOption';
import DropDownList from '../../../../../deep/components/materials/DropDownList';
import Content from '../../../../../types/content';
import ScriptRender from '../../../../../deep/components/ScriptRender';
import { Button } from '@material-ui/core';

interface ScanTabProps {
  t: TFunction;
  opportunity: Opportunity;
  churnArchetypeOption: AttributeOption;
  onChangeChurnArchetype: (c: any) => any;
  selectedChurnArchetype: any;
  staticScripts: { [name: string]: Content };
  recordArchetype: () => any;
  archetypeRecorded: boolean;
  scriptsEnabled?: boolean;
}

function ScanTab(props: ScanTabProps) {
  /**
     * // TODO: once we figure out where we're putting churn archetype in discovery segment, do that
     * instead of hardcoding this
    const churnOptionDetails = (props.churnArchetypeOption.options as AttributeOptionDetail[]);
    const churnAttributeOptions = churnOptionDetails.map((o) => ({
        id: o.id,
        value: o.value,
        label: o.name
    }));
     **/
  const churnAttributeOptions = [];

  return (
    <>
      {props.scriptsEnabled && (
        <div>
          <ScriptRender content={props.staticScripts.scan} />
        </div>
      )}
      <br />
      <DropDownList
        options={churnAttributeOptions}
        placeholder={props.t('session.feedback.lbl-select-churn')}
        value={props.selectedChurnArchetype}
        onChange={props.onChangeChurnArchetype}
      />
      <Button
        onClick={props.recordArchetype}
        disabled={props.archetypeRecorded}
        variant='contained'
        color={'primary'}
        disableElevation
        disableRipple
      >
        {props.t('session.feedback.record-archetype')}
      </Button>
    </>
  );
}

export default ScanTab;
