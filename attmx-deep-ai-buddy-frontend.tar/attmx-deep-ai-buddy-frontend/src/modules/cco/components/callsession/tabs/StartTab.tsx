import React from 'react';
import { TFunction } from 'i18next';
import Customer from '../../../../../types/customer';
import Persona from '../../../../../types/persona';
import ClientSettings from '../../../../../types/clientSettings';
import Opportunity from '../../../../../types/opportunity';
import ScriptRender from '../../../../../deep/components/ScriptRender';

interface StartTabProps {
  t: TFunction;
  customer: Customer;
  me: Persona;
  clientSettings: ClientSettings;
  opportunity: Opportunity;
  staticScripts: any;
  scriptsEnabled?: boolean;
}

/**
 * The start script for the agent -
 * greeting sentence and first part of script
 *
 */
function StartTab(props: StartTabProps) {
  return (
    <div>
      {props.scriptsEnabled && (
        <ScriptRender
          content={props.staticScripts.start}
          replacements={{
            '{{persona}}': props.me.nickname,
            '{{customer}}': ` ${props.customer.firstname} `,
            '[Nombre del agente]': props.me.nickname,
            '[Nombre del cliente]': ` ${props.customer.firstname} `,
            '[NOMBRE AGENTE]': props.me.nickname,
            _______: ` ${props.customer.lastname} `
          }}
        />
      )}
    </div>
  );
}

export default StartTab;
