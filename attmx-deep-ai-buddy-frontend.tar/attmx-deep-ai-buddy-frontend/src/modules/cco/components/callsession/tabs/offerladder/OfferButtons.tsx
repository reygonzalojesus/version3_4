import React from 'react';
import styles from '../../Feedback.module.css'
import {TFunction} from "i18next";
import {Box} from "@material-ui/core";

export enum OfferOutcome {
    NotSelected = "notoffered",
    NotProposed = "notproposed",
    Accepted = "accepted",
    Rejected = "rejected"
}

interface OfferButtonProps {
    selectedOutcome: OfferOutcome;
    onChangeOutcome: (o: OfferOutcome) => any;
    t: TFunction;
}

interface OfferChipProps {
    selectedOutcome: OfferOutcome;
    onChangeOutcome: (o: OfferOutcome) => any;
    activeOutcome: OfferOutcome;
    chipStyle: any;
    chipText: any;
}

function OfferChip(props: OfferChipProps) {
    return  <div
        className={`
                        ${styles.Chip}
                        ${props.chipStyle}
                        ${props.selectedOutcome === props.activeOutcome ? styles.Active : ''}
                   `}
        onClick={() => {
            props.onChangeOutcome(props.activeOutcome)
        }}
    >
        {props.chipText}
    </div>
}

function OfferButtons(props: OfferButtonProps) {
    return <>
        <div className={styles.ChipsContainer}>
            <Box className={styles.ChipsBorder}>
                <OfferChip selectedOutcome={props.selectedOutcome}
                           onChangeOutcome={props.onChangeOutcome}
                           activeOutcome={OfferOutcome.Accepted}
                           chipStyle={styles.Accepted}
                           chipText={props.t('session.feedback.tab-outcome-accepted')} />
                <OfferChip
                           selectedOutcome={props.selectedOutcome}
                           onChangeOutcome={props.onChangeOutcome}
                           activeOutcome={OfferOutcome.NotProposed}
                           chipStyle={styles.NotProposed}
                           chipText={props.t('session.feedback.tab-outcome-notoffered')}
                />
                <OfferChip selectedOutcome={props.selectedOutcome}
                           onChangeOutcome={props.onChangeOutcome}
                           activeOutcome={OfferOutcome.Rejected}
                           chipStyle={styles.Rejected}
                           chipText={props.t('session.feedback.tab-outcome-rejected')} />
            </Box>
        </div>
    </>
}

export default OfferButtons;