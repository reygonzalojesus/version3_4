import React, { Component } from 'react';
import * as CcoApi from './../api/endpoints';
import * as MwHistory from 'utils/MwHistory';
import getCustomer from 'modules/cco/api/endpoints/getCustomer.ts';
import getCustomerAttributeOptions from '../api/endpoints/getCustomerAttributeOptions';
import getContentByCode from '../api/endpoints/getContentByCode';
import getCustomerPersonalAttributes from '../api/endpoints/getCustomerPersonalAttributes';
import getOffersByCustomer from '../api/endpoints/getOffersByCustomer';
import getAttributesByCode from '../api/endpoints/getAttributesByCode';
import getArchetypes from '../api/endpoints/getArchetypes';
import getOrdersIncidentsBillsForCustomer from '../api/endpoints/getOrdersIncidentsBillsForCustomer';
import getDataUsage from '../api/endpoints/getDataUsage';

const CallSessionContext = React.createContext();

class CallSessionProvider extends Component {
  constructor(props) {
    super(props);
    this.state = {
      archetypes: null,
      customer: null,
      selectedCampaign: null,
      selectedOpportunity: null,
      selectedProduct: null,
      selectedCollection: null,
      selectedCollectionAnswer: null,
      selectedArchetype: null,
      selectedOffer: null,
      allProducts: null,
      portfolio: null,
      interactionHistory: null,
      relationship: null,
      bill: null,
      campaigns: null,
      personalAttributes: null,
      products: null,
      allOpportunities: null,
      opportunities: null,
      outcomes: null,
      outcomeAcceptedId: null,
      outcomeNotOfferedId: null,
      outcomeRejectedId: null,
      reasons: null,
      quarantines: null,
      features: null,
      tips: null,
      collections: null,
      customerAttributeOptions: null,
      churnArchetypeOption: null,
      staticScripts: {},
      offerLadder: [],
      history: null,
      attributeTips: null,
      customerSubscribers: null,
      orders: null,
      incidents: null,
      dataUsage: null,
      subscriberId: null,
      Smartarchetypes: null,
    };
  }
  //TODO
  async loadSubscriber(subscriberId, customerId) {
    CcoApi.getContractSubscribers(customerId).then((data) => {
      this.setState({
        subscriberId,
        subscribers: data
      });
      this.loadArchetypes(subscriberId);
    });
  }

  async loadCustomer(customerId) {
    try {
      const result = await getCustomer(customerId);
      this.onCustomerSucceed(result);
    } catch (error) {
      MwHistory.replace('/404/');
    }
  }

  onCustomerSucceed(customer) {
    this.setState({ customer: customer });
    this.loadAllProducts(customer.id);
    this.loadCustomerAttributeOptions();
    this.loadPortfolio(customer.src_client_id);
    this.loadInteractionHistory(customer.src_client_id);
    this.loadRelationship(customer.id);
    this.loadOrdersIncidents(customer.src_client_id);
    this.loadStaticContent();
    this.loadCampaigns(customer.src_client_id);
    this.loadOutcomes();
    this.loadCollectionData(customer.id);
    this.loadDataUsage(customer.id);
    this.loadQuarantines();
  }

  async loadCustomerAttributeOptions() {
    getCustomerAttributeOptions().then((o) => {
      // Pull out the churn archetype, and put everything in the state
      const churnArchetypeOption = o.find((s) => s.code === 'CHURN_ARCHETYPE');
      this.setState({
        churnArchetypeOption: churnArchetypeOption,
        customerAttributeOptions: o
      });
    });
  }
  async loadArchetypes(subscriberId) {
    const result = await getArchetypes(subscriberId);
    this.setState({ archetypes: result });
  }
 
  async loadAllProducts() {
    const result = await CcoApi.getProducts();
    this.setState({ allProducts: result });
  }

  async loadPortfolio(customerId) {
    const result = await CcoApi.getCustomerContracts(customerId);
    this.setState({ portfolio: result });
  }

  async loadInteractionHistory(customerId) {
    const result = await CcoApi.getCustomerInteractionHistory(customerId);
    this.setState({ interactionHistory: result });
  }

  async loadRelationship(customerId) {
    const result = await CcoApi.getRelationship(customerId);
    this.setState({ relationship: result });
  }

  async loadOrdersIncidents(customerId) {
    getOrdersIncidentsBillsForCustomer(customerId).then((ordersIncidents) => {
      this.setState({
        orders: ordersIncidents.orders,
        incidents: ordersIncidents.incidents,
        bill: ordersIncidents.payments,
        customerSubscribers: ordersIncidents.subscribers
      });
    });
  }

  async loadCampaigns(customerId) {
    const result = await CcoApi.getCustomerCampaigns(customerId);
    this.onCampaignsSucceed(result);
  }

  async loadStaticContent() {
    // Load the content that's the same for every session
    let scripts = {};
    const callScriptCodes = [
      'start',
      'scan',
      'end_accepted',
      'end_rejected',
      'check'
    ];
    // Load all the static content scripts in a batch
    await Promise.all(
      callScriptCodes.map(
        (k) =>
          new Promise((resolve, reject) => {
            getContentByCode(k).then((c) => {
              scripts[k] = c;
              resolve();
            });
          })
      )
    );
    this.setState({ staticScripts: scripts });
  }

  onCampaignsSucceed(data) {
    const selectedCampaign = data.length > 0 ? data[0] : null;
    this.setState({
      campaigns: data,
      selectedCampaign: selectedCampaign
    });
    if(this.state.customer !== null){
      if (selectedCampaign) {
        this.loadOpportunities(
          this.state.customer.src_client_id,
          selectedCampaign.id
        );
      }
      this.loadPersonalAttributes(
        this.state.customer.src_client_id,
        selectedCampaign?.type.id
      ); 
    }

  }

  async loadOpportunities(customerId, campaignId) {
    const result = await CcoApi.getCustomerOpportunities(
      customerId,
      campaignId
    );
    await this.loadOfferLadder(customerId);
    this.onOpportunitiesSucceed(result);
  }

  async loadOfferLadder(customerId) {
    let offerLadder = await getOffersByCustomer(customerId);
    this.setState({ offerLadder: offerLadder });
  }

  onOpportunitiesSucceed(data) {
    this.setState({ allOpportunities: data });
    this.populateProducts(data);
    this.populateOpportunities(data, this.state.selectedProduct?.id);
    this.loadReasons(
      this.state.selectedCampaign?.type.id,
      this.state.selectedProduct?.id
    );
    this.loadProductFeatures(this.state.selectedProduct?.id);
  }

  async loadPersonalAttributes(customerId, campaignTypeId) {
    await Promise.all([
      getCustomerPersonalAttributes(customerId, campaignTypeId).then((r) =>
        this.setState({ personalAttributes: r })
      ),
      getAttributesByCode(customerId, 'history', campaignTypeId).then((r) =>
        this.setState({ history: r })
      ),
      getAttributesByCode(customerId, 'tips', campaignTypeId).then((r) => {
        this.setState({ attributeTips: r });
      }),

    ]);
  }

  populateProducts(opportunities) {
    let ids = [];
    const products = [];
    opportunities.forEach((opportunity) => {
      if (opportunity.product && !ids.includes(opportunity.product.id)) {
        ids.push(opportunity.product.id);
        products.push({
          id: opportunity.product.id,
          price: opportunity.product.price,
          propensity: opportunity.propensity,
          name: opportunity.product.name
        });
      }
    });

    let selectedProduct = products.length > 0 ? products[0] : null;
    this.setState({
      products: products,
      selectedProduct: selectedProduct
    });
  }
  // yieldOthersOpportunities = function* (opportunity) {
  //   if (opportunity?.offer?.others !== undefined) {
  //     for (const offer of opportunity?.offer?.others) {
  //       yield { ...opportunity, offer };
  //     }
  //   }
  // };
  populateOpportunities(allOpportunities, productId) {
    let opportunities = [];
    let knownOpportunities = new Set();

    allOpportunities.forEach((opportunity) => {
      if (opportunity.product?.id === productId || !opportunity.product) {
        if (!knownOpportunities.has(opportunity.id)) {
          knownOpportunities.add(opportunity.id);
          opportunities.push(opportunity);
        }
      }
    });

    // if (opportunities.length === 1) {
    //   opportunities = opportunities.concat(
    //     ...this.yieldOthersOpportunities(opportunities[0])
    //   );
    // }

    let selectedOpportunity = null;
    if (opportunities.length > 0) {
      selectedOpportunity = opportunities[0];
    }
    this.setState({
      opportunities: opportunities,
      selectedOpportunity: selectedOpportunity
    });
    if (selectedOpportunity !== null){
      this.loadTips(selectedOpportunity.id);
    }
  }

  async loadOutcomes() {
    const result = await CcoApi.getOutcomes();
    let outcomeAcceptedId = 0;
    let outcomeNotOfferedId = 0;
    let outcomeRejectedId = 0;
    let outcomeUndecidedId = 0;

    result.forEach((item) => {
      if (item.code === 'accepted') {
        outcomeAcceptedId = item.id;
      } else if (item.code === 'not_proposed') {
        outcomeNotOfferedId = item.id;
      } else if (item.code === 'rejected') {
        outcomeRejectedId = item.id;
      } else if (item.code === 'undecided') {
        outcomeUndecidedId = item.id;
      }
    });

    this.setState({
      outcomes: result,
      outcomeAcceptedId: outcomeAcceptedId,
      outcomeNotOfferedId: outcomeNotOfferedId,
      outcomeRejectedId: outcomeRejectedId,
      outcomeUndecidedId: outcomeUndecidedId
    });
  }

  async loadReasons(campaignTypeId, productId) {
    const result = await CcoApi.getReasons(campaignTypeId, productId);
    this.setState({ reasons: result });
  }

  async loadQuarantines(campaignTypeId, productId) {
    const result = await CcoApi.getQuarantines();
    this.setState({ quarantines: result });
  }

  async loadProductFeatures(productId) {
    if (productId) {
      const result = await CcoApi.getProductsFeatures(productId);
      this.setState({ features: result });
    }
  }

  async loadTips(opportunityId) {
    const result = await CcoApi.getOpportunityTips(opportunityId);
    this.setState({ tips: result });
  }

  async loadDataUsage(customerId) {
    const result = await getDataUsage(customerId);
    this.setState({
      dataUsage: result
    });
  }

  loadCollectionData = async (customerId) => {
    const result = await CcoApi.getCollectionForCustomer(customerId);
    this.setState({
      collections: result,
      selectedCollection: result.length ? result[0] : null
    });
  };

  load = (customerId, subscriberId) => {
    this.loadCustomer(customerId);
    this.loadSubscriber(subscriberId, customerId);
  };
  setSelectedArchetype = (archetype) => {
    this.setState({
      selectedArchetype: archetype
    });
  };
  setSelectedOffer = (offer) => {
    this.setState({
      selectedOffer: offer
    });
  };
  setSelectedCampaign = (campaign) => {
    this.setState({
      selectedCampaign: campaign,
      selectedOpportunity: null,
      selectedProduct: null
    });
    this.loadOpportunities(this.state.customer.src_client_id, campaign.id);
    this.loadPersonalAttributes(
      this.state.customer.src_client_id,
      campaign.type.id
    );
  };
  setSelectedOpportunity = (opportunity) => {
    this.setState({
      selectedOpportunity: opportunity,
      selectedProduct: null
    });
    this.loadTips(opportunity.id);
  };
  setSelectedProduct = (product) => {
    this.setState({ selectedProduct: product });
    this.populateOpportunities(this.state.allOpportunities, product.id);
    this.loadReasons(this.state.selectedCampaign?.type.id, product.id);
    this.loadProductFeatures(product.id);
  };
  setSelectedCollectionQuestion = (question) => {
    this.setState({
      selectedCollection: question
    });
  };
  setSelectedCollectionAnswer = (answer) => {
    this.setState({
      selectedCollectionAnswer: answer
    });
  };

  render() {
    const { children } = this.props;
    const {
      archetypes,
      customer,
      selectedCampaign,
      selectedArchetype,
      selectedOffer,
      selectedOpportunity,
      selectedProduct,
      selectedCollection,
      selectedCollectionAnswer,
      allProducts,
      portfolio,
      interactionHistory,
      relationship,
      bill,
      campaigns,
      personalAttributes,
      products,
      allOpportunities,
      opportunities,
      outcomes,
      outcomeAcceptedId,
      outcomeNotOfferedId,
      outcomeRejectedId,
      outcomeUndecidedId,
      reasons,
      quarantines,
      features,
      tips,
      collections,
      customerAttributeOptions,
      churnArchetypeOption,
      staticScripts,
      offerLadder,
      attributeTips,
      history,
      orders,
      incidents,
      payments,
      subscribers,
      dataUsage,
      subscriberId
    } = this.state;

    const gamificationActive = this.props.appContext.gamificationActive;
    const clientSettings = this.props.appContext.clientSettings;
    const me = this.props.appContext.me;

    const {
      load,
      setSelectedCampaign,
      setSelectedArchetype,
      setSelectedOffer,
      setSelectedOpportunity,
      setSelectedProduct,
      setSelectedCollectionQuestion,
      setSelectedCollectionAnswer,
      loadCollectionData
    } = this;

    return (
      <CallSessionContext.Provider
        value={{
          load,
          gamificationActive,
          clientSettings,
          me,
          archetypes,
          customer,
          selectedCampaign,
          selectedArchetype,
          selectedOffer,
          selectedOpportunity,
          selectedProduct,
          selectedCollection,
          selectedCollectionAnswer,
          allProducts,
          portfolio,
          interactionHistory,
          relationship,
          bill,
          campaigns,
          personalAttributes,
          products,
          allOpportunities,
          opportunities,
          outcomes,
          outcomeAcceptedId,
          outcomeNotOfferedId,
          outcomeRejectedId,
          outcomeUndecidedId,
          reasons,
          quarantines,
          features,
          tips,
          collections,
          customerAttributeOptions,
          churnArchetypeOption,
          subscriberId,
          setSelectedCampaign,
          setSelectedArchetype,
          setSelectedOffer,
          setSelectedOpportunity,
          setSelectedProduct,
          setSelectedCollectionQuestion,
          setSelectedCollectionAnswer,
          loadCollectionData,
          staticScripts,
          offerLadder,
          attributeTips,
          history,
          orders,
          incidents,
          payments,
          subscribers,
          dataUsage
        }}
      >
        {children}
      </CallSessionContext.Provider>
    );
  }
}

export default CallSessionContext;

export { CallSessionProvider };
