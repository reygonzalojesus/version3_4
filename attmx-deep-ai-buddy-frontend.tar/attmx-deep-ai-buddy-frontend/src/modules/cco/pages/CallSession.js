import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { withStyles } from '@material-ui/core/styles';
import { get } from 'lodash';

import Grid from '@material-ui/core/Grid';
import Footer from 'deep/components/Footer';
import ResizableCard from 'deep/components/materials/ResizableCard';
import SimpleCard from 'deep/components/materials/SimpleCard';
import NoOpportunity from './../components/callsession/NoOpportunity';
import Feedback from './../components/callsession/Feedback';
import Comparison from './../components/callsession/Comparison';
import AdditionalProducts from './../components/callsession/AdditionalProducts';
import Navigator from './../components/callsession/Navigator';
import CallSessionContext from './../contexts/CallSessionProvider';
import GamificationContext from 'gamification/contexts/GamificationProvider';
import RecommendedTips from '../components/callsession/RecommendedTips';
import CustomerProfile from '../components/callsession/CustomerProfile';
import CustomerOverview from '../components/callsession/CustomerOverview';
import InteractionHistory from '../components/callsession/InteractionHistory';
import CustomerContext from '../components/callsession/CustomerContext';
import ActiveRetentionBenefits from '../components/callsession/ActiveRetentionBenefits';
import DataUsage from '../components/callsession/DataUsage';
import * as CcoApi from './../api/endpoints';
const styles = (theme) => ({
  wrapper: {
    marginTop: '51px',
    boxShadow: 'inset 0rem 0.3rem 0.4rem 0rem rgba(1,0,0,0.03)',
    padding: '2.4rem 2.4rem 0rem',
    minHeight: 'calc(100vh - 51px)',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-between'
  },
  activity: {
    height: '0.3rem',
    backgroundColor: theme.palette.secondary.main,
    width: 'calc(100vw + 2rem)',
    position: 'fixed',
    top: 0,
    left: '-2rem',
    zIndex: 2000
  },
  content: {
    paddingBottom: '2rem'
  }
});

class CallSession extends Component {
  static contextType = CallSessionContext;

  constructor(props) {
    super(props);
    this.state = {
      cardCustomerDetailsRender: false,
      cardMwHistoryRender: true,
      cardMwInteractionRender: true,
      cardRecommendedTipsRender: false,
      cardBusinessRulesRender: false,
      cardSupportRender: false,
      cardComparisonRender: false,
      cardAdditionalProductsRender: false,
      customerProfileRender: true
    };
  }

  componentDidMount() {
    this.mounted = true;
    window.scrollTo(0, 0);
    const {
      match: { params }
    } = this.props;
    this.searchCustomer(params.customerId);
    this.context.load(params.customerId, params.subscriberId);
  }
  componentWillUnmount() {
    this.mounted = false;
  }
  securSetState(data) {
    if (this.mounted) {
      this.setState(data);
    }
  }
  
  async searchCustomer(customerId) {

    if (customerId === '') {
      this.securSetState({
        searchResults: null,
        searchCustomerID: null,
        searchSubsriberId: null,
        showButton:false,
        customerId:''
      });
    } else {
      try {
        const contract = await CcoApi.validatePermissions(customerId);//antes sin el DN
      } catch (error) {
        if (error.status === 403) {
          this.props.onClose(); 
        } else {
          this.securSetState({
            loading: false,
            error: error
          });
        }
      }
    }
  }

  render() {
    const { classes } = this.props;
    const {
      cardCustomerDetailsRender,
      cardMwHistoryRender,
      cardMwInteractionRender,
      cardRecommendedTipsRender,
      cardComparisonRender,
      cardAdditionalProductsRender,
      customerProfileRender
    } = this.state;

    const { customer, selectedCampaign, selectedOpportunity } = this.context;

    const {
      displayHistory = true,
      displayAdditionalProducts = false,
      displayProfile = false,
      displayRecommendedTips = true,
      displayKnowledgeNavigator = false,
      displayProductComparison = false
    } = get(this.context.clientSettings, 'sessionConfig', {});

    // let tipsTitle = ' ';
    // if (selectedOpportunity && selectedOpportunity.product) {
    //   tipsTitle =
    //     selectedOpportunity.product.name[i18next.language] ||
    //     selectedOpportunity.product.name[i18next.options.fallbackLng[0]];
    // } else if (selectedOpportunity && selectedCampaign) {
    //   tipsTitle =
    //     selectedCampaign.type.name[i18next.language] ||
    //     selectedCampaign.type.name[i18next.options.fallbackLng[0]];
    // }
    return (
      <div className={classes.wrapper}>
        <div className={classes.activity}></div>
        <div className={classes.content}>
          {customer && (
            <div>
              <Grid
                container
                direction='row'
                justify='flex-start'
                alignItems='stretch'
                alignContent='stretch'
                spacing={2}
              >
                <Grid item xs={12} sm={6} md={4} lg={3}>
                  <ResizableCard
                    expanded={true}
                    expandable={true}
                    collapsable={true}
                    resizable={true}
                    featureTitle={this.props.t(
                      'session.customerdetails.card-title'
                    )}
                    contentId='customer_details'
                    childrenRender={cardCustomerDetailsRender}
                  >
                    <CustomerOverview
                      t={this.props.t}
                      orders={this.context.orders}
                      onRender={(render) =>
                        this.securSetState({
                          cardCustomerDetailsRender: render
                        })
                      }
                      history={this.context.history}
                    />
                  </ResizableCard>
                  {displayProfile && (
                    <ResizableCard
                      expandable={false}
                      expanded={true}
                      collapsable={false}
                      resizable={false}
                      featureTitle={this.props.t('session.profile.card-title')}
                      contentId={'customer_profile'}
                      onRender={(render) =>
                        this.securSetState({
                          cardRecommendedTipsRender: render
                        })
                      }
                      children={customerProfileRender}
                    >
                      <CustomerProfile
                        t={this.props.t}
                        portfolio={this.context.portfolio}
                        products={this.context.products}
                      />
                    </ResizableCard>
                  )}
                  {/* <ResizableCard
                    expandable={false}
                    expanded={true}
                    collapsable={false}
                    resizable={false}
                    onRender={(render) =>
                      this.securSetState({ cardSupportRender: render })
                    }
                    featureTtitle={this.props.t('session.contact-support')}
                  >
                    <CustomerHistory onRender={() => {}} />
                  </ResizableCard> */}

                  {displayHistory && (
                    <ResizableCard
                      expanded={true}
                      featureTitle={this.props.t(
                        'session.interaction.card-title'
                      )}
                      contentId='interaction_history'
                      childrenRender={cardMwInteractionRender}
                    >
                      <InteractionHistory
                        t={this.props.t}
                        interactions={this.context.incidents}
                      />
                    </ResizableCard>
                  )}
                </Grid>
                {!(selectedCampaign || selectedOpportunity) && (
                  <Grid item xs={12} sm={6} md={8} lg={9}>
                    <NoOpportunity />
                  </Grid>
                )}
                <Grid item xs={12} sm={5} md={3} lg={5}>
                  <SimpleCard>
                    <CustomerContext
                      t={this.props.t}
                      tips={this.context.attributeTips}
                      history={this.context.history}
                    />
                  </SimpleCard>
                  {selectedOpportunity && (
                    <SimpleCard>
                      <GamificationContext.Consumer>
                        {(gamificationContext) => (
                          <Feedback gamificationContext={gamificationContext} />
                        )}
                      </GamificationContext.Consumer>
                    </SimpleCard>
                  )}
                </Grid>
                <Grid item xs={12} sm={12} md={5} lg={4}>
                  {selectedOpportunity?.product && displayProductComparison && (
                    <ResizableCard
                      expanded={true}
                      collapsable={true}
                      resizable={true}
                      featureTitle={this.props.t(
                        'session.comparison.card-title'
                      )}
                      contentId='comparison'
                      childrenRender={cardComparisonRender}
                    >
                      <Comparison
                        onRender={(render) =>
                          this.securSetState({ cardComparisonRender: render })
                        }
                      />
                    </ResizableCard>
                  )}
                  {displayRecommendedTips && (
                    <ResizableCard
                      expandable={false}
                      expanded={true}
                      collapsable={false}
                      resizable={true}
                      featureTitle={this.props.t(
                        'session.recommended.card-title'
                      )}
                      contentId={'recommended_tips'}
                      childrenRender={cardRecommendedTipsRender}
                    >
                      <RecommendedTips
                        t={this.props.t}
                        tips={this.context.attributeTips}
                        render={cardRecommendedTipsRender}
                        onRender={(render) =>
                          this.securSetState({
                            cardRecommendedTipsRender: render
                          })
                        }
                      />
                  
                    </ResizableCard>
                  )}
                  {displayHistory && (
                    <ResizableCard
                      expanded={true}
                      featureTitle={this.props.t(
                        'session.active-retention-benefits'
                      )}
                      contentId='customer_history'
                      childrenRender={cardMwHistoryRender}
                    >
                      <ActiveRetentionBenefits
                        t={this.props.t}
                        history={this.context.history}
                      />
                    </ResizableCard>
                  )}

                  <ResizableCard
                    featureTitle={this.props.t('session.data-usage.title')}
                    expandable={false}
                    collapsable={false}
                    expanded={true}
                  >
                    <DataUsage
                      t={this.props.t}
                      dataUsage={this.context.dataUsage}
                    />
                  </ResizableCard>
                  {displayAdditionalProducts && (
                    <ResizableCard
                      expandable={true}
                      collapsable={true}
                      resizable={true}
                      featureTitle={this.props.t(
                        'session.additionalproducts.card-title'
                      )}
                      contentId='additional_products'
                      childrenRender={cardAdditionalProductsRender}
                    >
                      <AdditionalProducts
                        onRender={(render) =>
                          this.securSetState({
                            cardAdditionalProductsRender: render
                          })
                        }
                      />
                    </ResizableCard>
                  )}
                  {displayKnowledgeNavigator && <Navigator />}
                </Grid>
              </Grid>
            </div>
          )}
        </div>
        <Footer />
      </div>
    );
  }
}

export default withTranslation('cco')(withStyles(styles)(CallSession));
