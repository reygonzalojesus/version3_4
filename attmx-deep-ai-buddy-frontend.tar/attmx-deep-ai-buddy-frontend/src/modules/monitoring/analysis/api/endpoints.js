import { getRequest } from 'deep/api/utils';
import * as FormatData from './formatdata';
import * as RewriteData from './rewritemockdata';
import * as MwHistory from 'utils/MwHistory';

const MOCKDATA = false;

export function getProducts() {
  const endpoint = 'cco/product?parent__isnull=true&purchasable=true';

  return new Promise(function (resolve, reject) {
    getRequest(endpoint)
      .then((result) => {
        resolve(result.results);
      })
      .catch((error) => {
        switch (error.status) {
          case 403:
            reject(error.status);
            MwHistory.replace('/403');
            break;
          default:
            reject('error.customer-data-unavailable');
            break;
        }
      });
  });
}

export function getOutcomes() {
  let endpoint = 'cco/feedbackoutcome?ordering=order';

  return new Promise(function (resolve, reject) {
    getRequest(endpoint)
      .then((result) => {
        const results = FormatData.outcomes(result.results);
        resolve(results);
      })
      .catch((error) => {
        switch (error.status) {
          case 403:
            reject(error.status);
            MwHistory.replace('/403');
            break;
          default:
            reject('error.customer-data-unavailable');
            break;
        }
      });
  });
}

export function getChannels() {
  let endpoint = 'cco/channel';

  return new Promise(function (resolve, reject) {
    getRequest(endpoint)
      .then((result) => {
        resolve(result.results);
      })
      .catch((error) => {
        switch (error.status) {
          case 403:
            reject(error.status);
            MwHistory.replace('/403');
            break;
          default:
            reject('error.customer-data-unavailable');
            break;
        }
      });
  });
}

export function getCampaignTypes() {
  let endpoint = 'cco/campaigntype';

  return new Promise(function (resolve, reject) {
    getRequest(endpoint)
      .then((result) => {
        resolve(result.results);
      })
      .catch((error) => {
        switch (error.status) {
          case 403:
            reject(error.status);
            MwHistory.replace('/403');
            break;
          default:
            reject('error.customer-data-unavailable');
            break;
        }
      });
  });
}

export function getOverallActiveAgents(begin, end, interval, timelineFilterId) {
  return new Promise(function (resolve, reject) {
    if (MOCKDATA) {
      var json = require('./mockdata/overall_activeagents_' +
        timelineFilterId +
        '.json');
      resolve(RewriteData.overallActiveAgents(json, begin, end, interval));
    } else {
      const beginISO = begin.toISOString();
      const endISO = end.toISOString();
      const endpoint =
        'user/event/stats?begin=' +
        beginISO +
        '&end=' +
        endISO +
        '&interval=' +
        interval;

      getRequest(endpoint)
        .then((result) => {
          resolve(result);
        })
        .catch((error) => {
          switch (error.status) {
            case 403:
              reject(error.status);
              MwHistory.replace('/403');
              break;
            default:
              reject('error.customer-data-unavailable');
              break;
          }
        });
    }
  });
}

export function getOverallActions(
  begin,
  end,
  interval,
  outcomeId,
  timelineFilterId,
  outcomeFilterCode,
  multiCampaignTypesFilter
) {
  return new Promise(function (resolve, reject) {
    if (MOCKDATA) {
      var json = require('./mockdata/overall_actions_' +
        outcomeFilterCode +
        '_' +
        timelineFilterId +
        '.json');
      resolve(
        RewriteData.overallActions(
          json,
          begin,
          end,
          interval,
          timelineFilterId,
          outcomeFilterCode
        )
      );
    } else {
      const beginISO = begin.toISOString();
      const endISO = end.toISOString();
      const endpoint =
        'cco/interaction/stats?begin=' +
        beginISO +
        '&end=' +
        endISO +
        '&interval=' +
        interval +
        '&outcome=' +
        outcomeId;
      getRequest(endpoint)
        .then((result) => {
          resolve(result);
        })
        .catch((error) => {
          switch (error.status) {
            case 403:
              reject(error.status);
              MwHistory.replace('/403');
              break;
            default:
              reject('error.customer-data-unavailable');
              break;
          }
        });
    }
  });
}

export function getOverallAverage(
  begin,
  end,
  outcomeId,
  interval,
  timelineFilterId,
  outcomeFilterCode,
  multiCampaignTypesFilter
) {
  return new Promise(function (resolve, reject) {
    if (MOCKDATA) {
      var jsonActiveAgents = require('./mockdata/overall_activeagents_' +
        timelineFilterId +
        '.json');
      const resultActiveAgents = RewriteData.overallActiveAgents(
        jsonActiveAgents,
        begin,
        end,
        interval
      );
      var jsonActions = require('./mockdata/overall_actions_' +
        outcomeFilterCode +
        '_' +
        timelineFilterId +
        '.json');
      const resultActions = RewriteData.overallActions(
        jsonActions,
        begin,
        end,
        interval,
        timelineFilterId,
        outcomeFilterCode
      );

      var json = require('./mockdata/overall_dailyactions.json');
      const days = Math.floor(
        (end.getTime() - begin.getTime()) / 1000 / 60 / 60 / 24
      );
      const result = RewriteData.overallAverage(
        json,
        resultActiveAgents,
        resultActions,
        days,
        outcomeFilterCode
      );
      resolve(result);
    } else {
      const beginISO = begin.toISOString();
      const endISO = end.toISOString();
      const endpoint =
        'cco/feedback/average?begin=' +
        beginISO +
        '&end=' +
        endISO +
        '&outcome=' +
        outcomeId;
      getRequest(endpoint)
        .then((result) => {
          resolve(result);
        })
        .catch((error) => {
          switch (error.status) {
            case 403:
              reject(error.status);
              MwHistory.replace('/403');
              break;
            default:
              reject('error.customer-data-unavailable');
              break;
          }
        });
    }
  });
}

export function getOverallSuccessRate(
  begin,
  end,
  interval,
  timelineFilterId,
  multiCampaignTypesFilter
) {
  return new Promise(function (resolve, reject) {
    if (MOCKDATA) {
      var jsonAccepted = require('./mockdata/overall_actions_accepted_' +
        timelineFilterId +
        '.json');
      const resultAccepted = RewriteData.overallActions(
        jsonAccepted,
        begin,
        end,
        interval,
        timelineFilterId,
        'accepted'
      );
      var jsonNotProposed = require('./mockdata/overall_actions_not_proposed_' +
        timelineFilterId +
        '.json');
      const resultNotProposed = RewriteData.overallActions(
        jsonNotProposed,
        begin,
        end,
        interval,
        timelineFilterId,
        'not_proposed'
      );
      var jsonRejected = require('./mockdata/overall_actions_rejected_' +
        timelineFilterId +
        '.json');
      const resultRejected = RewriteData.overallActions(
        jsonRejected,
        begin,
        end,
        interval,
        timelineFilterId,
        'rejected'
      );

      var json = require('./mockdata/overall_successrate.json');
      const result = RewriteData.overallSuccessRate(
        json,
        resultAccepted,
        resultNotProposed,
        resultRejected
      );
      resolve(result);
    } else {
      const beginISO = begin.toISOString();
      const endISO = end.toISOString();
      const endpoint =
        'cco/feedback/number_of_actions?begin=' + beginISO + '&end=' + endISO;

      getRequest(endpoint)
        .then((result) => {
          resolve(result);
        })
        .catch((error) => {
          switch (error.status) {
            case 403:
              reject(error.status);
              MwHistory.replace('/403');
              break;
            default:
              reject('error.customer-data-unavailable');
              break;
          }
        });
    }
  });
}

export function getTimeEvolution() {
  return new Promise(function (resolve, reject) {
    var json = require('./mockdata/time_evolution.json');
    const result = FormatData.timeEvolutions(json);
    const mockResult = RewriteData.timeEvolutions(result);
    resolve(mockResult);
  });
}

export function getFeedbackReasons() {
  let endpoint = 'cco/feedbackreason'

  return new Promise(function (resolve, reject) {
    getRequest(endpoint)
      .then((result) => {
        const results = FormatData.FeedbackReasons(result.results);
        resolve(results);
      })
      .catch((error) => {
        switch (error.status) {
          case 403:
            reject(error.status);
            MwHistory.replace('/403');
            break;
          default:
            reject('error.customer-data-unavailable');
            break;
        }
      });
  });
}

export function getInteractionOutcome(
  begin,
  end,
  interval,
  channelId,
) {
  return new Promise(function (resolve, reject) {
    getRequest('cco/interactionoutcome').then((res) => {
      const result = FormatData.interactionOutcomes(res.results);
      getFeedbackReasons()
          .then((reasons) => {
            const mockResult = RewriteData.interactionOutcomes(result, reasons);
            resolve(mockResult);
          })
          .catch((error) => {
            resolve(result);
          });
    }).catch((err) => {
      reject(err);
    })
  });
}

export function getUserAnalysis(begin, end, channelId, timelineFilterId) {
  return new Promise(function (resolve, reject) {
    const beginISO = begin.toISOString();
    const endISO = end.toISOString();
    let endpoint = 'cco/persona/analysis?begin=' + beginISO + '&end=' + endISO;
    if (channelId) {
      endpoint += '&channel=' + channelId;
    }

    getRequest(endpoint)
      .then((result) => {
        const results = FormatData.userAnalysis(result.results);
        const total = result.total;
        if (MOCKDATA) {
          resolve(RewriteData.userAnalysis(results, timelineFilterId));
        } else {
          resolve({
            results: results,
            total: total
          });
        }
      })
      .catch((error) => {
        switch (error.status) {
          case 403:
            reject(error.status);
            MwHistory.replace('/403');
            break;
          default:
            reject('error.customer-data-unavailable');
            break;
        }
      });
  });
}
