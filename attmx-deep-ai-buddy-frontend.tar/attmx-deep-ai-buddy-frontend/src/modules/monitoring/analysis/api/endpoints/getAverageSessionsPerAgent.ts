import getDataInTimeline from "../getDataInTimeline";

export default function getAverageSessionsPerAgent(start: Date, end: Date): Promise<any> {
    const endpoint = 'cco/agentsessions';
    return getDataInTimeline(endpoint, start, end);
}