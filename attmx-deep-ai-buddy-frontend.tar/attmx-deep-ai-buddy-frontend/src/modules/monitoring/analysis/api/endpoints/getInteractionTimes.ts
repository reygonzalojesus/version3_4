import getDataInTimeline from "../getDataInTimeline";

export default function getInteractionTimes(start: Date, end: Date): Promise<any> {
    const endpoint = 'cco/sessiontimes';
    return getDataInTimeline(endpoint, start, end);
}