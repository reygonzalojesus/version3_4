import {getRequest} from "../../../../../deep/api/utils";
import KPIOutcomesByOffer from "../../../../../types/outcomesByOffer";

export default function getOutcomesByOffer(): Promise<KPIOutcomesByOffer> {
    const endpoint = `cco/outcomesbyoffer`
    return getRequest(endpoint)
}