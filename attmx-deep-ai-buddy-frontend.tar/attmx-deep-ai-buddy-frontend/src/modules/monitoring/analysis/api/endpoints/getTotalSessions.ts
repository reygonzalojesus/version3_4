import getDataInTimeline from "../getDataInTimeline";

export default function getTotalSessions(start: Date, end: Date): Promise<any> {
    const endpoint = 'cco/totalsessions';
    return getDataInTimeline(endpoint, start, end);
}