import getDataInTimeline from "../getDataInTimeline";

export default function getTotalSuccessfulSessions(start: Date, end: Date): Promise<any> {
    const endpoint = 'cco/successfulsessions';
    return getDataInTimeline(endpoint, start, end);
}