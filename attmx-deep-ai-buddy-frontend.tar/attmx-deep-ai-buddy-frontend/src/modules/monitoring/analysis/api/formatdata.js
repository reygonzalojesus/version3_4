function formatTrans(trans) {
  if (trans) {
    let labels = {};
    trans.forEach((lbl) => {
      labels[lbl.lang] = lbl.text;
    });
    return labels;
  } else {
    return null;
  }
}

function product(data) {
  if (!data) {
    return null;
  }
  let dataTranslated = {
    ...data,
    name: formatTrans(data.name?.items)
  };
  return dataTranslated;
}
function outcome(data) {
  if (!data) {
    return null;
  }
  let dataTranslated = {
    ...data,
    name: formatTrans(data.name?.items)
  };
  return dataTranslated;
}
function channel(data) {
  if (!data) {
    return null;
  }
  let dataTranslated = {
    ...data,
    name: formatTrans(data.name?.items)
  };
  return dataTranslated;
}
function campaignType(data) {
  if (!data) {
    return null;
  }
  let dataTranslated = {
    ...data,
    name: formatTrans(data.name?.items)
  };
  return dataTranslated;
}
function feedbackReason(data) {
  if (!data) {
    return null;
  }
  let dataTranslated = {
    ...data,
    description: formatTrans(data.description?.items)
  };
  return dataTranslated;
}

export function products(data) {
  let dataTranslated = [];
  data.forEach((item) => {
    dataTranslated.push(product(item));
  });
  return dataTranslated;
}
export function outcomes(data) {
  let dataTranslated = [];
  data.forEach((item) => {
    dataTranslated.push(outcome(item));
  });
  return dataTranslated;
}
export function channels(data) {
  let dataTranslated = [];
  data.forEach((item) => {
    dataTranslated.push(channel(item));
  });
  return dataTranslated;
}
export function campaignTypes(data) {
  let dataTranslated = [];
  data.forEach((item) => {
    dataTranslated.push(campaignType(item));
  });
  return dataTranslated;
}
export function FeedbackReasons(data) {
  let dataTranslated = [];
  data.forEach((item) => {
    dataTranslated.push(feedbackReason(item));
  });
  return dataTranslated;
}

export function timeEvolutions(data) {
  return data;
}
export function interactionOutcomes(data) {
  let dataTranslated = [];
  data.forEach((item) => {
    let reasons = [];
    if (item.reasons) {
      item.reasons.forEach((item) => {
        reasons.push({
          reason: feedbackReason(item.reason),
          ratio: item.ratio,
          count: item.count
        });
      });
    }

    dataTranslated.push({
      outcome: outcome(item.outcome),
      ratio: item.ratio,
      count: item.count,
      reasons: reasons
    });
  });
  return dataTranslated;
}
export function userAnalysis(data) {
  let dataTranslated = [];
  data.forEach((item) => {
    dataTranslated.push({
      ...item,
      channel: channel(item.channel)
    });
  });
  return dataTranslated;
}
