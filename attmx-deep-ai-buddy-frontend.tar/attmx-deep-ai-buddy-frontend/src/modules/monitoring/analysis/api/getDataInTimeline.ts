import { getRequest } from '../../../../deep/api/utils';

export default function getDataInTimeline(
  endpoint: string,
  start: Date,
  end?: Date,
  queryParameters?: { [name: string]: any }
): Promise<any> {
  if (!end) {
    end = new Date();
  }
  if (queryParameters === undefined) {
    queryParameters = {};
  }
  queryParameters['start'] = start.valueOf();
  queryParameters['end'] = end.valueOf();
  if (endpoint[endpoint.length - 1] !== '?') {
    endpoint += '?';
  }
  Object.keys(queryParameters).forEach((q: string) => {
    // @ts-ignore
    endpoint += `${q}=${queryParameters[q]}&`;
  });
  return getRequest(endpoint);
}
