import React, { Component } from 'react';
import clsx from 'clsx';
import { withTranslation } from 'react-i18next';
import { withStyles } from '@material-ui/core/styles';

const muiStyles = (theme) => ({
  label: {
    fontSize: '1.2rem',
    color: '#3A404D'
  },
  bar: {
    width: '100%',
    height: '0.6rem',
    backgroundColor: '#0BDCE9',
    borderRadius: '2px',
    margin: '0.5rem 0.2rem 0.5rem 0rem'
  },
  number: {
    fontWeight: 700,
    position: 'absolute',
    transform: 'translateX(calc(-50% + 0.2rem))'
  },
  ratio: {
    width: '100%',
    backgroundColor: '#0BDCE9',
    position: 'absolute',
    bottom: 0,
    borderRadius: '3px'
  },
  figures: {
    fontSize: '1.2rem'
  }
});

class StackedBar extends Component {
  render() {
    const { classes, data, showValue } = this.props;

    return (
      <div style={{ width: '100%' }}>
        {data &&
          data.map((item, index) => (
            <div key={index} style={{ width: item.ratio * 100 + '%' }}>
              <b style={{ fontSize: '1.2rem' }}>{item.label}</b>
              {showValue && item.value}&nbsp;&nbsp;
              <span style={{ fontWeight: 700 }}>
                ({(item.ratio * 100).toFixed()}%)
              </span>
              <div
                className={classes.bar}
                style={{
                  backgroundColor: item.color || '#F3F3F3',
                  display: 'inline-block'
                }}
              />
              <div
                className={clsx(classes.figures, {
                  [classes.labelRight]: index > 0
                })}
              ></div>
            </div>
          ))}
      </div>
    );
  }
}

export default withTranslation('monitoring')(withStyles(muiStyles)(StackedBar));
