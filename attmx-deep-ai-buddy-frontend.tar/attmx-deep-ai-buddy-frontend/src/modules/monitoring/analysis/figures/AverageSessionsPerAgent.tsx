import React from 'react';
import FiltersContext from '../contexts/FiltersProvider';
import Card from '../components/Card';
import { faUser } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import styles from './Overall.module.css';
import Moment from 'react-moment';
import getAverageSessionsPerAgent from '../api/endpoints/getAverageSessionsPerAgent';
import Grid from '@material-ui/core/Grid';
import Histogram from '../charts/Histogram';

let timer: any = null;

class AverageSessionsPerAgent extends React.Component<any, any> {
  static contextType = FiltersContext;
  private mounted: boolean;

  constructor(props: any) {
    super(props);
    this.mounted = false;
    this.state = {
      fadeIn: false,
      timelineFilter: null,
      channelFilter: null,
      stats: []
    };
  }

  componentWillUnmount() {
    this.mounted = false;
    clearTimeout(timer);
  }

  async loadStats() {
    let begin;
    let end;
    if (this.context.timelineFilter) {
      if (this.context.timelineFilter.begin) {
        begin = this.context.timelineFilter.begin;
      }
      if (this.context.timelineFilter.end) {
        end = this.context.timelineFilter.end;
      }
    }
    if (!begin) {
      // @ts-ignore
      begin = new Date() - 7;
    }
    if (!end) {
      end = new Date();
    }
    getAverageSessionsPerAgent(begin, end).then((r) => {
      let chartData: any[] = [];
      r.windows.forEach((s: any) => {
        const parsedStart = Date.parse(s.start);
        chartData.push({
          label: (
            <>
              <Moment date={parsedStart} format={'LL'} />
            </>
          ),
          value: s.sessions,
          ratio: s.sessions / r.max
        });
      });
      this.setState({
        stats: {
          chartData: chartData,
          count: r.total
        }
      });
    });
  }

  securSetState(data: any) {
    if (this.mounted) {
      this.setState(() => data);
    }
  }

  componentDidMount() {
    this.loadStats();
    this.mounted = true;
  }

  render() {
    let { stats } = this.state;
    return (
      <Card
        title={'Sesiones promedio por agente'}
        subtitle={'Promedio de sesiones por agente'}
        icon={<FontAwesomeIcon icon={faUser} />}
      >
        <Grid
          container
          spacing={1}
          alignItems='flex-end'
          justify='flex-start'
          style={{ maxWidth: 500 }}
        >
          <Grid item>
            <div
              className={styles.figureWrapper}
              style={{ marginBottom: '2.1rem' }}
            >
              <div className={styles.figureLabel}>Sesiones</div>
              <div className={styles.figureValue} style={{ color: '#19ABB4' }}>
                {stats?.count || '-'}
              </div>
            </div>
            <div className={styles.figureWrapper}>
              <div className={styles.figureLabel}>Tendencias</div>
              <div className={styles.figureValue} style={{ color: '#17B554' }}>
                {stats?.trends || '-'}
              </div>
            </div>
          </Grid>
          <Grid item>
            {stats?.chartData && (
              <Histogram
                data={stats.chartData}
                colWidth={10}
                barWidth={0.4}
                barHeight={10}
              />
            )}
          </Grid>
        </Grid>
      </Card>
    );
  }
}

export default AverageSessionsPerAgent;
