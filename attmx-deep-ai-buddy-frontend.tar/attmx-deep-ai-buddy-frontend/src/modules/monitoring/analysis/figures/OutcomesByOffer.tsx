import React from 'react';
import FiltersContext from '../contexts/FiltersProvider';
import Card from '../components/Card';
import { faTools } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import Loader from '../components/Loader';
import getOutcomesByOffer from '../api/endpoints/getOutcomesByOffer';
import StackedBarLarge from '../charts/StackedBarLarge';
import Grid from '@material-ui/core/Grid';
import ProgressBar from '../charts/ProgressBar';
import extractOfferCategories, {
  OfferPrimitives
} from '../../utils/extractOfferCategories';
import {
  Checkbox,
  FormControl,
  FormControlLabel,
  FormGroup,
  FormHelperText,
  FormLabel
} from '@material-ui/core';

let timer: any = null;

class OutcomesByOffer extends React.Component<any, any> {
  static contextType = FiltersContext;
  private mounted: boolean;
  private outcomePrimitives?: OfferPrimitives = undefined;

  constructor(props: any) {
    super(props);
    this.mounted = false;
    this.state = {
      fadeIn: false,
      timelineFilter: null,
      channelFilter: null,
      outcomes: null,
      stats: [],
      categories: null
    };
  }

  componentWillUnmount() {
    this.mounted = false;
    clearTimeout(timer);
  }

  formatStats(data: any) {
    if (!data) {
      return null;
    }

    let ratios: any[] = [];
    data.forEach((item: any) => {
      ratios.push(item.ratio);
    });
    let colors = ['#0CE67F', '#FEC869', '#FF5757'];

    let dataFormatted = [];
    for (let i = 0; i < data.length; i++) {
      let reasons = [];
      for (let j = 0; j < data[i].reasons.length; j++) {
        let color;
        switch (data[i].reasons[j].name) {
          case 'Aceptado':
            color = '#0CE67F';
            break;
          case 'Rechazado':
            color = '#FF5757';
            break;
          default:
            color = '#FEC869';
            break;
        }
        reasons.push({
          label: data[i].reasons[j].name,
          value: data[i].reasons[j].count,
          ratio: data[i].reasons[j].ratio,
          color: color
        });
      }

      dataFormatted.push({
        label: data[i].offer,
        index: i,
        ratios: ratios,
        color: colors[i],
        reasons: reasons
      });
    }

    return dataFormatted;
  }

  async loadStats() {
    let begin;
    let end;
    if (this.context.timelineFilter) {
      if (this.context.timelineFilter.begin) {
        begin = this.context.timelineFilter.begin;
      }
      if (this.context.timelineFilter.end) {
        end = this.context.timelineFilter.end;
      }
    }
    if (!begin) {
      // @ts-ignore
      begin = new Date() - 7;
    }
    if (!end) {
      end = new Date();
    }

    getOutcomesByOffer().then((r) => {
      this.outcomePrimitives = extractOfferCategories(r);
      let primitiveState: any = {};
      Object.keys(this.outcomePrimitives).forEach((p) => {
        primitiveState[p] = {
          // @ts-ignore
          count: this.outcomePrimitives[p].length,
          shown: true
        };
      });
      this.securSetState({ categories: primitiveState });
      let items: any[] = [];
      const getSumForOffer = (offerName: string) =>
        Object.values(r.counts[offerName]).reduce((a, b) => a + b, 0);
      Object.keys(r.counts)
        .sort((a, b) => {
          let aSum = getSumForOffer(a);
          let bSum = getSumForOffer(b);
          return aSum === bSum ? 0 : aSum > bSum ? -1 : 1;
        })
        .forEach((offerName) => {
          const offerSum = getSumForOffer(offerName);
          // @ts-ignore
          let itemReasons: any[] = [];
          Object.keys(r.counts[offerName]).forEach((outcomeName: string) => {
            itemReasons.push({
              name: outcomeName,
              count: r.counts[offerName][outcomeName],
              // @ts-ignore
              ratio: r.counts[offerName][outcomeName] / offerSum
            });
          });
          items.push({
            offer: offerName,
            // @ts-ignore
            ratio: offerSum / r.total,
            reasons: itemReasons
          });
        });
      const formattedStats = this.formatStats(items);
      this.setState({
        stats: formattedStats
      });
    });
  }

  securSetState(data: any) {
    if (this.mounted) {
      this.setState(() => data);
    }
  }

  componentDidMount() {
    this.loadStats();
    this.mounted = true;
  }

  renderCategoryFilter() {
    let checkboxes: any[] = [];
    Object.keys(this.state.categories).forEach((o, i) => {
      let primitiveObj = this.state.categories[o];
      checkboxes.push(
        <FormControlLabel
          control={
            <Checkbox
              checked={primitiveObj.shown}
              onChange={() =>
                this.setState((state: any) => {
                  let cat = state.categories;
                  cat[o].shown = !cat[o].shown;
                  return { categories: cat };
                })
              }
            />
          }
          label={`${o} (${primitiveObj.count})`}
          key={i}
        />
      );
    });
    return (
      <div style={{ display: 'flex' }}>
        <FormControl component='fieldset'>
          <FormLabel component='legend'>Filtrar Ofertas</FormLabel>
          <FormGroup style={{ flexDirection: 'row' }}>{checkboxes}</FormGroup>
          <FormHelperText>
            Elige qué tipos de ofertas quieres mostrar
          </FormHelperText>
        </FormControl>
      </div>
    );
  }

  render() {
    let shownStats: any[] = [];
    const readyToRender =
      this.state.stats && this.state.stats.length > 0 && this.state.categories;
    if (readyToRender) {
      this.state.stats.forEach((i: any) => {
        const iPrimitives = i.label.split(' + ');
        let primitiveFound = false;
        for (let primitive of iPrimitives) {
          if (this.state.categories[primitive].shown) {
            primitiveFound = true;
            break;
          }
        }
        if (primitiveFound) {
          shownStats.push(i);
        }
      });
    }
    return (
      <Card
        title='Estadísticas por herramienta de retención'
        subtitle='Tasas de uso de herramientas y tasa de resultados por herramienta de retención'
        icon={<FontAwesomeIcon icon={faTools} />}
      >
        <div style={{ margin: '0rem 2rem' }}>
          {this.state.categories && this.renderCategoryFilter()}
          <br />
          {readyToRender && (
            <Grid container spacing={6}>
              {shownStats.map((outcome: any, index: any) => (
                <Grid item key={index} xs={12} md={4}>
                  <div style={{ marginBottom: '4rem' }}>
                    <StackedBarLarge
                      data={outcome}
                      suffix={' de ofertas propuestas'}
                    />
                  </div>
                  {outcome.reasons.map((reason: any, index: any) => (
                    <div key={index} style={{ marginBottom: '2.4rem' }}>
                      <ProgressBar data={reason} />
                    </div>
                  ))}
                </Grid>
              ))}
            </Grid>
          )}
        </div>
        {!this.state.stats ||
          (this.state.stats.length === 0 && <Loader positionY='4rem' />)}
      </Card>
    );
  }
}

export default OutcomesByOffer;
