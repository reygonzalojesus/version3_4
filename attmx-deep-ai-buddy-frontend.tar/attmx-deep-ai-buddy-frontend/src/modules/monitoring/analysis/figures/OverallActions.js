import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import styles from './Overall.module.css';
import * as Api from './../api/endpoints';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheckCircle } from '@fortawesome/free-solid-svg-icons';
import Card from './../components/Card';
import Histogram from './../charts/Histogram';
import Fade from '@material-ui/core/Fade';
import Loader from './../components/Loader';
import Grid from '@material-ui/core/Grid';
import FiltersContext from './../contexts/FiltersProvider';
import Moment from 'react-moment';
import { FILTERS_TIMELINE } from './../contexts/FiltersProvider';

let timer = null;
let delay = 600;

class OverallActions extends Component {
  static contextType = FiltersContext;

  constructor(props) {
    super(props);
    this.state = {
      fadeIn: false,
      timelineFilter: null,
      channelFilter: null,
      outcomeFilter: null,
      multiCampaignTypesFilter: null,
      stats: null
    };
  }

  componentDidMount() {
    this.mounted = true;
    this.updateState();
  }
  componentDidUpdate() {
    this.updateState();
  }
  componentWillUnmount() {
    this.mounted = false;
    clearTimeout(timer);
  }
  securSetState(data) {
    if (this.mounted) {
      this.setState(() => data);
    }
  }

  updateState() {
    if (
      this.context.timelineFilter &&
      this.context.channelFilter &&
      this.context.outcomeFilter &&
      this.context.multiCampaignTypesFilter &&
      (this.context.timelineFilter.id !== this.state.timelineFilter?.id ||
        this.context.channelFilter.id !== this.state.channelFilter?.id ||
        this.context.outcomeFilter.id !== this.state.outcomeFilter?.id ||
        this.context.multiCampaignTypesFilter !==
          this.state.multiCampaignTypesFilter)
    ) {
      this.securSetState({
        fadeIn: false,
        timelineFilter: this.context.timelineFilter,
        channelFilter: this.context.channelFilter,
        outcomeFilter: this.context.outcomeFilter,
        multiCampaignTypesFilter: this.context.multiCampaignTypesFilter
      });
      this.loadStats();
    }
  }

  async loadStats() {
    timer = setTimeout(() => this.securSetState({ fadeIn: true }), delay);
    const result = await Api.getOverallActions(
      this.context.timelineFilter.begin,
      this.context.timelineFilter.end,
      this.context.timelineFilter.interval,
      this.context.outcomeFilter.id,
      this.context.timelineFilter.id,
      this.context.outcomeFilter.code,
      this.context.multiCampaignTypesFilter
    );
    this.formatStats(result);
  }

  formatStats(stats) {
    //get higher count for histogram
    let maxCount = 1;
    stats.results.forEach((data) => {
      if (data.count > maxCount) {
        maxCount = data.count;
      }
    });

    let prefix = '';
    let labelFormat = '';
    switch (this.context.timelineFilter.id) {
      case FILTERS_TIMELINE.WEEK.id:
      case FILTERS_TIMELINE.WEEKTODATE.id:
        labelFormat = 'ddd';
        break;
      case FILTERS_TIMELINE.MONTH.id:
      case FILTERS_TIMELINE.MONTHTODATE.id:
        labelFormat = 'w';
        prefix = 'Week';
        break;
      case FILTERS_TIMELINE.YEARTODATE.id:
        labelFormat = 'MMM';
        break;
      default:
    }

    //format chart data for histogram
    let chartData = [];
    stats.results.forEach((data) => {
      const date = new Date(data.begin);
      chartData.push({
        label: (
          <>
            {prefix} <Moment date={date} format={labelFormat} />
          </>
        ),
        value: data.count,
        ratio: data.count / maxCount
      });
    });

    //format final data
    let statsFormatted = {
      count: stats.count.toString(),
      trends:
        stats.trends > 0
          ? '+' + Math.round(stats.trends * 100) + '%'
          : Math.round(stats.trends * 100) + '%',
      previous: stats.previous.toString(),
      chartData: chartData
    };

    this.securSetState({
      stats: statsFormatted
    });
  }

  render() {
    let colWidth = 0;
    const { timelineFilter, stats } = this.state;

    switch (timelineFilter?.id) {
      case FILTERS_TIMELINE.WEEK.id:
      case FILTERS_TIMELINE.WEEKTODATE.id:
        colWidth = 4;
        break;
      case FILTERS_TIMELINE.MONTH.id:
      case FILTERS_TIMELINE.MONTHTODATE.id:
        colWidth = 5.8;
        break;
      case FILTERS_TIMELINE.YEARTODATE.id:
        colWidth = 3.2;
        break;
      default:
    }

    return (
      <Card
        title={'Number of actions'}
        subtitle={'Total of actions recorded in tool during time period '}
        icon=<FontAwesomeIcon icon={faCheckCircle} />
      >
        <Fade in={this.state.fadeIn} timeout={{ enter: 500 }}>
          <Grid
            container
            spacing={1}
            alignItems='flex-end'
            justify='flex-start'
            style={{ maxWidth: 500 }}
          >
            <Grid item>
              <div className={styles.figuresTitle}>{timelineFilter?.label}</div>
              <div
                className={styles.figureWrapper}
                style={{ marginBottom: '2.1rem' }}
              >
                <div className={styles.figureLabel}>Actions</div>
                <div
                  className={styles.figureValue}
                  style={{ color: '#19ABB4' }}
                >
                  {stats?.count || '-'}
                </div>
              </div>
              <div className={styles.figureWrapper}>
                <div className={styles.figureLabel}>Trends</div>
                <div
                  className={styles.figureValue}
                  style={{ color: '#17B554' }}
                >
                  {stats?.trends || '-'}
                </div>
              </div>
              <div className={styles.figuresTitle}>Previous</div>
              <div className={styles.figureWrapper}>
                <div className={styles.figureLabel}>Actions</div>
                <div className={styles.figureValue}>
                  {stats?.previous || '-'}
                </div>
              </div>
            </Grid>
            <Grid item>
              {stats?.chartData && (
                <Histogram
                  data={stats.chartData}
                  colWidth={colWidth}
                  barWidth={0.4}
                  barHeight={10}
                />
              )}
            </Grid>
          </Grid>
        </Fade>

        {!this.state.fadeIn && <Loader positionY='3rem' />}
      </Card>
    );
  }
}

export default withTranslation('monitoring')(OverallActions);
