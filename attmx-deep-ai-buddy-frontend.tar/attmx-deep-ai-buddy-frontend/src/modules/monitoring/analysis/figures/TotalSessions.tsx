import React from 'react';
import FiltersContext from '../contexts/FiltersProvider';
import Card from '../components/Card';
import { faCalculator } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import styles from './Overall.module.css';
import Loader from '../components/Loader';
import Moment from 'react-moment';
import getTotalSessions from '../api/endpoints/getTotalSessions';

let timer: any = null;

class TotalSessions extends React.Component<any, any> {
  static contextType = FiltersContext;
  private mounted: boolean;

  constructor(props: any) {
    super(props);
    this.mounted = false;
    this.state = {
      fadeIn: false,
      timelineFilter: null,
      channelFilter: null,
      stats: []
    };
  }

  componentWillUnmount() {
    this.mounted = false;
    clearTimeout(timer);
  }

  async loadStats() {
    let statsFormatted: any[] = [];

    let begin;
    let end;
    if (this.context.timelineFilter) {
      if (this.context.timelineFilter.begin) {
        begin = this.context.timelineFilter.begin;
      }
      if (this.context.timelineFilter.end) {
        end = this.context.timelineFilter.end;
      }
    }
    if (!begin) {
      // @ts-ignore
      begin = new Date() - 7;
    }
    if (!end) {
      end = new Date();
    }
    getTotalSessions(begin, end).then((r) => {
      r.forEach((s: any) => {
        const parsedStart = Date.parse(s.start);
        const parsedEnd = Date.parse(s.end);
        statsFormatted.push({
          label: (
            <>
              <Moment format={'LL'}>{parsedStart}</Moment>-
              <Moment format={'LL'}>{parsedEnd}</Moment>
            </>
          ),
          value: s.sessions
        });
      });
      this.setState({
        stats: statsFormatted
      });
    });
  }

  securSetState(data: any) {
    if (this.mounted) {
      this.setState(() => data);
    }
  }

  componentDidMount() {
    this.loadStats();
    this.mounted = true;
  }

  render() {
    return (
      <Card
        title='Sesiones totales'
        subtitle='Sesiones totales, semana a semana'
        icon={<FontAwesomeIcon icon={faCalculator} />}
      >
        <div>
          <div className={styles.divider}></div>
          <div style={{ width: '95%' }}>
            {this.state.stats.map((s: any, i: number) => {
              return (
                <div key={i}>
                  <div className={styles.figureWrapper}>
                    Semana de {s.label} - <b>{s.value}</b>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        {!this.state.stats ||
          (this.state.stats.length === 0 && <Loader positionY='4rem' />)}
      </Card>
    );
  }
}

export default TotalSessions;
