import React from 'react';
import FiltersContext from '../contexts/FiltersProvider';
import Card from '../components/Card';
import { faTools,faPrint, faExchangeAlt } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import Loader from '../components/Loader';
import getOutcomesByOffer from '../api/endpoints/getOutcomesByOffer';
import StackedBarLarge from '../charts/StackedBarLarge';
import Grid from '@material-ui/core/Grid';
import ProgressBar from '../charts/ProgressBar';
import extractOfferCategories, {
  OfferPrimitives
} from '../../utils/extractOfferCategories';
import {
  Checkbox,
  FormControl,
  FormControlLabel,
  FormGroup,
  FormHelperText,
  FormLabel
} from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
import styled from 'styled-components';
import * as CcoApi from '../api/endpoints';

let timer: any = null;

class report extends React.Component<any, any> {
  static contextType = FiltersContext;
  private mounted: boolean;
  private outcomePrimitives?: OfferPrimitives = undefined;

  constructor(props: any) {
    super(props);
    this.mounted = false;
    this.state = {
      fadeIn: false,
      timelineFilter: null,
      channelFilter: null,
      outcomes: null,
      stats: [],
      categories: null,
      dateInit: new Date().getFullYear() + "-" + (new Date().getMonth() + 1) + "-" + "01",
      dateEnd: new Date().toISOString().split('T')[0],
      titleButton: 'Descargar'
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }
  handleSubmit(event: any) {
    event.preventDefault();
  }
  handleChange(event: any) {
    this.setState({value: event.target.value,
      dateInit: event.target.id == 'date1'? event.target.value: this.state.dateInit,
      dateEnd: event.target.id == 'date2'? event.target.value: this.state.dateEnd});
  }
  componentWillUnmount() {
    this.mounted = false;
    clearTimeout(timer);
  }

  formatStats(data: any) {
    if (!data) {
      return null;
    }

    let ratios: any[] = [];
    data.forEach((item: any) => {
      ratios.push(item.ratio);
    });
    let colors = ['#0CE67F', '#FEC869', '#FF5757'];

    let dataFormatted = [];
    for (let i = 0; i < data.length; i++) {
      let reasons = [];
      for (let j = 0; j < data[i].reasons.length; j++) {
        let color;
        switch (data[i].reasons[j].name) {
          case 'Aceptado':
            color = '#0CE67F';
            break;
          case 'Rechazado':
            color = '#FF5757';
            break;
          default:
            color = '#FEC869';
            break;
        }
        reasons.push({
          label: data[i].reasons[j].name,
          value: data[i].reasons[j].count,
          ratio: data[i].reasons[j].ratio,
          color: color
        });
      }

      dataFormatted.push({
        label: data[i].offer,
        index: i,
        ratios: ratios,
        color: colors[i],
        reasons: reasons
      });
    }

    return dataFormatted;
  }

  async loadStats() {
  }

  securSetState(data: any) {
    if (this.mounted) {
      this.setState(() => data);
    }
  }

  componentDidMount() {
    this.loadStats();
    this.mounted = true;
  }

  renderCategoryFilter() {
  }
  loadIp(){

    console.log("ip");
  }
  render() {
    this.loadIp();
    let shownStats: any[] = [];
    const readyToRender =
      this.state.stats && this.state.stats.length > 0 && this.state.categories;
    if (readyToRender) {
      this.state.stats.forEach((i: any) => {
        const iPrimitives = i.label.split(' + ');
        let primitiveFound = false;
        for (let primitive of iPrimitives) {
          if (this.state.categories[primitive].shown) {
            primitiveFound = true;
            break;
          }
        }
        if (primitiveFound) {
          shownStats.push(i);
        }
      });
    }
    return (
      
      <form onSubmit={this.handleSubmit}>
      <Card
        title='Reporte de promociones'
        subtitle=''
        icon={<FontAwesomeIcon icon={faPrint} />}
      >
        <div style={{
        margin: 'auto',
        display: 'block',
        width: 'fit-content'
      }}>
        <TextField
          id="date1"
          label="Fecha inicial"
          type="date"
          defaultValue={this.state.dateInit}
          InputLabelProps={{
            shrink: true,
          }}
          value={this.state.dateInit}
          onChange={this.handleChange}/>
         
          <TextField
          id="date2"
          label="Fecha final"
          type="date"
          defaultValue={this.state.dateEnd}
          InputLabelProps={{
            shrink: true,
          }}
          value={this.state.dateEnd}
          onChange={this.handleChange}/>
      </div>
      <Contenido><br></br><Boton  onClick={() =>   window.open("http://localhost:8000/deep/api/v1/cco/excel?" +'date1='+this.state.dateInit+'&date2='+this.state.dateEnd+'', "_blank")  }>{this.state.titleButton}</Boton>
      <br></br>
      </Contenido>
      
      </Card>
      </form>
    );
  }
}



const Contenido = styled.div`
	display: flex;
	flex-direction: column;
	align-items: center;
	h1 {
		font-size: 42px;
		font-weight: 700;
		margin-bottom: 0px;
	}
	p {
		font-size: 18px;
		margin-bottom: 20px;
		
	}
	img {
		width: 100%;
		vertical-align: top;
		border-radius: 3px;
	}
	z-index: 1000;
`;
const Boton = styled.button`
	display: block;
	padding: 10px 30px;
	border-radius: 100px;
	color: #fff;
	border: none;
	background: #00A8E0;
	cursor: pointer;
	font-family: 'Roboto', sans-serif;
	font-weight: 500;
	transition: .3s ease all;
	&:hover {
		background: #00A8E0;
	}
	z-index: 1000;
`;



export default report;

