import React, { Component } from 'react';
import styles from './Monitoring.module.css';
import Grid from '@material-ui/core/Grid';
import AverageInteractionTime from "../figures/AverageInteractionTime";
import AverageSessionsPerAgent from "../figures/AverageSessionsPerAgent";
import TotalSessions from "../figures/TotalSessions";
import SuccessfulSessions from "../figures/SuccessfulSessions";

class OverallPerformance extends Component {
  render() {
    return (
      <>
        <div className={styles.Wrapper}>
          <Grid
            container
            spacing={3}
            alignItems='stretch'
            style={{ maxWidth: 1400 }}
          >
            <Grid item xs={4} md={4}>
              <AverageInteractionTime />
            </Grid>
            <Grid item xs={8} md={8}>
              <AverageSessionsPerAgent />
            </Grid>
            <Grid item xs={4} md={4}>
              <TotalSessions />
            </Grid>
            <Grid item xs={6} md={6}>
              <SuccessfulSessions />
            </Grid>
          </Grid>
        </div>
      </>
    );
  }
}

export default OverallPerformance;
