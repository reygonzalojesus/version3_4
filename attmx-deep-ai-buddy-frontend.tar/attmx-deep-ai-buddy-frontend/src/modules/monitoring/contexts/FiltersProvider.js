import React, { Component } from 'react';
import * as Api from './../api/endpoints';

export const FILTERS_TIMELINE = {
  WEEK: { id: 'week', label: 'Last 7 Days', interval: 86400 },
  MONTH: { id: 'month', label: 'Last 30 Days', interval: 604800 },
  WEEKTODATE: { id: 'weektodate', label: 'Week to Date', interval: 86400 },
  MONTHTODATE: { id: 'monthtodate', label: 'Month to Date', interval: 604800 },
  YEARTODATE: { id: 'yeartodate', label: 'Year to Date', interval: 2728000 }
};
export const FILTERS_KPIS = [
  { id: 'logins', label: '# Logins' },
  { id: 'success', label: 'Successful actions' },
  { id: 'rate', label: 'Conversion Rate' },
  { id: 'actions', label: 'Actions on tool' },
  { id: 'comparison', label: 'Comparison with average' },
  { id: 'average', label: 'Average Handling time' }
];
export const FILTERS_STATUS = {
  ALL: { id: 'all', label: 'All Status' },
  UPCOMING: { id: 'upcoming', label: 'Upcoming' },
  ONGOING: { id: 'ongoing', label: 'Ongoing' },
  ARCHIVES: { id: 'archives', label: 'Archives' }
};

const FiltersContext = React.createContext();

class FiltersProvider extends Component {
  constructor(props) {
    super(props);
    this.state = {
      outcomeFilter: null,
      outcomes: null,
      channelFilter: null,
      channels: null,
      multiProductsFilter: null,
      singleProductFilter: null,
      products: null,
      multiCampaignTypesFilter: null,
      singleCampaignTypeFilter: null,
      campaignTypes: null,
      timelineFilter: null,
      kpisFilter: null,
      statusFilter: null
    };
  }

  componentDidMount() {
    this.mounted = true;
    this.loadOutcomes();
    this.loadChannels();
    this.loadProducts();
    this.loadCampaignTypes();
    this.setTimelineFilter(FILTERS_TIMELINE.WEEK);
    this.setKpisFilter([
      FILTERS_KPIS[0].id,
      FILTERS_KPIS[1].id,
      FILTERS_KPIS[2].id,
      FILTERS_KPIS[3].id
    ]);
    this.setStatusFilter(FILTERS_STATUS.ALL);
  }
  componentWillUnmount() {
    this.mounted = false;
  }
  securSetState(data) {
    if (this.mounted) {
      this.setState(() => data);
    }
  }

  async loadOutcomes() {
    const result = await Api.getOutcomes();
    this.formatOutcomes(result);
  }

  formatOutcomes(outcomes) {
    let formattedOutcomes = [];
    outcomes.forEach((outcome) => {
      formattedOutcomes.push({
        id: outcome.id,
        label: outcome.name['en'],
        code: outcome.code
      });
    });
    this.securSetState({
      outcomes: formattedOutcomes
    });
    this.setOutcomeFilter(formattedOutcomes[0]);
  }

  async loadChannels() {
    const result = await Api.getChannels();
    this.formatChannels(result);
  }

  formatChannels(channels) {
    let formattedChannels = [];
    channels.forEach((channel) => {
      formattedChannels.push({
        id: channel.id,
        label: channel.name['en']
      });
    });
    this.securSetState({
      channels: formattedChannels
    });
    this.setChannelFilter(formattedChannels[0]);
  }

  async loadProducts() {
    const result = await Api.getProducts();
    this.formatProducts(result);
  }

  formatProducts(products) {
    let formattedProducts = [];
    let multiProductsFilter = [];
    products.forEach((product) => {
      formattedProducts.push({
        id: product.id,
        label: product.name['en']
      });
      if (multiProductsFilter.length < 4) {
        multiProductsFilter.push(product.id);
      }
    });
    this.securSetState({
      products: formattedProducts
    });
    this.setMultiProductsFilter(multiProductsFilter);
    this.setSingleProductFilter(formattedProducts[0]);
  }

  async loadCampaignTypes() {
    const result = await Api.getCampaignTypes();
    this.formatCampaignTypes(result);
  }

  formatCampaignTypes(campaignTypes) {
    let formattedCampaignTypes = [];
    let multiCampaignTypesFilter = [];
    campaignTypes.forEach((campaignType) => {
      formattedCampaignTypes.push({
        id: campaignType.id,
        label: campaignType.name['en']
      });
      multiCampaignTypesFilter.push(campaignType.id);
    });
    this.securSetState({
      campaignTypes: formattedCampaignTypes
    });
    this.setMultiCampaignTypesFilter(multiCampaignTypesFilter);
    this.setSingleCampaignTypeFilter(formattedCampaignTypes[0]);
  }

  setOutcomeFilter = (filter) => {
    this.securSetState({ outcomeFilter: filter });
  };
  setChannelFilter = (filter) => {
    this.securSetState({ channelFilter: filter });
  };
  setMultiProductsFilter = (products) => {
    this.securSetState({ multiProductsFilter: products });
  };
  setSingleProductFilter = (filter) => {
    this.securSetState({ singleProductFilter: filter });
  };
  setMultiCampaignTypesFilter = (campaignTypes) => {
    this.securSetState({ multiCampaignTypesFilter: campaignTypes });
  };
  setSingleCampaignTypeFilter = (filter) => {
    this.securSetState({ singleCampaignTypeFilter: filter });
  };
  setTimelineFilter = (filterBase) => {
    let filter = {
      id: filterBase.id,
      label: filterBase.label,
      interval: filterBase.interval,
      begin: null,
      end: new Date()
    };
    const now = new Date();
    switch (filterBase.id) {
      case FILTERS_TIMELINE.WEEK.id:
        filter.begin = new Date(now.setDate(now.getDate() - 6));
        break;
      case FILTERS_TIMELINE.MONTH.id:
        filter.begin = new Date(now.setMonth(now.getMonth() - 1));
        break;
      case FILTERS_TIMELINE.WEEKTODATE.id:
        filter.begin = new Date(now.setDate(now.getDate() - now.getDay()));
        break;
      case FILTERS_TIMELINE.MONTHTODATE.id:
        filter.begin = new Date(now.getFullYear(), now.getMonth());
        break;
      case FILTERS_TIMELINE.YEARTODATE.id:
        filter.begin = new Date(now.getFullYear(), 0);
        break;
      default:
        filter.begin = new Date(now.setDate(now.getDate() - 7));
        break;
    }
    this.securSetState({ timelineFilter: filter });
  };
  setKpisFilter = (kpis) => {
    this.securSetState({ kpisFilter: kpis });
  };
  setStatusFilter = (status) => {
    this.securSetState({ statusFilter: status });
  };
  render() {
    const { children } = this.props;
    const {
      outcomeFilter,
      outcomes,
      channelFilter,
      channels,
      multiProductsFilter,
      singleProductFilter,
      products,
      multiCampaignTypesFilter,
      singleCampaignTypeFilter,
      campaignTypes,
      timelineFilter,
      kpisFilter,
      statusFilter
    } = this.state;

    const {
      setOutcomeFilter,
      setChannelFilter,
      setMultiProductsFilter,
      setSingleProductFilter,
      setMultiCampaignTypesFilter,
      setSingleCampaignTypeFilter,
      setTimelineFilter,
      setKpisFilter,
      setStatusFilter
    } = this;

    return (
      <FiltersContext.Provider
        value={{
          outcomes,
          outcomeFilter,
          setOutcomeFilter,
          channels,
          channelFilter,
          setChannelFilter,
          products,
          multiProductsFilter,
          setMultiProductsFilter,
          singleProductFilter,
          setSingleProductFilter,
          campaignTypes,
          multiCampaignTypesFilter,
          setMultiCampaignTypesFilter,
          singleCampaignTypeFilter,
          setSingleCampaignTypeFilter,
          timelineFilter,
          setTimelineFilter,
          kpisFilter,
          setKpisFilter,
          statusFilter,
          setStatusFilter
        }}
      >
        {children}
      </FiltersContext.Provider>
    );
  }
}

export default FiltersContext;

export { FiltersProvider };
