import React, { Component } from 'react';
import { withTranslation } from 'react-i18next';
import { withStyles } from '@material-ui/core/styles';
import styles from './Monitoring.module.css';
import Card from './../components/Card';
import Histogram from './../charts/Histogram';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import TableHead from '@material-ui/core/TableHead';
import Fade from '@material-ui/core/Fade';
import Loader from './../components/Loader';
import FiltersContext from './../contexts/FiltersProvider';

let delay = 800;

const muiStyles = (theme) => ({
  TableHeadCellHisto: {
    borderBottom: 'none'
  },
  TableHeadCell: {
    color: '#4C4C4C',
    borderBottom: 'none',
    fontWeight: 600,
    lineHeight: '1.4',
    padding: '0.4rem 1.2rem',
    verticalAlign: 'bottom',
    width: '17%',
    backgroundColor: '#F6F6F6',
    '&:nth-child(1)': {
      backgroundColor: 'transparent'
    }
  },
  TableCell: {
    color: '#777777',
    borderBottom: '1px solid #E6E9EE',
    padding: '1rem 1.2rem 0.4rem',
    verticalAlign: 'top',
    whiteSpace: 'nowrap',
    '&:nth-child(n+2)': {
      fontWeight: 700
    },
    '&:nth-child(1)': {
      borderBottom: 'none'
    }
  }
});

class FeedbackAnalysis extends Component {
  static contextType = FiltersContext;

  constructor(props) {
    super(props);
    this.state = {
      fadeIn: false,
      timer: null,
      multiProductsFilter: null,
      timelineFilter: null,
      singleCampaignTypeFilter: null,
      channelFilter: null
    };
  }

  componentDidUpdate() {
    if (
      (this.context.timelineFilter &&
        this.context.timelineFilter.id !== this.state.timelineFilter?.id) ||
      (this.context.channelFilter &&
        this.context.channelFilter.id !== this.state.channelFilter?.id) ||
      (this.context.singleCampaignTypeFilter &&
        this.context.singleCampaignTypeFilter !==
          this.state.singleCampaignTypeFilter) ||
      (this.context.multiProductsFilter &&
        this.context.multiProductsFilter !== this.state.multiProductsFilter)
    ) {
      this.securSetState({
        fadeIn: false,
        timelineFilter: this.context.timelineFilter,
        channelFilter: this.context.channelFilter,
        singleCampaignTypeFilter: this.context.singleCampaignTypeFilter,
        multiProductsFilter: this.context.multiProductsFilter
      });
      this.securSetState({
        timer: setTimeout(() => this.securSetState({ fadeIn: true }), delay)
      });
    }
  }

  componentDidMount() {
    this.mounted = true;
    window.scrollTo(0, 0);
    this.securSetState({
      timelineFilter: this.context.timelineFilter,
      channelFilter: this.context.channelFilter,
      singleCampaignTypeFilter: this.context.singleCampaignTypeFilter,
      multiProductsFilter: this.context.multiProductsFilter
    });
    this.securSetState({
      timer: setTimeout(() => this.securSetState({ fadeIn: true }), delay)
    });
  }
  componentWillUnmount() {
    this.mounted = false;
    clearTimeout(this.state.timer);
  }
  securSetState(data) {
    if (this.mounted) {
      this.setState(() => data);
    }
  }

  render() {
    let chartsData,
      columns,
      tableData = null;
    const { products } = this.context;
    const { multiProductsFilter, singleCampaignTypeFilter } = this.state;
    let selectedProducts = [];

    if (products && multiProductsFilter && singleCampaignTypeFilter) {
      if (singleCampaignTypeFilter.id === 1) {
        ////////////////////////////
        //Retentions
        ////////////////////////////

        //histograms
        chartsData = [null];
        chartsData.push([{ label: '', value: 854, ratio: 1 }]);

        //colums
        columns = [{ id: 'outcome', label: '' }];
        columns.push({ id: 'total', label: 'Total' });

        //table data
        tableData = [
          {
            outcome: (
              <div
                style={{
                  border: '1px solid #12AD56',
                  borderRadius: '21px',
                  fontSize: '1.3rem',
                  padding: '0.3rem 10 rem 0.4rem 2rem'
                }}
              >
                Accepted
              </div>
            ),
            total: '27.8%'
          },
          {
            outcome: (
              <div
                style={{
                  border: '1px solid #CCBD16',
                  borderRadius: '21px',
                  fontSize: '1.3rem',
                  padding: '0.3rem 2rem 0.4rem'
                }}
              >
                Not Offered
              </div>
            ),
            total: '31.4%'
          },
          {
            outcome: (
              <div
                style={{
                  border: '1px solid #F90000',
                  borderRadius: '21px',
                  fontSize: '1.3rem',
                  padding: '0.3rem 2rem 0.4rem'
                }}
              >
                Rejected
              </div>
            ),
            total: '40.8%'
          },
          {
            outcome: (
              <div
                style={{
                  border: '1px solid #E87F19',
                  borderRadius: '21px',
                  fontSize: '1.3rem',
                  padding: '0.3rem 2rem 0.4rem'
                }}
              >
                Undecided
              </div>
            ),
            total: '40.8%'
          }
        ];
      } else if (
        singleCampaignTypeFilter.id === 1 ||
        singleCampaignTypeFilter.id === 2
      ) {
        ////////////////////////////
        //Collections
        ////////////////////////////

        //histograms
        chartsData = [null];
        chartsData.push([{ label: '', value: 642, ratio: 1 }]);

        //colums
        columns = [{ id: 'outcome', label: '' }];
        columns.push({ id: 'total', label: 'Total' });

        //table data
        tableData = [
          {
            outcome: (
              <div
                style={{
                  border: '1px solid #12AD56',
                  borderRadius: '21px',
                  fontSize: '1.3rem',
                  padding: '0.3rem 10 rem 0.4rem 2rem'
                }}
              >
                Accepted
              </div>
            ),
            total: '33.8%'
          },
          {
            outcome: (
              <div
                style={{
                  border: '1px solid #E5C674',
                  borderRadius: '21px',
                  fontSize: '1.3rem',
                  padding: '0.3rem 2rem 0.4rem'
                }}
              >
                Not Offered
              </div>
            ),
            total: '40.1%'
          },
          {
            outcome: (
              <div
                style={{
                  border: '1px solid #FC8948',
                  borderRadius: '21px',
                  fontSize: '1.3rem',
                  padding: '0.3rem 2rem 0.4rem'
                }}
              >
                Rejected
              </div>
            ),
            total: '26.1%'
          },
        ];
      } else {
        ////////////////////////////
        //Other Campaign Types
        ////////////////////////////

        products.forEach((product) => {
          if (multiProductsFilter.indexOf(product.id) > -1) {
            selectedProducts.push(product);
          }
        });

        //histograms
        chartsData = [null];
        let randValues = [];
        let totalValues = 0;
        selectedProducts.forEach((product) => {
          let rand = Math.random() * (500 - 20) + 500;
          randValues.push(Math.floor(rand));
          totalValues += Math.floor(rand);
        });
        chartsData.push([{ label: '', value: totalValues, ratio: 1 }]);
        for (let i = 0; i < selectedProducts.length; i++) {
          chartsData.push([
            {
              label: '',
              value: randValues[i],
              ratio: randValues[i] / totalValues
            }
          ]);
        }

        //colums
        columns = [{ id: 'outcome', label: '' }];
        columns.push({ id: 'total', label: 'Total' });
        selectedProducts.forEach((product) => {
          columns.push({ id: product.id, label: product.label });
        });

        //table data
        tableData = [
          {
            outcome: (
              <div
                style={{
                  border: '1px solid #12AD56',
                  borderRadius: '21px',
                  fontSize: '1.3rem',
                  padding: '0.3rem 2rem 0.4rem'
                }}
              >
                Accepted
              </div>
            )
          },
          {
            outcome: (
              <div
                style={{
                  border: '1px solid #E5C674',
                  borderRadius: '21px',
                  fontSize: '1.3rem',
                  padding: '0.3rem 2rem 0.4rem'
                }}
              >
                Not Offered
              </div>
            )
          },
          {
            outcome: (
              <div
                style={{
                  border: '1px solid #FC8948',
                  borderRadius: '21px',
                  fontSize: '1.3rem',
                  padding: '0.3rem 2rem 0.4rem'
                }}
              >
                Rejected
              </div>
            )
          }
        ];
        for (let j = 0; j < tableData.length; j++) {
          for (let i = 0; i < selectedProducts.length; i++) {
            let rand = Math.random() * (600 - 100) + 100;
            tableData[j][selectedProducts[i].id] =
              (rand / 10).toFixed(1).toString() + ' %';
          }
          let rand = Math.random() * (600 - 100) + 100;
          tableData[j]['total'] = (rand / 10).toFixed(1).toString() + ' %';
        }
      }
    } else {
      chartsData = [
        [{ label: '', value: '', ratio: 0 }],
        [{ label: '', value: '', ratio: 0 }],
        [{ label: '', value: '', ratio: 0 }],
        [{ label: '', value: '', ratio: 0 }],
        [{ label: '', value: '', ratio: 0 }]
      ];

      columns = [
        { id: 'outcome', label: '' },
        { id: 'total', label: ' ' },
        { id: 'p1', label: ' ' },
        { id: 'p2', label: ' ' },
        { id: 'p3', label: ' ' },
        { id: 'p4', label: ' ' }
      ];
      tableData = [
        {
          outcome: (
            <div
              style={{
                border: '1px solid #12AD56',
                borderRadius: '21px',
                fontSize: '1.3rem',
                padding: '0.3rem 2rem 0.4rem'
              }}
            >
              Accepted
            </div>
          ),
          total: ' ',
          p1: ' ',
          p2: ' ',
          p3: ' ',
          p4: ' '
        },
        {
          outcome: (
            <div
              style={{
                border: '1px solid #E5C674',
                borderRadius: '21px',
                fontSize: '1.3rem',
                padding: '0.3rem 2rem 0.4rem'
              }}
            >
              Not Offered
            </div>
          ),
          total: ' ',
          p1: ' ',
          p2: ' ',
          p3: ' ',
          p4: ' '
        },
        {
          outcome: (
            <div
              style={{
                border: '1px solid #FC8948',
                borderRadius: '21px',
                fontSize: '1.3rem',
                padding: '0.3rem 2rem 0.4rem'
              }}
            >
              Rejected
            </div>
          ),
          total: ' ',
          p1: ' ',
          p2: ' ',
          p3: ' ',
          p4: ' '
        }
      ];
    }

    const { classes } = this.props;

    return (
      <>
        <div
          className={styles.Wrapper}
          style={{ width: '100%', maxWidth: 1400 }}
        >
          {tableData && (
            <Card>
              <Fade in={this.state.fadeIn} timeout={{ enter: 500 }}>
                <div>
                  <Table
                    size='small'
                    style={{
                      margin: '3rem 0rem 5rem',
                      width: selectedProducts.length === 0 ? 'auto' : '100%'
                    }}
                  >
                    <TableHead>
                      <TableRow>
                        {chartsData.map((chart, index) => (
                          <TableCell
                            key={index}
                            classes={{ root: classes.TableHeadCellHisto }}
                            align='center'
                          >
                            <Histogram
                              data={chart}
                              colWidth={6}
                              barWidth={2.3}
                              barHeight={20}
                            />
                          </TableCell>
                        ))}
                      </TableRow>
                    </TableHead>
                    <TableHead>
                      <TableRow>
                        {columns.map((head, index) => (
                          <TableCell
                            key={index}
                            style={{
                              width:
                                selectedProducts.length === 0 ? '50%' : 'auto'
                            }}
                            classes={{ root: classes.TableHeadCell }}
                            align={index === 0 ? 'left' : 'center'}
                          >
                            {head.label}
                          </TableCell>
                        ))}
                      </TableRow>
                    </TableHead>
                    <TableBody classes={{ root: classes.TableBody }}>
                      {tableData.map((row, rowIndex) => (
                        <TableRow
                          key={rowIndex}
                          classes={{ root: classes.TableRow }}
                        >
                          {columns.map((head, colIndex) => (
                            <TableCell
                              classes={{ root: classes.TableCell }}
                              key={colIndex}
                              align={colIndex === 0 ? 'left' : 'center'}
                              size='small'
                              colSpan={row.colspan}
                              style={{
                                paddingRight: colIndex === 0 ? '3rem' : '1.2rem'
                              }}
                            >
                              {row[head.id]}
                            </TableCell>
                          ))}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </Fade>
              {!this.state.fadeIn && <Loader />}
            </Card>
          )}
        </div>
      </>
    );
  }
}

export default withTranslation('monitoring')(
  withStyles(muiStyles)(FeedbackAnalysis)
);
