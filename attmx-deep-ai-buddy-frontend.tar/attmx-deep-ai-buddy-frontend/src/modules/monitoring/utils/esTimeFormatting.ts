export function formatDurationInSeconds(duration: number) {
    let seconds = Math.round(duration);
    let minutes;
    let hours;
    if (duration >= 60) {
        minutes = Math.round(duration / 60);
        seconds = Math.round(duration % 60);
        if (duration >= 3600) {
            hours = Math.round(minutes / 60);
            minutes = Math.round(minutes % 60)
        }
    }
    return `${hours ? hours.toString()+'h:' : ''}${minutes ? minutes.toString()+'m:' : ''}${seconds}s`
}