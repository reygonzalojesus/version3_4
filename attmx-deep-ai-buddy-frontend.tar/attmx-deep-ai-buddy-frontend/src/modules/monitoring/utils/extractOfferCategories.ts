import KPIOutcomesByOffer from "../../../types/outcomesByOffer";

export type OfferPrimitives = { [offerPrimitiveName: string]: string[] }

export default function extractOfferCategories(offerOutcomes: KPIOutcomesByOffer): OfferPrimitives {
    let offerPrimitives: OfferPrimitives = {};
    Object.keys(offerOutcomes.counts).forEach((offerName) => {
        let offerComponents = offerName.split(" + ");
        offerComponents.forEach((c) => {
            if (!offerPrimitives.hasOwnProperty(c)) {
                offerPrimitives[c] = [];
            }
            offerPrimitives[c].push(offerName);
        })
    })
    return offerPrimitives;
}