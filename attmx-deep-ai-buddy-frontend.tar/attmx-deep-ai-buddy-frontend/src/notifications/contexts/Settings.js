export const settings = {
  push_time: 5000,
  silent_pages: []
};
