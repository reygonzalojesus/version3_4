export const FEEDBACKS_LIKE = {
  LIKE: 'like',
  UNLIKE: 'unlike',
  UNKNOWN: 'unknown'
};
export const PUSH_SETTINGS = {
  DETAILED: 'detailed',
  MICRO: 'micro'
};
