import OfferLight from "./offerLight";
import ProductLight from "./productLight";
import Channel from "./channel";
import Content from "./content";

interface Action {
    id: string;
    offer: OfferLight;
    product: ProductLight;
    channel: Channel;
    content: Content;
    name: string;
    expected_cost?: number;
    expected_value?: number;
    probability?: number;
    action_group?: number;
}

export default Action