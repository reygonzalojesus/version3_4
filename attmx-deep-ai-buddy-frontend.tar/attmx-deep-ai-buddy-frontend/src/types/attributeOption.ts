import AttributeOptionDetail from "./attributeOptionDetail";
import Translated from "./translated";

interface AttributeOption {
    category_id: number;
    code: string;
    id: number;
    max_value?: number;
    min_value?: number;
    type: string;
    name: Translated;
    options?: AttributeOptionDetail[];
}

export default AttributeOption;
