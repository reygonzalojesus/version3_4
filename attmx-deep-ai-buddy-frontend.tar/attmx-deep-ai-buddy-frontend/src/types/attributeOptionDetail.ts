interface AttributeOptionDetail {
    id: number;
    name: string;
    order: number;
    value: string;
}

export default AttributeOptionDetail;