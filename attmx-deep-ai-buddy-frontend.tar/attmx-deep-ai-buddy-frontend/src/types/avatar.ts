interface Avatar {
    id: number;
    file: any;
}

export default Avatar;