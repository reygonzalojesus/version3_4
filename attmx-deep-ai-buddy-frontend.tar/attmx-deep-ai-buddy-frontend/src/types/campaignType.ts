interface CampaignType {
    id: number;
    name: string;
    name_en?: string;
    name_es?: string;
}

export default CampaignType;