interface Channel {
    id: number;
    name: string;
    name_en?: string;
    name_es?: string;
    content_types: string[];
    lft: number;
    rght: number;
    tree_id: number;
    level: number;
    parent_id: number;
}

export default Channel;