import Color from "./color";

interface ClientSettings {
    id: number;
    name: string;
    slug: string;
    currency: string;
    langs: string;
    dataset: string;
    schema_name: string;
    logo: any;
    primary_color: Color;
    secondary_color: Color;
}

export default ClientSettings;