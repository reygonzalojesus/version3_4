interface Color {
    main: string;
    light: string;
    dark: string;
}

export default Color;