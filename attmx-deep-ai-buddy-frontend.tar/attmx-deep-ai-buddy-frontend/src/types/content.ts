export enum ContentType {
    Email = "EMAIL",
    CallScript = "CALL_SCRIPT",
    OfferScript = "OFFER_SCRIPT",
    SMS = "SMS",
    SalePitch = "SALE_PITCH",
    AdBanner = "AD_BANNER"
}

interface Content {
    id: number;
    content: any;
    name: string;
    name_en?: string;
    name_es?: string;
    name_it?: string;
    type: ContentType;
    products?: number[];
}

export default Content;