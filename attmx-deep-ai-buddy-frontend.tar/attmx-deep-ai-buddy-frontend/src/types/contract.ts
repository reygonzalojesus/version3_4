import ProductLight from "./productLight";
import ContractSubscriber from "./contractSubscriber";

interface Contract {
    id: number;
    product: ProductLight;
    subscriber: ContractSubscriber;
    customer: number;
    ended?: string;
    discount?: number;
}

export default Contract;