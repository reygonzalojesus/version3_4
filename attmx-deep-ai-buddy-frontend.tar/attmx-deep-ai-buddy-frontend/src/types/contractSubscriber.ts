interface ContractSubscriber {
    id: number;
    src_subscriber_id: number;
    src_mdn: number;
    inserted_ts: any;
    history: any;
}

export default ContractSubscriber;