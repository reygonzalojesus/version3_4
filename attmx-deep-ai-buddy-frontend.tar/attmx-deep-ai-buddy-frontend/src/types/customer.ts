interface Customer {
    id: number;
    firstname: string;
    lastname: string;
    address: string;
    email: string;
    phone_number: string;
    country: string;
    region: string;
    in_quarantine: boolean;
    quarantine_until?: string;
}

export default Customer;