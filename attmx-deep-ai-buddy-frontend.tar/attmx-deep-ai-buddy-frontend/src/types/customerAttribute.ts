import Translated from "./translated";
import AttributeOptionDetail from "./attributeOptionDetail";

interface CustomerAttribute {
    id: number;
    name: Translated;
    options?: AttributeOptionDetail[];
    code: string;
    type: string;
    display?: string;
    min_value?: number;
    max_value?: number;
    order: number;
    category_id: number;
}

export default CustomerAttribute;