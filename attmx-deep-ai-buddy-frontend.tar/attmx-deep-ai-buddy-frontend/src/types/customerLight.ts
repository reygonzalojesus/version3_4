interface CustomerLight {
    id: number;
    firstname: string;
    lastname: string;
    in_quarantine: boolean;
    quarantine_until?: string;
}

export default CustomerLight;