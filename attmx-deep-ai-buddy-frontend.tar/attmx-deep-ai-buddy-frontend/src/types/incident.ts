export default interface Incident {
    subscriber: number;
    created: any;
    title: string;
    incident_source: string;
    call_reason: string;
    assigned_uid: string;
    level_one: string;
    level_two: string;
    level_three: string;
    note: string;
}