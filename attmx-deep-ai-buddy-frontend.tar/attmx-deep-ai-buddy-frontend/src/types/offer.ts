import OfferBase from "./offerBase";
import OfferLight from "./offerLight";

interface Offer extends OfferBase {
    others?: OfferLight[];
}

export default Offer;