interface OfferBase {
    id: number;
    name: string;
    name_en?: string;
    name_es?: string;
    description: string;
}

export default OfferBase;