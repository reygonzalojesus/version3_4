interface OfferLadderLight {
    id: number;
    opportunity: number;
    subscriber: number;
}

export default OfferLadderLight;