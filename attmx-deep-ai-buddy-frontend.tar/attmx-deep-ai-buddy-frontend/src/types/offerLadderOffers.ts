import Content from "./content";
import OfferLadderLight from "./offerLadderLight";
import Offer from "./offer";

interface OfferLadderOffers {
    offerladder: OfferLadderLight;
    content: Content;
    offer: Offer;
    offer_value?: number;
}

export default OfferLadderOffers;