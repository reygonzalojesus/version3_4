import OfferBase from "./offerBase";

interface OfferLight extends OfferBase {}

export default OfferLight;