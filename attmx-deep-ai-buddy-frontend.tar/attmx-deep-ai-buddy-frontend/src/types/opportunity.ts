import Action from "./action";
import Customer from "./customer";
import Product from "./product";
import CampaignType from "./campaignType";

interface Opportunity {
    id: number;
    active: boolean;
    expected_value?: number;
    probability: number;
    propensity?: number;
    customer: Customer;
    product: Product;
    campaign?: number;
    campaign_type?: CampaignType;
    

    // Note that the offer field (on both this and proactiveOpportunity), while returned from the serializer,
    // is deprecated (and as such left out of this model), and should be
    // accessed through action
}

export default Opportunity;