export default interface Order {
    subscriber: number;
    action_type_description: string;
    action_status: string;
    sales_channel_description: string;
    final_status_description: string;
    reason_description: string;
    src_order_id: number;
    created: any;
}