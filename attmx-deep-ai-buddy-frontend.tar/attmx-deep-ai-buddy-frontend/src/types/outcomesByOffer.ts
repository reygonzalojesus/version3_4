
export default interface KPIOutcomesByOffer {
    counts: { [offerName: string]: { [outcomeName: string]: number } };
    total: number;
}