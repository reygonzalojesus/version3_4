export default interface Payment {
    customer: number;
    date: any;
    pending: number;
    pending_days: number;
    account_status: string;
}