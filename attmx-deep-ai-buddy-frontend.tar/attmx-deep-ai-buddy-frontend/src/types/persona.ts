import PersonaType from "./personaType";
import Channel from "./channel";
import User from "./user";

interface Persona {
    id: number;
    nickname: string;
    type: PersonaType;
    channel: Channel;
    user: User;
}

export default Persona;