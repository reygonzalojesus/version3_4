interface PersonaType {
    id: number;
    name: string;
    name_en?: string;
    name_es?: string;
}

export default PersonaType;