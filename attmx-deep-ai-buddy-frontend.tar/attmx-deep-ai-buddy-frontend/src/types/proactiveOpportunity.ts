import Offer from "./offer";
import CustomerLight from "./customerLight";
import Contract from "./contract";
import Action from "./action";

interface ProactiveOpportunity {
    id: number;
    offer: Offer;
    customer: CustomerLight;
    customer_type?: string;
    last_bill_value?: number;
    campaign_type?: any;
    contracts?: Contract[];
    action: Action;
    action_type?: string;
    action_sub_type?: string;
    expected_value?: number;
    probability?: number;
}

export default ProactiveOpportunity;