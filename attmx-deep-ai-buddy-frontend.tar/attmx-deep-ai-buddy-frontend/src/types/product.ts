interface Product {
    name: string;
    name_en?: string
    name_es?: string;
    product_code: string;
    propensity?: number;
    parent?: number;
    price: number;
    price_fixed: boolean;
    price_timedelta?: number;
    package?: number[];
    purchasable: boolean;
}

export default Product;