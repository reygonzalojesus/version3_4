interface ProductLight {
    id: number;
    name: string;
    price?: number;
}

export default ProductLight;
