export default interface TrafficShare {
    customer_id: number;
    daily_facebook_share: number;
    daily_instagram_share: number;
    daily_youtube_share: number;
    daily_tiktok_share: number;
    daily_google_share: number;
    daily_whatsapp_share: number;
    inserted_ts: string;
}
