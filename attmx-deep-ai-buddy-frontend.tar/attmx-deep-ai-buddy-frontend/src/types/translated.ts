interface Translated {
    de?: string;
    en?: string;
    es?: string;
    fr?: string;
    it?: string;
    nl?: string;
    "zh-cn"?: string;
}

export default Translated;