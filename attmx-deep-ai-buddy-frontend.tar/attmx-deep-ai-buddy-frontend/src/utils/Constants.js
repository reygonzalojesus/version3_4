export const ROLES = {
  ADMIN: 'admin',
  CCMANAGER: 'manager',
  CCAGENT: 'agent'
};

export const STORAGE_VARS = {
  TOKEN: 'token',
  ATTUID: 'ATTUID',
  LANGUAGE: 'language',
  AVATAR_DISCLAIMER: 'avatar',
  TENANT: 'tenant',
  GAMIFICATION_ACTIVATED: 'gamification',
  NOTIFICATION_ACTIVATED: 'notification',
  DEMO_CALL_ACCEPTED: 'dca',
  DEMO_CALL_NOTOFFERED: 'dcno',
  DEMO_CALL_REJECTED: 'dcr'
};

export const URLS = {
  LOGIN: 'https://saml.e-access.att.com/isam/sps/ATTIDPEntity/saml20/logininitial?RequestBinding=HTTPPost&PartnerId=https://buddyservices.mx.att.com/deep/api/v1/user/saml',
  LOGIN_UAT: 'https://saml.stage.att.com/isam/sps/ATTIDPEntity/saml20/logininitial?RequestBinding=HTTPPost&PartnerId=https://buddyservicesuat.mx.att.com:16601/deep/api/v1/user/saml',
  UAT:'https://buddyuat.mx.att.com:16500/login',
  PROD:'https://buddy.mx.att.com/login'
};
