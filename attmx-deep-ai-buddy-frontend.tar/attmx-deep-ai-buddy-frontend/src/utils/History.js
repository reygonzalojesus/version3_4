import { createBrowserHistory as History } from 'history';

const BASE_PATH = process.env.REACT_APP_BASE_PATH || ''

export default History({basename: BASE_PATH});
