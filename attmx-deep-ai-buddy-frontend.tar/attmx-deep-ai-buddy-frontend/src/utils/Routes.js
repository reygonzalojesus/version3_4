import React, { Component } from 'react';
import { Router, Switch, Route, Redirect } from 'react-router-dom';
import History from './History';
import * as Tenancy from 'utils/Tenancy';
import NotFound from '../deep/pages/NotFound';
import Forbidden from '../deep/pages/Forbidden';
import Unauthorized from '../deep/pages/Unauthorized';
import Locked from 'deep/pages/Locked';
import InternalServerError from 'deep/pages/InternalServerError';
import Login from '../deep/pages/Login';
import Saml from '../deep/pages/Saml';
import CallSession from '../modules/cco/pages/CallSession';
import HomeAgent from '../modules/cco/pages/HomeAgent';
import GamificationDashboard from '../gamification/pages/GamificationDashboard';
import GamificationBadges from '../gamification/pages/GamificationBadges';
import GamificationRules from '../gamification/pages/GamificationRules';
import GamificationLevels from '../gamification/pages/GamificationLevels';
import UsersMgmt from '../deep/pages/UsersMgmt';
import OverallPerformance from '../modules/monitoring/analysis/pages/OverallPerformance';
import TimeEvolution from '../modules/monitoring/analysis/pages/TimeEvolution';
import FeedbackAnalysis from '../modules/monitoring/analysis/pages/FeedbackAnalysis';
import InteractionOutcome from '../modules/monitoring/analysis/pages/InteractionOutcome';
import exportExcel from '../modules/monitoring/analysis/pages/exportExcel';
import UserAnalysis from '../modules/monitoring/analysis/pages/UserAnalysis';
import NotificationsRules from '../modules/monitoring/notifications/pages/NotificationsRules';
import NotificationsRuleEdit from '../modules/monitoring/notifications/pages/NotificationsRuleEdit';

export default class Routes extends Component {
  render() {
    const isMonoTenant = Tenancy.isMonoTenant();
    const tenant = Tenancy.getTenant();

    if (isMonoTenant) {
      return (
        <Router history={History}>
          <Switch>
            <Redirect path='/' exact to={'/login'} />

            <Route path='/login' component={Login} />
            <Route path='/saml' component={Saml} />
            <Route path='/admin' exact component={UsersMgmt} />
            <Route path='/cco' exact component={HomeAgent} />
            <Route
              path='/cco/session/:customerId/:subscriberId'
              exact
              render={(matchProps) => <CallSession {...matchProps} />}
            />
            <Route path='/404' exact component={NotFound} />
            <Route path='/403' exact component={Forbidden} />
            <Route path='/401' exact component={Unauthorized} />
            <Route path='/423' exact component={Locked} />
            <Route path='/500' exact component={InternalServerError}/>
            <Route
              path='/monitoring/analysis/overall-performance'
              exact
              component={OverallPerformance}
            />
            <Route
              path='/monitoring/analysis/interaction-outcome'
              exact
              component={InteractionOutcome}
            />
            <Route
              path='/monitoring/analysis/report'
              exact
              component={exportExcel}
            />
            <Redirect
              path='/monitoring/analysis'
              to={'/monitoring/analysis/overall-performance'}
            />

            <Redirect to={'/404'} />
          </Switch>
        </Router>
      );
    } else {
      return (
        <Router history={History}>
          <Switch>
            <Redirect path='/login' to={'/' + tenant + '/login'} />
            <Redirect path='/saml' to={'/' + tenant + '/saml'} />
            <Redirect path='/' exact to={'/' + tenant + '/login'} />

            <Route path='/:tenant/login' component={Login} />
            <Route path='/:tenant/saml' component={Saml} />
            <Route path='/:tenant/admin' exact component={UsersMgmt} />
            <Route path='/:tenant/cco' exact component={HomeAgent} />
            <Route path='/:tenant/401' exact component={Unauthorized} />
            <Route path='/:tenant/423' exact component={Locked} />
            <Route path='/:tenant/500' exact component={InternalServerError}/>
            <Route
              path='/:tenant/cco/session/:customerId/:subscriberId'
              exact
              render={(matchProps) => <CallSession {...matchProps} />}
            />
            <Route
              path='/:tenant/cco/game/dashboard'
              exact
              component={GamificationDashboard}
            />
            <Route
              path='//cco/game/badges'
              exact
              component={GamificationBadges}
            />
            <Route path='/cco/game/rules' exact component={GamificationRules} />
            <Route
              path='/cco/game/levels'
              exact
              component={GamificationLevels}
            />
            <Route path='/404' exact component={NotFound} />
            <Route path='/403' exact component={Forbidden} />
            <Route path='/423' exact component={Locked} />
            <Route
              path='/monitoring/analysis/overall-performance'
              exact
              component={OverallPerformance}
            />
            <Route
              path='/monitoring/analysis/time-evolution'
              exact
              component={TimeEvolution}
            />
            <Route
              path='/monitoring/analysis/feedback-analysis'
              exact
              component={FeedbackAnalysis}
            />
            <Route
              path='/monitoring/analysis/interaction-outcome'
              exact
              component={InteractionOutcome}
            />
            <Route
              path='/monitoring/analysis/report'
              exact
              component={exportExcel}
            />
            <Route
              path='/monitoring/analysis/user-analysis'
              exact
              component={UserAnalysis}
            />
            <Route
              path='/monitoring/notifications/rules'
              exact
              component={NotificationsRules}
            />
            <Route
              path='/monitoring/notifications/rule'
              exact
              component={NotificationsRuleEdit}
            />
            <Redirect
              path='/monitoring/analysis'
              to={'/monitoring/analysis/overall-performance'}
            />
            <Redirect
              path='/:tenant/monitoring/analysis/overall-performance'
              to={'/monitoring/analysis/overall-performance'}
            />
            <Redirect
              path='/:tenant/monitoring/analysis/interaction-outcome'
              to={'/monitoring/analysis/interaction-outcome'}
            />
            <Redirect
              path='/:tenant/monitoring/analysis/report'
              to={'/monitoring/analysis/report'}
            />
            <Redirect to={'/404'} />
          </Switch>
        </Router>
      );
    }
  }
}
